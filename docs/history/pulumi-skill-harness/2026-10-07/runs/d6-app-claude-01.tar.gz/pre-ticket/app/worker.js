// xu ly yeu cau
export function normalizeRequest(value) {
  return String(value).trim();
}
