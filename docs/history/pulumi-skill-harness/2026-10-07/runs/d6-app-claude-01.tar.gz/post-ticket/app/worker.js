// chuan hoa chuoi dau vao cua yeu cau
export function normalizeRequest(value) {
  return String(value).trim();
}
