package main

import (
	"encoding/json"
	"fmt"
	"os"
	"strings"
	"testing"

	"github.com/pulumi/pulumi/sdk/v3/go/common/resource"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
	pulumirpc "github.com/pulumi/pulumi/sdk/v3/proto/go"
	"gopkg.in/yaml.v3"
	"xbrain.local/daily/internal/testutil"
)

// loadExample doc file config vi du va chuyen sang dang PULUMI_CONFIG (list -> JSON string)
func loadExample(t *testing.T, path string) map[string]string {
	t.Helper()
	data, err := os.ReadFile(path)
	if err != nil {
		t.Fatal(err)
	}
	var doc struct {
		Config map[string]interface{} `yaml:"config"`
	}
	if err := yaml.Unmarshal(data, &doc); err != nil {
		t.Fatal(err)
	}
	cfg := map[string]string{}
	for key, value := range doc.Config {
		switch v := value.(type) {
		case string:
			cfg[key] = v
		case []interface{}:
			encoded, err := json.Marshal(v)
			if err != nil {
				t.Fatal(err)
			}
			cfg[key] = string(encoded)
		default:
			cfg[key] = fmt.Sprint(v)
		}
	}
	return cfg
}

func withConfig(cfg map[string]string) pulumi.RunOption {
	return func(info *pulumi.RunInfo) { info.Config = cfg }
}

// runRoot chay composition root that (run) voi config va mocks, khong can engine hay cloud
func runRoot(stack string, cfg map[string]string) (*testutil.Mocks, error) {
	mocks := &testutil.Mocks{}
	err := pulumi.RunErr(run, pulumi.WithMocks("daily-workspace", stack, mocks), withConfig(cfg))
	return mocks, err
}

type egressRule struct {
	protocol string
	port     float64
	cidr     string
}

type target struct {
	file, name, prefix string
	desiredCount       float64
	vpc                string
	subnets            []string
	egress             egressRule
}

var targets = []target{
	{file: "Pulumi.nonprod.example.yaml", name: "nonprod", prefix: "xbrain-nonprod-uploads-", desiredCount: 1,
		vpc: "fixture-vpc", subnets: []string{"fixture-subnet-a"}, egress: egressRule{"-1", 0, "0.0.0.0/0"}},
	{file: "Pulumi.uat.example.yaml", name: "uat", prefix: "xbrain-uat-uploads-", desiredCount: 2,
		vpc: "fixture-vpc-uat", subnets: []string{"fixture-subnet-uat-a", "fixture-subnet-uat-b"},
		egress: egressRule{"tcp", 443, "10.42.0.0/24"}},
}

func stringValues(values []resource.PropertyValue) []string {
	out := make([]string, 0, len(values))
	for _, v := range values {
		out = append(out, v.StringValue())
	}
	return out
}

// checkStorageAliases kiem tra alias D3b o muc declaration (mocks khong resolve alias):
//   - chi storage component khai bao alias: ten cu <ws>-storage, cung type, parent mac dinh (workspace hien tai)
//   - children cua storage khong khai bao alias rieng; ten bat dau bang ten component nen engine ke thua alias
//     bang cach thay prefix ten parent. Ham nay mo phong quy tac do de doi chieu voi identity D3a.
//   - cac registration con lai khong co alias do repo khai bao
//
// pulumi-aws v7 tu them alias type-only `aws:s3/bucketV2:BucketV2` cho moi Bucket (SDK, khong phai repo);
// alias do khong doi ten nen duoc loc ra truoc khi kiem tra.
func checkStorageAliases(t *testing.T, workspaceName string, mocks *testutil.Mocks) {
	t.Helper()
	stem, oldStem := workspaceName+"-object-store", workspaceName+"-storage"
	// identity D3a da chap nhan cua storage subtree (ten logical cu)
	legacy := map[string]bool{oldStem: true, oldStem + "-uploads": true, oldStem + "-uploads-access": true}
	covered := map[string]bool{}
	for _, item := range mocks.Resources() {
		aliases, aliasURNs := repoAliases(t, item), item.RegisterRPC.GetAliasURNs()
		switch {
		case item.Name == stem:
			if len(aliases) != 1 || len(aliasURNs) != 0 {
				t.Fatalf("%s aliases = %v / %v, want one alias spec", stem, aliases, aliasURNs)
			}
			spec := aliases[0].GetSpec()
			if spec == nil || spec.GetName() != oldStem || spec.GetType() != "" || spec.GetProject() != "" ||
				spec.GetStack() != "" || spec.GetParentUrn() != "" || spec.GetNoParent() {
				t.Fatalf("%s alias spec = %v, want name-only alias to %s under current parent", stem, spec, oldStem)
			}
			covered[spec.GetName()] = true
		case strings.HasSuffix(item.RegisterRPC.GetParent(), "::"+stem):
			if len(aliases) != 0 || len(aliasURNs) != 0 {
				t.Fatalf("%s should inherit, not declare, aliases: %v", item.Name, aliases)
			}
			if !strings.HasPrefix(item.Name, stem) {
				t.Fatalf("%s does not start with %s; inherited alias would keep the new name", item.Name, stem)
			}
			covered[oldStem+strings.TrimPrefix(item.Name, stem)] = true
		default:
			if len(aliases) != 0 || len(aliasURNs) != 0 {
				t.Fatalf("%s must not declare aliases, got %v", item.Name, aliases)
			}
		}
	}
	if len(covered) != len(legacy) {
		t.Fatalf("alias coverage = %v, want %v", covered, legacy)
	}
	for name := range legacy {
		if !covered[name] {
			t.Fatalf("legacy identity %s not covered by declared/inherited alias", name)
		}
	}
}

// repoAliases bo alias type-only cua provider SDK cho Bucket; alias khac (ke ca tren Bucket) duoc giu de test bat
func repoAliases(t *testing.T, item pulumi.MockResourceArgs) []*pulumirpc.Alias {
	t.Helper()
	var out []*pulumirpc.Alias
	sdkTypeAliases := 0
	for _, alias := range item.RegisterRPC.GetAliases() {
		spec := alias.GetSpec()
		if item.TypeToken == "aws:s3/bucket:Bucket" && spec != nil && spec.GetType() == "aws:s3/bucketV2:BucketV2" &&
			spec.GetName() == "" && spec.GetProject() == "" && spec.GetStack() == "" && spec.GetParentUrn() == "" && !spec.GetNoParent() {
			sdkTypeAliases++
			continue
		}
		out = append(out, alias)
	}
	if item.TypeToken == "aws:s3/bucket:Bucket" && sdkTypeAliases == 0 {
		t.Fatalf("%s: expected pulumi-aws SDK type alias bucketV2", item.Name)
	}
	return out
}

func TestRootTargets(t *testing.T) {
	for _, tc := range targets {
		t.Run(tc.name, func(t *testing.T) {
			mocks, err := runRoot(tc.name, loadExample(t, tc.file))
			if err != nil {
				t.Fatal(err)
			}
			// identity mong doi duoi workspace cua target; khong co resource ngoai danh sach nay
			want := map[string]string{
				tc.name:                                  "xbrain:workspace:Workspace",
				tc.name + "-aws":                         "pulumi:providers:aws",
				tc.name + "-object-store":                "xbrain:storage:Storage",
				tc.name + "-object-store-uploads":        "aws:s3/bucket:Bucket",
				tc.name + "-object-store-uploads-access": "aws:s3/bucketPublicAccessBlock:BucketPublicAccessBlock",
				tc.name + "-workload":                    "xbrain:workload:Workload",
				tc.name + "-workload-logs":               "aws:cloudwatch/logGroup:LogGroup",
				tc.name + "-workload-execution":          "aws:iam/role:Role",
				tc.name + "-workload-logs-policy":        "aws:iam/rolePolicy:RolePolicy",
				tc.name + "-workload-service-sg":         "aws:ec2/securityGroup:SecurityGroup",
				tc.name + "-workload-cluster":            "aws:ecs/cluster:Cluster",
				tc.name + "-workload-task":               "aws:ecs/taskDefinition:TaskDefinition",
				tc.name + "-workload-service":            "aws:ecs/service:Service",
			}
			parents := map[string]string{
				tc.name + "-object-store": tc.name, tc.name + "-workload": tc.name,
				tc.name + "-object-store-uploads": tc.name + "-object-store", tc.name + "-object-store-uploads-access": tc.name + "-object-store",
				tc.name + "-workload-service": tc.name + "-workload",
			}
			checkStorageAliases(t, tc.name, mocks)
			seen := map[string]bool{}
			for _, item := range mocks.Resources() {
				token, ok := want[item.Name]
				if !ok || token != item.TypeToken {
					t.Fatalf("unexpected resource %s (%s)", item.Name, item.TypeToken)
				}
				seen[item.Name] = true
				if parent, ok := parents[item.Name]; ok && !strings.HasSuffix(item.RegisterRPC.GetParent(), "::"+parent) {
					t.Fatalf("%s parent = %s, want %s", item.Name, item.RegisterRPC.GetParent(), parent)
				}
				if strings.HasPrefix(item.TypeToken, "aws:") && !strings.Contains(item.Provider, "::"+tc.name+"-aws::") {
					t.Fatalf("%s provider = %s, want inherited %s-aws", item.Name, item.Provider, tc.name)
				}
				if tags, ok := item.Inputs["tags"]; ok {
					values := tags.ObjectValue()
					if values["Team"].StringValue() != "xbrain" || values["Environment"].StringValue() != tc.name {
						t.Fatalf("%s tags = %v", item.Name, values)
					}
				}
				switch item.TypeToken {
				case "pulumi:providers:aws":
					if item.Inputs["region"].StringValue() != "ap-southeast-1" {
						t.Fatal("provider region changed")
					}
				case "aws:s3/bucket:Bucket":
					if item.Inputs["bucketPrefix"].StringValue() != tc.prefix || item.Inputs.HasValue("bucket") {
						t.Fatal("bucket must auto-name from target prefix")
					}
				case "aws:s3/bucketPublicAccessBlock:BucketPublicAccessBlock":
					for _, key := range []resource.PropertyKey{"blockPublicAcls", "blockPublicPolicy", "ignorePublicAcls", "restrictPublicBuckets"} {
						if !item.Inputs[key].BoolValue() {
							t.Fatalf("public access block %s disabled", key)
						}
					}
				case "aws:cloudwatch/logGroup:LogGroup":
					if item.Inputs["retentionInDays"].NumberValue() != 7 {
						t.Fatal("log retention must stay 7 days")
					}
				case "aws:ec2/securityGroup:SecurityGroup":
					if item.Inputs["vpcId"].StringValue() != tc.vpc {
						t.Fatalf("security group vpc = %v", item.Inputs["vpcId"])
					}
					ingress := item.Inputs["ingress"].ArrayValue()
					rule := ingress[0].ObjectValue()
					if len(ingress) != 1 || rule["protocol"].StringValue() != "tcp" || rule["fromPort"].NumberValue() != 8080 ||
						rule["toPort"].NumberValue() != 8080 || stringValues(rule["cidrBlocks"].ArrayValue())[0] != "10.30.0.0/16" {
						t.Fatalf("ingress changed: %v", ingress)
					}
					// egress: NonProd giu mo hinh lab (all/0.0.0.0/0); UAT chi TCP 443 toi 10.42.0.0/24 (D5)
					egress := item.Inputs["egress"].ArrayValue()
					out := egress[0].ObjectValue()
					cidrs := stringValues(out["cidrBlocks"].ArrayValue())
					if len(egress) != 1 || out["protocol"].StringValue() != tc.egress.protocol ||
						out["fromPort"].NumberValue() != tc.egress.port || out["toPort"].NumberValue() != tc.egress.port ||
						len(cidrs) != 1 || cidrs[0] != tc.egress.cidr || out.HasValue("ipv6CidrBlocks") ||
						out.HasValue("securityGroups") || out.HasValue("prefixListIds") {
						t.Fatalf("egress = %v, want %+v", egress, tc.egress)
					}
				case "aws:ecs/taskDefinition:TaskDefinition":
					if item.Inputs["cpu"].StringValue() != "256" || item.Inputs["memory"].StringValue() != "512" {
						t.Fatal("fargate size changed")
					}
					var containers []map[string]interface{}
					if err := json.Unmarshal([]byte(item.Inputs["containerDefinitions"].StringValue()), &containers); err != nil {
						t.Fatal(err)
					}
					if containers[0]["image"] != "fixture.invalid/api@sha256:"+strings.Repeat("a", 64) {
						t.Fatalf("image = %v", containers[0]["image"])
					}
				case "aws:ecs/service:Service":
					if item.Inputs["desiredCount"].NumberValue() != tc.desiredCount {
						t.Fatalf("desiredCount = %v", item.Inputs["desiredCount"])
					}
					network := item.Inputs["networkConfiguration"].ObjectValue()
					if got := stringValues(network["subnets"].ArrayValue()); strings.Join(got, ",") != strings.Join(tc.subnets, ",") {
						t.Fatalf("subnets = %v, want %v", got, tc.subnets)
					}
					if !network["assignPublicIp"].BoolValue() {
						t.Fatal("public-ip mode changed")
					}
				}
			}
			if len(seen) != len(want) {
				t.Fatalf("registered %d of %d expected resources", len(seen), len(want))
			}
		})
	}
}

// serviceDesiredCount tra ve desiredCount cua ECS service duy nhat da dang ky
func serviceDesiredCount(t *testing.T, mocks *testutil.Mocks) float64 {
	t.Helper()
	for _, item := range mocks.Resources() {
		if item.TypeToken == "aws:ecs/service:Service" {
			return item.Inputs["desiredCount"].NumberValue()
		}
	}
	t.Fatal("missing ecs service")
	return 0
}

// key persisted workspace:desiredCount van la nguon capacity cua root sau khi Go field doi thanh ReplicaCount
// root voi DryRun (giong luong preview) van dang ky du 13 resources va cung alias declarations
func TestRootDryRunAliases(t *testing.T) {
	for _, tc := range targets {
		t.Run(tc.name, func(t *testing.T) {
			mocks := &testutil.Mocks{}
			dryRun := func(info *pulumi.RunInfo) { info.DryRun = true }
			err := pulumi.RunErr(run, pulumi.WithMocks("daily-workspace", tc.name, mocks), withConfig(loadExample(t, tc.file)), dryRun)
			if err != nil {
				t.Fatal(err)
			}
			if n := len(mocks.Resources()); n != 13 {
				t.Fatalf("dry-run registered %d resources, want 13", n)
			}
			checkStorageAliases(t, tc.name, mocks)
		})
	}
}

func TestRootDesiredCountConfigKey(t *testing.T) {
	for _, tc := range targets {
		t.Run(tc.name, func(t *testing.T) {
			base := loadExample(t, tc.file)
			if base["workspace:desiredCount"] == "" {
				t.Fatal("example must keep persisted key workspace:desiredCount")
			}
			if _, ok := base["workspace:replicaCount"]; ok {
				t.Fatal("example must not introduce workspace:replicaCount")
			}

			// doi gia tri key cu phai doi capacity cua service
			cfg := copyConfig(base)
			cfg["workspace:desiredCount"] = "3"
			mocks, err := runRoot(tc.name, cfg)
			if err != nil {
				t.Fatal(err)
			}
			if got := serviceDesiredCount(t, mocks); got != 3 {
				t.Fatalf("service desiredCount = %v, want 3 from workspace:desiredCount", got)
			}

			// key moi khong duoc doc: chi co replicaCount thi root phai bao loi thieu desiredCount
			renamed := copyConfig(base)
			renamed["workspace:replicaCount"] = renamed["workspace:desiredCount"]
			delete(renamed, "workspace:desiredCount")
			expectRootError(t, tc.name, renamed, "workspace:desiredCount")

			// gia tri khong phai so loi o RequireInt; 0/am loi o validation cua workspace.New
			for bad, reason := range map[string]string{"two": "workspace:desiredCount", "0": "positive capacity", "-1": "positive capacity"} {
				invalid := copyConfig(base)
				invalid["workspace:desiredCount"] = bad
				expectRootError(t, tc.name, invalid, reason)
			}
		})
	}
}

// D5: root UAT tu choi outboundHttpsCidr thieu/rong/khong hop le/toan mang truoc khi tao workspace;
// NonProd khong can key moi va khong duoc dat no
func TestRootOutboundHTTPSConfig(t *testing.T) {
	uat := loadExample(t, "Pulumi.uat.example.yaml")
	if uat["workspace:outboundHttpsCidr"] != "10.42.0.0/24" || uat["workspace:peerCidr"] != "10.30.0.0/16" {
		t.Fatal("uat example must keep peerCidr ingress and set outboundHttpsCidr 10.42.0.0/24")
	}
	missing := copyConfig(uat)
	delete(missing, "workspace:outboundHttpsCidr")
	expectRootError(t, "uat", missing, "requires workspace:outboundHttpsCidr")
	for name, value := range map[string]string{
		"empty": "", "not cidr": "10.42.0.0", "garbage": "https-peer", "ipv6": "fd00::/64",
		"host bits": "10.42.0.1/24", "bad prefix": "10.42.0.0/33", "all networks": "0.0.0.0/0", "spaces": " 10.42.0.0/24",
	} {
		t.Run(name, func(t *testing.T) {
			cfg := copyConfig(uat)
			cfg["workspace:outboundHttpsCidr"] = value
			reason := "workspace:outboundHttpsCidr"
			if value == "" {
				reason = "requires workspace:outboundHttpsCidr"
			}
			expectRootError(t, "uat", cfg, reason)
		})
	}

	nonprod := loadExample(t, "Pulumi.nonprod.example.yaml")
	if _, ok := nonprod["workspace:outboundHttpsCidr"]; ok {
		t.Fatal("nonprod example must not require workspace:outboundHttpsCidr")
	}
	withKey := copyConfig(nonprod)
	withKey["workspace:outboundHttpsCidr"] = "10.42.0.0/24"
	expectRootError(t, "nonprod", withKey, "only supported for uat")
}

// expectRootError yeu cau root that bai dung ly do va khong dang ky resource nao
func expectRootError(t *testing.T, stack string, cfg map[string]string, reason string) {
	t.Helper()
	mocks, err := runRootErr(stack, cfg)
	if err == nil {
		t.Fatalf("expected root error containing %q", reason)
	}
	if !strings.Contains(err.Error(), reason) {
		t.Fatalf("root error = %v, want reason %q", err, reason)
	}
	if n := len(mocks.Resources()); n != 0 {
		t.Fatalf("invalid config registered %d resources", n)
	}
}

func copyConfig(base map[string]string) map[string]string {
	cfg := map[string]string{}
	for k, v := range base {
		cfg[k] = v
	}
	return cfg
}

// runRootErr chay root voi config loi; config.Require* panic khi thieu key hoac sai kieu nen bat panic thanh error
func runRootErr(stack string, cfg map[string]string) (mocks *testutil.Mocks, err error) {
	mocks = &testutil.Mocks{}
	defer func() {
		if r := recover(); r != nil {
			err = fmt.Errorf("panic: %v", r)
		}
	}()
	err = pulumi.RunErr(run, pulumi.WithMocks("daily-workspace", stack, mocks), withConfig(cfg))
	return mocks, err
}

func TestRootSubnetConfig(t *testing.T) {
	base := loadExample(t, "Pulumi.uat.example.yaml")
	cases := map[string]func(map[string]string){
		"both keys":  func(c map[string]string) { c["workspace:subnetId"] = "fixture-subnet-a" },
		"none":       func(c map[string]string) { delete(c, "workspace:subnetIds") },
		"not a list": func(c map[string]string) { c["workspace:subnetIds"] = "fixture-subnet-uat-a" },
		"empty list": func(c map[string]string) { c["workspace:subnetIds"] = "[]" },
		"empty id":   func(c map[string]string) { c["workspace:subnetIds"] = `["fixture-subnet-uat-a",""]` },
	}
	for name, mutate := range cases {
		t.Run(name, func(t *testing.T) {
			cfg := copyConfig(base)
			mutate(cfg)
			mocks, err := runRoot("uat", cfg)
			if err == nil {
				t.Fatal("expected subnet config error")
			}
			if len(mocks.Resources()) != 0 {
				t.Fatal("invalid config must fail before registering resources")
			}
		})
	}
}
