# D5 — Kết nối HTTPS thuộc workspace UAT

Network team sở hữu VPC, subnets, route tables, mọi route và peer. Workspace chỉ consume các ID đã cấp; không tạo, import hay sửa VPC/subnet/route/TGW/peer hoặc policy của bên còn lại. Contract offline không chứng minh đường đi hoặc kết nối AWS.

Ticket đã duyệt thay egress rộng hiện tại của security group UAT bằng một đích IPv4 `10.42.0.0/24`, protocol TCP, từ port 443 tới port 443. Cấu hình đích được đọc tại composition root từ key mới `workspace:outboundHttpsCidr`, rồi truyền bằng Args có kiểu qua workspace và workload. Không dùng `workspace:peerCidr` cho đích outbound: key cũ giữ nguyên ingress nội bộ `10.30.0.0/16` tới TCP 8080. Cấu hình và egress rộng của NonProd giữ nguyên, không bắt NonProd cấp key mới.

Root UAT phải từ chối key outbound thiếu, rỗng, không phải IPv4 CIDR hợp lệ hoặc CIDR toàn mạng trước khi gọi tạo workspace. Input là concrete config; không đọc config sâu trong package con. Chỉ UAT được đổi egress; không mở thêm destination, IPv6 hoặc protocol/port. Không đổi tên/key `workspace:desiredCount` đã lưu: Go API hiện tại vẫn là `ReplicaCount`.

Giữ toàn bộ type/name/parent/provider, outputs, aliases storage hiện tại, log retention 7 ngày, image/health/log wiring, capacity, ingress và các resource khác. Không bỏ tài nguyên workload khi image Output còn unknown. Giữ major và version dependencies hiện tại. Coder chọn cách tổ chức Args/helper hợp lý; không cần một tên field Go cụ thể hoặc một cấu trúc expression chính xác.

UAT consume `fixture-vpc-uat`, hai subnets `fixture-subnet-uat-a`, `fixture-subnet-uat-b`, desiredCount 2, storage prefix `xbrain-uat-uploads-`, tags Team=xbrain/Environment=uat, region ap-southeast-1. Các ID/image chỉ dùng mock. Network team chưa cấp topology/routes/peer firewall live, backend/state, image pull được hoặc helper probe. Điều kiện trước kiểm tra thật: xác nhận routes hai chiều, policy peer cho HTTPS, workspace đã provision theo quyền, image/probe và identity đúng target được cấp. Source và mock pass chỉ cho biết wiring/ownership/scope; connectivity, DNS, route hiệu lực, TGW/cross-account và cloud plan chưa kiểm chứng.

Quyền: sửa Go/config example/tests/docs của hạ tầng liên quan, chạy Go checks và mock tests; không chạy native CLI khác, pulumi preview/up/refresh/import/destroy, auth/config/state writes, CI dispatch, push hoặc thao tác AWS. Không sửa/build app. Hướng dẫn dùng và handoff viết tiếng Việt có dấu; code comments tiếng Việt không dấu. Cập nhật docs đang có khi behavior đổi, không tạo report riêng.
