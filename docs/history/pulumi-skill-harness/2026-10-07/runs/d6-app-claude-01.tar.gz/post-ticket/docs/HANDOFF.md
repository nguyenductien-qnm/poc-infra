# Bàn giao cho người tiếp quản

Tài liệu này dành cho người chỉ có repository này, không có lịch sử trao đổi trước.

## Trạng thái hiện tại

- Một project Pulumi Go `daily-workspace` (`infra/`), gồm hai target ví dụ:
  NonProd (`Pulumi.nonprod.example.yaml`) và UAT (`Pulumi.uat.example.yaml`).
  Đây là fixture offline: chưa có stack, backend, state hay identity thật.
- Đọc theo thứ tự: `AGENTS.md`, `docs/DECISIONS.md` (các quyết định D1–D5),
  `docs/CONTRACTS.md`, `docs/D4-DELIVERY.md`, `docs/D5-NETWORK-CONTRACT.md`,
  `README.md` (config, migration D3b, preview D4, egress D5), `docs/OPERATIONS.md`.
- Các điểm phải giữ:
  - logical names, type tokens, parents và provider `<ws>-aws`;
  - alias storage D3b;
  - Go API `ReplicaCount` cùng config key persisted `workspace:desiredCount`;
  - log retention 7 ngày;
  - egress UAT TCP 443 tới `10.42.0.0/24`;
  - preview D4 chỉ cho NonProd;
  - deploy manual-dispatch có approval;
  - VPC, subnets và routes thuộc network team.

## D6: drift log retention

Chẩn đoán và hướng reconcile ở `docs/OPERATIONS.md`. Tóm tắt: observation 14 ngày
là fixture, declared là 7. Mới chỉ đề xuất reconcile, chưa chạy gì.

Kiểm tra local, tất cả offline:

```sh
cd infra && gofmt -l . && go mod tidy -diff && go vet ./... && go build ./... && go test ./...
cd offline-controls/secret-transform && go test ./...   # GOPROXY=off GOSUMDB=off
python -B -m unittest discover -s scripts/delivery -p test_d4_preview.py   # cần pwsh
```

## Quyết định đang chờ duyệt (chỉ phân tích, chưa triển khai)

### Regional NAT

Hiện trạng: ECS service đặt `AssignPublicIp: true`. Egress của NonProd là
all/`0.0.0.0/0`; egress của UAT chỉ là TCP 443 tới `10.42.0.0/24`.

Tác động nếu chuyển sang NAT:
- Cần private subnets, route `0.0.0.0/0` qua NAT và NAT gateway. Tất cả thuộc
  network dùng chung của network team. Workspace không tạo, import hay sửa
  chúng; chỉ consume subnet IDs mới qua config.
- Phía workspace sẽ đổi `AssignPublicIp` thành false và đổi subnet refs. Thay
  đổi network configuration của ECS service phải được kiểm tra bằng preview
  (update hay replace, gián đoạn task). Đọc source chưa đủ để kết luận.
- Egress UAT hiện tại không cho đi internet qua NAT. Kéo image và đẩy log
  (`awslogs`) cần TCP 443 tới ECR hoặc registry và CloudWatch Logs. Nếu không
  có VPC endpoints hoặc route qua `10.42.0.0/24`, task UAT có thể không khởi
  động được. Rủi ro này đã tồn tại từ D5, cần network team xác nhận, và mock
  không phát hiện được.

Input và quyền cần chốt: topology (subnets/AZ, NAT theo AZ hay regional), quyết
định cost/availability, owner của NAT và route, VPC endpoints cho
ECR/Logs/S3, quyền thay đổi network dùng chung, và egress mục tiêu của từng target.

### N-1 capacity

Hiện trạng: NonProd có `desiredCount` 1, UAT có 2. Giữ nguyên, không đổi.

Tác động: NonProd với 1 task không chịu được mất một task hay một AZ. UAT với 2
task trên 2 subnets chỉ chịu được N-1 nếu một task đủ tải và hai subnets nằm ở
hai AZ khác nhau. Điều kiện AZ chưa được xác nhận.

Input cần chốt:
- SLO;
- tải và capacity của mỗi task (256 CPU/512 MiB);
- ánh xạ subnet sang AZ;
- giá trị được duyệt.

Giá trị mới đi qua `workspace:desiredCount` (Go: `ReplicaCount`); không đổi tên key.

## Quyền và input còn thiếu, theo owner

| Owner | Cần cấp |
| --- | --- |
| Delivery owner | Backend/state thật (S3/KMS), CI identity chỉ cho preview và identity deploy riêng, quyền dispatch, preview có refresh cho từng stack. |
| Owner workspace NonProd/UAT | Xác nhận retention mong muốn, quyết định có giữ log cũ trước khi hạ retention hay không, giá trị N-1. |
| Network team | Topology/NAT, routes hai chiều tới `10.42.0.0/24`, VPC endpoints, policy phía peer. |
| App team | Image pull được, thay cho fixture `fixture.invalid`. |

## Lưu ý

- `app/` nằm ngoài phạm vi hạ tầng. `app/worker.js` có comment chung chung (`xu ly yeu cau`),
  nhưng ticket không cho sửa app nên chưa đụng tới.
- Không coi mocks, YAML hợp lệ hay log synthetic là preview, deploy hay
  approval đã quan sát.
