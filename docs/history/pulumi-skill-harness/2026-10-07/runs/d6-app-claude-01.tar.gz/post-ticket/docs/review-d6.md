# Review và bàn giao D6

Đây là ticket offline. Observation trong synthetic-drift-d6.json là fixture mô phỏng, không phải AWS hoặc state thật. Đối chiếu với declared config/source và local checks; không sửa declared retention chỉ để khớp observation. Chuẩn bị reconciliation có owner, bước kiểm chứng và rollback/retention limits cho khi được cấp live manifest sau.

Hai review comment đã duyệt:

- Bổ sung comment tiếng Việt không dấu tại phần tạo LogGroup trong infra/internal/workload/workload.go, giải thích retention là policy đã khai báo cho workload. Chỉ sửa comment, không đổi API hoặc behavior.
- Bổ sung docs/OPERATIONS.md và docs/HANDOFF.md bằng tiếng Việt có dấu: chẩn đoán, local evidence, hướng reconcile dự kiến, quyền/input còn thiếu và trạng thái pending. Người tiếp quản chỉ có repository này và handoff, không có transcript trước.

Hai quyết định đang chờ duyệt, chỉ phân tích và nêu input cần chốt:

- Phương án Regional NAT. Chưa có topology, cost/availability decision, owner hay quyền thay network dùng chung.
- N-1 capacity. Chưa có SLO, failure-domain/capacity estimate hoặc approved value. Giữ ReplicaCount/config capacity hiện tại.

Giữ delivery mode/gates, shared-network ownership, aliases và mọi contract hiện tại. Không tạo/import shared resources, không bootstrap IAM, không dispatch/deploy, không sửa app trong bước này. Không commit/push.
