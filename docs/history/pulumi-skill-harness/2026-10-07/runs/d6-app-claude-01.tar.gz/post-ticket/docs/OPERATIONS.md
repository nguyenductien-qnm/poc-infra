# Vận hành: drift log retention (D6)

## Phân loại bằng chứng

| Nguồn | Loại | Nội dung |
| --- | --- | --- |
| `docs/synthetic-drift-d6.json` | Fixture do controller viết | `nonprod-workload-logs` (`aws:cloudwatch/logGroup:LogGroup`) có `retentionInDays: 14`. Không phải AWS read, preview, refresh hay state export. |
| `infra/internal/workload/workload.go` | Source khai báo | `RetentionInDays: pulumi.Int(7)`, dùng chung cho mọi workspace. |
| `docs/CONTRACTS.md` | Contract | NonProd: log retention 7 ngày. |
| `go test ./...` trong `infra/` | Quan sát local (mocks) | NonProd và UAT đều đăng ký LogGroup `<ws>-workload-logs` với `retentionInDays = 7` (`TestRootTargets`, `TestExistingNonProd`, `TestUAT`). |

Mocks chỉ cho thấy chương trình khai báo gì. Không có bằng chứng nào về giá trị
thật trên AWS hay trong state; observation 14 chưa được xác minh.

## Chẩn đoán

Nếu observation đúng trên môi trường thật, đây là thay đổi ngoài IaC: declared
và contract là 7, thực tế là 14. Declared được giữ nguyên. Sửa source thành 14
chỉ để khớp observation là không hợp lệ; muốn 14 thì phải đổi contract trước.

## Hướng reconcile dự kiến (chưa thực hiện)

Chỉ làm khi đã có quyền và live manifest:

1. Owner workspace NonProd xác nhận giá trị mong muốn. Mặc định là 7 theo contract.
   Nếu muốn 14, phải đổi `docs/CONTRACTS.md` và source qua review trước.
2. Delivery owner chạy preview có cấp quyền, có refresh, trên stack NonProd, với
   đúng revision, backend và identity. Diff mong đợi: chỉ `nonprod-workload-logs`
   đổi `retentionInDays` 14 → 7, update in-place, không replace hay delete.
3. Apply qua luồng deploy manual-dispatch có approval hiện có. Sau đó đọc lại để
   xác nhận retention là 7 và không còn diff.
4. Ghi lại ai đã đổi ngoài IaC và chặn tái diễn, ví dụ bằng quyền hoặc quy trình.

## Giới hạn rollback và retention

- Hạ retention 14 → 7 làm CloudWatch xóa log events cũ hơn 7 ngày. Thao tác này
  không đảo ngược được: nâng lại 14 không khôi phục dữ liệu đã xóa, và revert Git
  cũng không phải rollback.
- Nếu cần giữ log 8–14 ngày tuổi (sự cố, audit), phải export hoặc giữ chúng
  trước khi apply. Việc này cần quyết định của owner.
- Chưa biết UAT có cùng drift hay không, vì observation chỉ nói về NonProd. Mỗi
  stack cần preview riêng.

Quyền và input còn thiếu: xem `docs/HANDOFF.md`.
