# Quyết định của lab

- Track offline/code. Chưa có AWS state hay resource; IDs và image chỉ là fixture.
- Một project Go `daily-workspace`; consumers là NonProd (hiện có) và UAT (D2,
  onboard ở mức source/config example, chưa có stack). Cấu hình môi trường được
  đọc ở composition root và dùng chung các capability cụ thể.
- Subnets: `workspace:subnetIds` (list) cho UAT/target mới; `workspace:subnetId`
  (single) là key legacy của NonProd, vẫn được hỗ trợ. Hai key loại trừ nhau.
- Workspace sở hữu bucket, SG, logs, execution role, ECS cluster/task/service.
  VPC và subnets thuộc network team, chỉ consume qua contract. Không import hay
  register lại chúng. Provider thuộc workspace.New, được đăng ký ở stack root với tên <workspace>-aws; children kế thừa provider qua parent. Composition root cmd/workspace đọc config. Giữ cách sở hữu provider này trong ticket cấu hình.
- Identity hiện tại: type token `xbrain:workspace:Workspace`, logical name
  `nonprod`, child components `nonprod-object-store` (trước D3b là
  `nonprod-storage`, giữ qua alias) / `nonprod-workload` và các
  resource suffix trong source. Refactor giữ chúng hoặc nêu migration/aliases.
  UAT dùng cùng type token và suffix dưới logical name `uat`, provider `uat-aws`.
- Đổi tên storage (D3b): stem `<workspace>-storage` → `<workspace>-object-store`
  (Bucket `...-uploads`, BucketPublicAccessBlock `...-uploads-access`). Storage
  component khai báo một alias `Name: <workspace>-storage` (cùng type, cùng
  parent workspace). Children không khai báo alias riêng: tên của chúng bắt đầu
  bằng tên component nên SDK/engine sinh alias kế thừa bằng cách thay prefix tên
  parent. Mục đích: giữ bucket và dữ liệu, không replace chỉ vì đổi tên logical.
  Type tokens, properties, prefix vật lý, provider, Outputs và 10 registrations
  khác không đổi. Chỉ gỡ alias sau khi mọi stack đã `up` thành công với tên mới.
- NonProd cho phép protection=false; không thêm production guardrails unasked.
- Delivery mode: kiểm tra PR, preview thủ công và deploy manual-dispatch có
  approval. Chưa cấp backend/CI identity; không dispatch hoặc đổi delivery mode.
- StoragePrefix hiện tại `xbrain-nonprod-uploads-`; dùng BucketPrefix auto-name,
  không lấy physical name cố định. Consumer mới có prefix riêng theo contract.
  Prefix đi từ config `storagePrefix` qua `workspace.Args` vào `storage.Args.Prefix`;
  logical name của workspace lấy từ config `environment`.
- Capacity (D3a): Go API dùng `ReplicaCount` (int) ở `workspace.Args` và
  `workload.Args`; field `DesiredCount` cũ đã bỏ. Config key persisted vẫn là
  `workspace:desiredCount` và map vào `ecs.ServiceArgs.DesiredCount`. Đây chỉ là
  đổi Go identifier, không đổi resource identity nên không cần alias/migration.
- Egress UAT (D5): `workspace:outboundHttpsCidr` (UAT bắt buộc, IPv4 CIDR chuẩn,
  không `/0`) được validate ở composition root, truyền qua
  `workspace.Args.OutboundHTTPSCIDR` → `workload.Args.OutboundHTTPSCIDR`; SG UAT
  chỉ có egress TCP 443 tới CIDR đó. NonProd không đặt key, giữ egress lab rộng.
  Ingress `peerCidr` và mọi identity không đổi; mạng chung vẫn do network team sở hữu.
- Preview thủ công cho revision PR (D4): entry `d4-preview.yml` →
  `scripts/delivery/preview.ps1` chỉ preview NonProd với label mock cố định
  `fixture-backend-nonprod`; target cố định trong entrypoint, không là input hay
  environment override. Deploy manual-dispatch có approval vẫn là luồng riêng.
- Args/Outputs có consumer thật; không thêm registry, plugin engine hoặc flags
  chưa dùng. Không nâng major SDK. Mocks không phải observed Pulumi preview.
