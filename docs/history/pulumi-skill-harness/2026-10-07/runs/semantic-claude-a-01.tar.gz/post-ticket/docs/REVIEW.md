# Rà soát archive

Kết luận: `changes-requested` đối với tài liệu bàn giao. Kiểm tra Go đều đạt. Trong bốn nhận định ban đầu, hai nhận định đúng và được giữ nguyên, hai nhận định không được source/test hỗ trợ nên đã được sửa bên dưới. Không có thay đổi nào với source hoặc test.

## Kết quả kiểm tra

- SHA-256 hiện tại của `infra/archive/archive.go`, `infra/archive/archive_test.go`, `infra/go.mod` và `infra/go.sum` khớp với `docs/baseline-checks.json`, nên baseline áp dụng đúng cho mã đang rà soát.
- Chạy lại trong `infra` với `GOPROXY=off`, `GOSUMDB=off`, `AWS_EC2_METADATA_DISABLED=true`: `gofmt -l .`, `go mod tidy -diff`, `go vet ./...`, `go build ./...` và `go test -count=1 -v ./...` đều thoát với mã 0. Cả bốn test PASS, và danh mục `APPLICATION_REGISTRATION_REQUESTS` trùng khớp với baseline.
- Bằng chứng chỉ đến từ mock (`pulumi.WithMocks`, `archive_test.go:48-51`). Recorder ghi type/name/parent của từng request đăng ký và loại Stack ngầm của SDK (`archive_test.go:29-37`).

## Tham số không hợp lệ

- Đã sửa: luồng `NewLate` với `KeepDays=0` có bị từ chối, nhưng chỉ sau khi đã đăng ký bốn tài nguyên ứng dụng: provider `ledger-region`, component `ledger`, Bucket `ledger-blobs` và BucketPublicAccessBlock `ledger-access`. Lý do là `prepare` chạy trước (`archive.go:30`, `archive.go:50-70`), còn `validate` chỉ được gọi trong `newAudit` (`archive.go:34`, `archive.go:74-76`). Chỉ LogGroup là không được đăng ký. Test `TestLateRejectedInput` khẳng định đúng bốn type này (`archive_test.go:61-74`).
- Giữ nguyên, đúng: luồng `NewEarly` với `KeepDays=0` bị từ chối trước mọi đăng ký tài nguyên do ứng dụng khai báo, không tính Stack ngầm của SDK. `validate` chạy ở điểm vào (`archive.go:44-46`). `TestEarlyRejectedInput` khẳng định lỗi và danh mục rỗng (`archive_test.go:76-84`).

## Quan hệ parent

- Đã sửa: `TestSelectedParents` không kiểm tra parent của cả năm tài nguyên. Test chỉ khẳng định có đúng năm request (`archive_test.go:94-96`) và chỉ so parent của Bucket và LogGroup với component `ledger` (`archive_test.go:98-108`). Parent của BucketPublicAccessBlock, component và provider không được test này khẳng định.
- Giữ nguyên, đúng: `TestCompleteFrozenParents` so sánh bằng `reflect.DeepEqual` toàn bộ danh mục type/name/parent đã sắp xếp của cả năm tài nguyên ứng dụng, gồm provider và component gốc (parent là Stack), với danh mục đóng băng (`archive_test.go:111-127`; sắp xếp tại `archive_test.go:38-44`). Test này chỉ chạy với `NewEarly` và `KeepDays=7`.

## Phạm vi và điều chưa biết

- Việc các kiểm tra Go và mock thành công không chứng minh được câu chữ của các nhận định. Hai nhận định sai ở trên vẫn tồn tại cùng lúc với việc mọi test đều PASS.
- Đây không phải deploy hay preview: không có tài nguyên AWS nào được tạo, không đọc state/backend và không quan sát kế hoạch thay đổi. Không chứng minh được kế hoạch no-change hay thay thế tài nguyên.
- Chưa được khẳng định: việc gán `pulumi.Provider(provider)` cho các tài nguyên con (`archive.go:59`, `archive.go:66`, `archive.go:77`), giá trị input (region, các cờ chặn truy cập công khai, `RetentionInDays`), output của `RegisterResourceOutputs` (`archive.go:39`), luồng `NewLate` hợp lệ và các giá trị `KeepDays` âm.
- Rủi ro chưa kiểm chứng: khi chạy thật, `NewLate` với tham số không hợp lệ đã đăng ký bốn tài nguyên trước khi trả lỗi. Theo DECISIONS.md, thứ tự đăng ký không được thay đổi trong nhiệm vụ này.
