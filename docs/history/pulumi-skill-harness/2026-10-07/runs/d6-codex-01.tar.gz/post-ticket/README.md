# xbrain daily infrastructure lab

Repo kế thừa cho ticket bảo trì Pulumi Go. Đây là fixture offline, chưa deploy.
`infra/cmd/workspace` đọc config; `infra/internal/workspace` ghép component;
storage và workload có owner riêng trong workspace, network được consume.

Đọc docs/DECISIONS.md và docs/CONTRACTS.md. Kiểm tra từ infra:
`gofmt -l .`, `go mod tidy -diff`, `go vet ./...`, `go build ./...`, `go test ./...`.
Mocks không chứng minh preview, cloud connectivity hoặc migration thành công.
App là module scope-control riêng, không phải image runtime và không build nó.

## Dùng lại component Workspace

`infra/internal/workspace.New(ctx, name, args, opts...)` ghép storage và workload
qua Args cụ thể. Component không đọc stack config. Composition root
`infra/cmd/workspace` đọc namespace `workspace` và dùng `environment` làm
logical name; tên stack không quyết định tên component. Khi dùng trong một
composition root khác của module `infra`, truyền name ổn định và các giá trị từ
contract của môi trường đó.

| Config ở root | Args | Ý nghĩa |
| --- | --- | --- |
| `workspace:environment` | `Environment` | Tag `Environment`; root dùng làm logical name |
| `workspace:region` | `Region` | Region cho provider và container logs |
| `workspace:storagePrefix` | `StoragePrefix` | Truyền xuống `storage.Args.BucketPrefix`; giữ S3 auto-naming |
| `workspace:desiredCount` | `ReplicaCount` | Số task ECS, phải lớn hơn 0; giữ config key đã lưu |
| `workspace:image` | `Image` | Image do app team cấp, truyền qua Pulumi Input |
| `workspace:vpcId` | `VpcID` | VPC ngoài workspace, chỉ consume |
| `workspace:subnetIds` | `SubnetIDs` | List refs subnet ngoài, giữ nguyên thứ tự và truyền tất cả vào service |
| `workspace:subnetId` | `SubnetIDs` | Tương thích legacy: một ref khi không có `subnetIds` |
| `workspace:peerCidr` | `PeerCIDR` | CIDR được ingress TCP tới port 8080 |
| `workspace:outboundHttpsCidr` | `OutboundHTTPSCIDR` (`netip.Prefix`) | Bắt buộc với UAT: đích IPv4 cho outbound TCP 443; NonProd không đọc khóa này |

Environment, region và storage prefix phải khác rỗng. `BucketName` và
`ServiceName` là Pulumi StringOutput, được đăng ký trên component và export ở
root thành `bucketName` / `serviceName`; giữ Output khi nối với consumer tiếp theo.

Go API D3a dùng `workspace.Args.ReplicaCount` và `workload.Args.ReplicaCount`,
cùng kiểu `int`; field `DesiredCount` cũ đã được loại bỏ khỏi hai Args này.
Caller Go chuyển field sang `ReplicaCount`. Config đã lưu và hai target examples
tiếp tục dùng `workspace:desiredCount`; không đổi thành `workspace:replicaCount`.
Root đọc `desiredCount`, truyền qua hai capability bằng `ReplicaCount`, rồi
workload map vào `ecs.ServiceArgs.DesiredCount`. NonProd giữ 1 task, UAT giữ 2.
Riêng D3a là đổi Go identifier, không đổi identity tài nguyên của cả hai target;
không cần aliases hay migration Pulumi và không dự kiến replacement/deletion.

Ví dụ Go cho UAT từ contract offline (dùng trong module `infra`):

```go
result, err := workspace.New(ctx, "uat", &workspace.Args{
    Environment:   "uat",
    Region:        "ap-southeast-1",
    StoragePrefix: "xbrain-uat-uploads-",
    ReplicaCount:  2,
    Image:         pulumi.String("fixture.invalid/api@sha256:" + strings.Repeat("a", 64)),
    VpcID:         pulumi.String("fixture-vpc-uat"),
    SubnetIDs: pulumi.StringArray{
        pulumi.String("fixture-subnet-uat-a"),
        pulumi.String("fixture-subnet-uat-b"),
    },
    PeerCIDR:          "10.30.0.0/16",
    OutboundHTTPSCIDR: netip.MustParsePrefix("10.42.0.0/24"),
})
if err != nil {
    return err
}
ctx.Export("bucketName", result.BucketName)
ctx.Export("serviceName", result.ServiceName)
```

Ví dụ cần import `net/netip`, `strings`, `github.com/pulumi/pulumi/sdk/v3/go/pulumi` và
`xbrain.local/daily/internal/workspace`. Region trong ví dụ là fixture test.
Theo [contract](docs/CONTRACTS.md), NonProd dùng environment/name `nonprod`,
prefix `xbrain-nonprod-uploads-`, desired count 1; UAT dùng `uat`,
`xbrain-uat-uploads-`, desired count 2. Cả hai giữ tag `Team=xbrain`, retention
7 ngày, port 8080, health `/health`, Fargate 256 CPU/512 MiB và wiring logs.
UAT đã có target config được kiểm tra qua root ở mức offline; chưa deploy cloud.
Mỗi môi trường vẫn phải nhận refs mạng live và image live trước khi triển khai;
fixture không dùng trên AWS.

## Supply config cho hai target

Checkpoint D2 nối tiếp D1r2 trong repo này. [Contract gốc](docs/CONTRACTS.md)
giữ nguyên; refs UAT và dạng list dưới đây là input D2 được cấp cho ticket.
Hai file mẫu nằm cạnh composition root, trong thư mục `examples`:

| Target | File mẫu | VPC ngoài | Subnet refs |
| --- | --- | --- | --- |
| NonProd | [Pulumi.nonprod.yaml](infra/cmd/workspace/examples/Pulumi.nonprod.yaml) | `fixture-vpc` | Legacy `workspace:subnetId: fixture-subnet-a` |
| UAT | [Pulumi.uat.yaml](infra/cmd/workspace/examples/Pulumi.uat.yaml) | `fixture-vpc-uat` | List `fixture-subnet-uat-a`, `fixture-subnet-uat-b` |

Mỗi file cấp đủ environment, region, storagePrefix, desiredCount, vpcId, image
và peerCidr; image chứa digest gồm đúng 64 ký tự `a`. Không có backend, cloud
identity hay secret trong mẫu. Root chọn logical workspace từ environment:
NonProd là `nonprod`, UAT là `uat`, độc lập tên stack; không cần thêm registry
hoặc target flag.

Để supply refs D2, giữ `workspace:vpcId` và subnet legacy trong mẫu NonProd.
Mẫu UAT dùng đúng YAML list sau, không phải chuỗi ghép bằng dấu phẩy:

```yaml
workspace:vpcId: fixture-vpc-uat
workspace:subnetIds:
  - fixture-subnet-uat-a
  - fixture-subnet-uat-b
workspace:outboundHttpsCidr: 10.42.0.0/24
```

Khi root nhận config, `subnetIds` được ưu tiên nếu có cả hai khóa; `subnetId`
chỉ là fallback khi `subnetIds` vắng mặt. List rỗng, null, sai kiểu, JSON không
hợp lệ hoặc ref trắng trả lỗi trước khi đăng ký tài nguyên workspace; không
fallback âm thầm sang mạng legacy. Thiếu cả hai khóa hoặc legacy trắng cũng
trả lỗi. VPC/subnet chỉ đi qua Args thành inputs SG/service, không lookup hay
nhận ownership mạng.

Ở mức offline, chạy `go test ./cmd/workspace -run TestTargetExamples -v` từ
`infra`: tests đọc chính hai file mẫu bằng parser stack YAML của SDK đã pin,
đưa config vào Pulumi context mock và gọi cùng `run` mà `main` sử dụng.
Đây là kiểm chứng target root/config, không chỉ constructor. Các file trong
`examples` không tự trở thành stack đang chọn. Khi tích hợp với runtime được
cấp riêng, nội dung mẫu cấu hình được supply qua file `Pulumi.<stack>.yaml`
cạnh `Pulumi.yaml`, giữ environment/name ổn định và thay fixture bằng refs
live do network/app team cấp. Ticket này chỉ đọc mẫu trong tests; không tạo
stack, ghi config đang hoạt động hay chạy lệnh Pulumi.

Giữ retention 7 ngày cho cả hai target và public-IP mode bật. NonProd giữ egress
lab mọi protocol tới `0.0.0.0/0`; UAT dùng một rule TCP 443 tới `10.42.0.0/24`
theo D5. Bucket public-access blocks, execution/log policy và Outputs
giữ nguyên D1r2; không áp dụng retention 14/30 từ thử nghiệm khác.

Workspace sở hữu provider `<name>-aws` ở stack root, bucket và public-access
block, SG, logs, execution role/policy, ECS cluster/task/service. Child components
`<name>-object-store` và `<name>-workload` có parent là Workspace; tài nguyên có
parent là component tương ứng và kế thừa provider. VPC/subnet không được tạo,
đọc lookup hay import. Caller options được truyền vào đăng ký Workspace;
giữ provider do Workspace sở hữu theo [quyết định](docs/DECISIONS.md).

Giữ environment/name, region, prefix và config examples của NonProd/UAT.
Workspace, workload và provider giữ logical names cùng type tokens, quan hệ
parent và ownership; bucket vẫn dùng `BucketPrefix`, không có physical name cố
định. D3b đổi ba logical names của storage và có alias coverage như dưới đây.
Đổi environment/name, parent, region hay prefix ngoài phạm vi này cần đánh giá
migration riêng. Chưa có observed preview hoặc kiểm chứng cloud.

## Migration logical names D3b

Với `<workspace>` là `nonprod` hoặc `uat`, chỉ ba registrations này đổi tên:

| Resource | Tên logical D3a | Tên logical D3b | Coverage identity cũ |
| --- | --- | --- | --- |
| Storage (`xbrain:storage:Storage`) | `<workspace>-storage` | `<workspace>-object-store` | Alias Name về component cũ |
| Bucket (`aws:s3/bucket:Bucket`) | `<workspace>-storage-uploads` | `<workspace>-object-store-uploads` | Kế thừa alias parent và thay name prefix |
| PublicAccessBlock (`aws:s3/bucketPublicAccessBlock:BucketPublicAccessBlock`) | `<workspace>-storage-uploads-access` | `<workspace>-object-store-uploads-access` | Kế thừa alias parent và thay name prefix |

`workspace.New` truyền `pulumi.Aliases([]pulumi.Alias{{Name:
pulumi.String(name + "-storage")}})` vào storage component mới. Alias để mặc
định type, parent, project và stack hiện tại. Component vẫn là con của Workspace;
bucket và public-access block vẫn là con của storage, có tên bắt đầu bằng đúng
tên component mới. Theo [tài liệu aliases chính thức](https://www.pulumi.com/docs/iac/concepts/resources/options/aliases/),
parent alias được kế thừa xuống children, bao gồm thay name prefix khi child
name bắt đầu bằng parent name. Quy tắc này cũng có trong SDK Go v3.263.0 đang
pin (`inheritedChildAlias`); vì vậy component alias bao phủ cả hai child identities
cũ mà không cần khai báo alias riêng ở từng child.

Mười registrations còn lại giữ nguyên tên/type/parent/provider: Workspace,
provider `<workspace>-aws`, workload component, logs, execution role, log policy,
SG, ECS cluster/task/service. Trong D3b, properties và provider scope giữ nguyên;
D5 chỉ đổi egress của SG UAT như mục kết nối bên dưới. Public
access block vẫn nhận `bucket.ID()`; `BucketName` tiếp tục lấy `bucket.Bucket`
qua storage rồi Workspace và root export. `ServiceName` cùng wiring workload
không đổi. Giữ `ReplicaCount int`, persisted key `workspace:desiredCount`,
capacity 1/2, retention 7 và network contract D2.

Mục đích migration là nhận diện bucket đang có và giữ dữ liệu, không tạo
replacement chỉ vì đổi logical names. Không đổi `BucketPrefix` hay tags, không
đổi policy physical naming và không thêm resource thay thế/import. Theo source
và alias declarations, không dự kiến replacement/deletion do rename này.
Đây chưa phải kết quả migration engine hoặc observed preview.

Kiểm chứng offline đọc alias declaration trên component và kiểm tra name prefix,
parent/type của hai children cho cả target. SDK mock monitor mặc định hỗ trợ
alias specs nhưng không resolve inheritance hoặc match state. Tests không dùng
alias để gán lại physical ID cũ. ID/bucket name do mocks sinh từ tên logical mới
chỉ là giá trị giả để kiểm tra Output/reference wiring, không chứng minh physical
bucket name đã đổi hay bucket/dữ liệu cũ đã được giữ.

Giữ aliases trong source đến khi việc migration trên mọi stack liên quan đã được
xác nhận riêng bằng runtime/state thật. Khi backend, cloud identity và live refs
được cấp cho một track khác, cần đối chiếu plan có match cả ba identities cũ,
không replace/delete bucket chỉ vì rename, và kiểm tra physical ID/dữ liệu sau
migration. Ticket này không đọc state, chạy preview hay thực hiện migration.

## Kết nối HTTPS UAT D5

Theo [contract D5](docs/D5-NETWORK-CONTRACT.md), root đọc
`workspace:outboundHttpsCidr` từ mẫu UAT đã cấp. Root parse thành `netip.Prefix`,
chuẩn hóa host bits bằng `Masked()` và truyền `OutboundHTTPSCIDR` qua
`workspace.Args` tới `workload.Args`. UAT thiếu khóa, rỗng, sai CIDR, IPv6
hoặc IPv4 `/0` trả lỗi trước khi gọi tạo Workspace. Workspace cũng kiểm tra
prefix khi caller Go gọi trực tiếp; package con không đọc config.

UAT thay egress rộng bằng đúng một rule TCP, from/to port 443, một đích IPv4
`10.42.0.0/24`. `peerCidr` vẫn chỉ cấp ingress TCP 8080 từ `10.30.0.0/16`.
NonProd không cần key mới, root bỏ qua key này nếu được cấp và Workspace
giữ egress rộng của NonProd; caller NonProd có thể để `OutboundHTTPSCIDR`
là zero value. Không đổi identity, parent, provider, Outputs hay aliases storage.

Trong phạm vi mạng, Workspace sở hữu SG của workload và consume VPC/subnet refs. Network team
sở hữu shared VPC/subnets, routes hai chiều, TGW/peer và policy phía peer;
ticket này không tạo, lookup, import hoặc sửa những tài nguyên đó. Rule SG
UAT không chứng minh traffic tới peer hoặc image pull được. Trước kiểm tra kết
nối thật, owner hạ tầng cần backend/state, identity đúng target và quyền provision;
network team cần cấp refs live, xác nhận routes hai chiều và policy peer cho HTTPS;
app/ops team cần image pull được, endpoint và probe thích hợp. Việc supply và
kiểm tra này thuộc track có quyền riêng. Chưa có bằng chứng connectivity, DNS,
route hiệu lực, TGW/cross-account hoặc cloud plan từ fixture offline.

## Kiểm chứng offline

Trong PowerShell, từ thư mục `infra`, dùng dependency/toolchain đã có sẵn để
không tải mạng:

```powershell
$env:GOTOOLCHAIN = 'local'
$env:GOPROXY = 'off'
$env:GOSUMDB = 'off'
gofmt -l .
go mod tidy -diff
go vet ./...
go build ./...
go test ./...
```

`TestWorkspaceContracts` kiểm tra cả NonProd và UAT với image biết trước và
unknown-image DryRun: đủ 13 registrations, inventory/identity,
parent/provider, prefix, tags, capacity, Outputs, mạng ngoài, container và quyền
ghi log nối từ LogGroup Output. DryRun đọc raw registration RPC với
`KeepUnknowns` để kiểm tra container definitions vẫn unknown; registration
task/service không nằm trong callback phụ thuộc image. Đây là chế độ SDK mock
DryRun, không phải chạy Pulumi preview. Các kiểm tra dùng
`CheckStorageAliasCoverage` chỉ chứng minh declarations và điều kiện inheritance.
`TestTargetExamples` đọc hai mẫu và chạy root
với tên stack độc lập, kiểm tra identity/parent/provider, tags, region, prefix,
capacity, VPC/subnets riêng, ingress/egress từng target, image và Outputs.
`TestReplicaCountAPI` kiểm tra
field mới là int và field Go cũ đã loại bỏ ở cả hai Args.
`TestPersistedCapacityConfig` chạy root cho cả hai target, xác nhận config
`workspace:desiredCount` quyết định capacity ngay cả khi có khóa
`workspace:replicaCount` khác giá trị. `TestSubnetConfigCompatibility`
kiểm tra ưu tiên list và config lỗi trước registration. `TestOutboundHTTPSConfig`
chạy root với input UAT thiếu/sai CIDR trước registration, chuẩn hóa host bits,
kiểm tra prefix thực sự đi từ config tới SG và NonProd bỏ qua key mới.
`TestUATRequiresOutboundHTTPSPrefix` kiểm tra guard cho caller Go trực tiếp.
Test known/unknown image cũng kiểm tra chính xác toàn bộ ingress/egress để
không thêm destination, IPv6 hay protocol/port. Mocks từ chối provider invoke;
tests chỉ dùng giá trị fixture. Các check này không chứng minh preview,
image pull, connectivity hay migration thành công.

## Manual preview D4

Entry PR-origin revision dùng manual dispatch và chỉ chọn NonProd với backend
label mock cố định. [Hướng dẫn vận hành D4](docs/D4-OPERATIONS.md) mô tả nguyên
nhân mismatch target trong log synthetic, local regression checks, control
secret-transform và owner/inputs cần bàn giao để kiểm chứng CI thật. Luồng deploy
manual có approval giữ riêng; local stub execution không phải observed preview.

## Vận hành và bàn giao D6

[OPERATIONS](docs/OPERATIONS.md) đối chiếu observation retention mô phỏng với
declared policy, mô tả reconcile có owner cùng giới hạn rollback dữ liệu và phân
tích NAT/N-1 đang pending. [HANDOFF](docs/HANDOFF.md) ghi contract D5 được giữ,
local evidence mới nhất, checks skipped và inputs/quyền cần cho người tiếp quản.
