# Vận hành và đối chiếu drift D6

D6 tiếp nối source D5 đã được chấp nhận. Phạm vi hiện tại chỉ offline trong
repository này, theo [review D6](review-d6.md), [quyết định lab](DECISIONS.md),
[contract gốc](CONTRACTS.md), [network D5](D5-NETWORK-CONTRACT.md) và
[delivery D4](D4-DELIVERY.md). Không có backend/state, identity hoặc manifest
live được cấp. Các mô tả dưới đây về reconcile là đề xuất cho track được cấp
quyền sau này; chưa thực hiện read, plan, refresh hoặc apply.

## Chẩn đoán và nguồn bằng chứng

| Nguồn | Điều được biết | Giới hạn |
| --- | --- | --- |
| [synthetic-drift-d6.json](synthetic-drift-d6.json) | Fixture do controller viết, track `synthetic-offline`: LogGroup `nonprod-workload-logs`, type `aws:cloudwatch/logGroup:LogGroup`, observation `retentionInDays=14` | Không phải AWS read, state export, preview hoặc refresh; câu chuyện operator thay đổi sau release cũng là mô phỏng |
| [workload.go](../infra/internal/workload/workload.go) | `New` khai báo `RetentionInDays: pulumi.Int(7)` cho `<workspace>-workload-logs`; không có retention config hoặc nhánh theo target | Source thể hiện intent, không xác nhận giá trị cloud |
| [workspace.go](../infra/internal/workspace/workspace.go) và [root](../infra/cmd/workspace/main.go) | Root → Workspace → Workload; Workspace sở hữu provider `<workspace>-aws` ở stack root; LogGroup là con Workload, kế thừa provider | Logical name trong fixture chưa đủ để xác định stack/project/physical identity live |
| [root tests](../infra/cmd/workspace/main_test.go) | Đọc chính hai YAML examples, gọi `run`, kiểm tra retention 7 và inventory/ownership/config | SDK mocks, không đọc stack/state/backend đang hoạt động |
| [component tests](../infra/internal/workspace/workspace_test.go) | Cả NonProd/UAT, image known và unknown DryRun: đủ 13 registrations, retention 7, Output wiring, parents/providers, storage alias declarations | Mock trả ID/reference giả, không resolve aliases, không thực thi migration hoặc truy cập cloud |

Finding D6 là chênh lệch **fixture 14 so với declared 7**. Nếu cùng resource
live thật sự có giá trị 14, đó là candidate drift cần kiểm chứng. Fixture không
chứng minh tác nhân, thời điểm, revision đã deploy hay việc tài nguyên tồn tại.
Không sửa source thành 14 hoặc sửa observation để làm hai bên khớp. D6 chỉ thêm
comment giải thích policy retention trong Go và tài liệu; tests/config không đổi.

## Reconcile dự kiến khi được cấp manifest và quyền live

1. Owner hạ tầng chỉ định operator và owner backend/state; nhận manifest đã duyệt
   gồm target NonProd, project/stack/backend, region, exact source revision và
   config tương ứng. Đối chiếu identity LogGroup đầy đủ cùng parent/provider và
   mapping physical resource trong kênh được phép; không suy ra từ logical name
   trong fixture. Không đưa identifiers nhạy cảm, state hoặc secret vào repo/log.
2. Operator được cấp quyền read/plan xác nhận retention hiện tại của đúng
   LogGroup, thời điểm và nguồn thay đổi từ bằng chứng live phù hợp. Phân biệt
   declared source, state snapshot và cloud observation; không dùng refresh như
   một cách mặc nhiên sửa cloud hoặc biến observation thành policy mới.
3. Owner policy/logs xác nhận policy vẫn là 7 ngày. Trước bất kỳ giảm retention,
   xác định dữ liệu 7–14 ngày còn cần giữ, yêu cầu bảo toàn và nơi lưu được duyệt;
   nếu cần, owner có quyền phải bảo toàn và kiểm tra dữ liệu trước khi thay đổi.
   Chưa có quyền, bằng chứng bảo toàn hoặc approval thì dừng ở proposal.
4. Trong track riêng được cấp quyền, owner delivery chuẩn bị plan của exact
   revision/config/target đã kiểm chứng. Nếu live đúng là 14 và policy vẫn 7,
   intent là cập nhật retention 14 → 7 trên LogGroup hiện có. Theo source D6
   không có đổi identity hoặc yêu cầu replacement/deletion; chỉ plan live mới
   xác nhận engine/provider sẽ làm gì. Dừng nếu plan có replacement/deletion,
   thay resource ngoài scope, target sai hoặc không match identity.
5. Sau review plan và approval của luồng deploy riêng, operator có quyền mới
   reconcile. Xác minh lại retention 7, đúng identity, workload tiếp tục ghi log,
   không có thay đổi ngoài phạm vi; lưu evidence đã lọc theo quy định của owner.
   Mismatch live đã hết mới được đóng drift. Không đánh dấu resolved bằng mock.

Giảm retention từ 14 về 7 có thể làm dữ liệu cũ hơn policy mới bị xóa. Không cam
kết thời điểm xóa hay khả năng khôi phục từ fixture. Đặt lại 14 sau đó hoặc revert
Git không khôi phục log đã bị xóa. Khi có sự cố, dừng thay đổi tiếp, giữ evidence
và gọi owner policy/logs cùng operator; phương án tăng retention tạm thời hoặc
restore từ bản bảo toàn phải được duyệt riêng. Không có bản bảo toàn đã kiểm tra
thì không có cam kết rollback dữ liệu. Ticket này không đổi retention hay state.

## Regional NAT — pending

Đây là phương án đang chờ quyết định, chưa phải kiến trúc được chọn. Cần làm rõ
“Regional NAT” là dịch vụ/topology nào và có phù hợp region cùng SDK/provider
đang pin hay không; ticket này không xác nhận support hoặc giá hiện hành.
Network team sở hữu shared VPC/subnets, routes, TGW/peer và policy phía peer.
Workspace không tự tạo/import NAT, sửa route hoặc nhận ownership mạng dùng chung.

Tác động cần đánh giá gồm đường outbound, nguồn IP thấy ở peer, routing hai
chiều, DNS/endpoints, failure domains/failover, thông lượng và giới hạn kết nối,
chi phí cố định/xử lý dữ liệu/đường truyền cùng blast radius với consumers khác.
NAT không tự mở thêm quyền SG hoặc peer firewall. Rule UAT vẫn chỉ TCP 443 tới
`10.42.0.0/24`; NAT không chứng minh peer route hay image pull được. Hiện service
cả hai target vẫn `assignPublicIp=true`; không tự chuyển sang private-only.

Trước quyết định cần topology và subnet/AZ/route mappings live, nhu cầu destinations
(peer, image/logs), traffic/cost estimate, SLO availability, mô hình failover,
owner ngân sách/thiết kế và phê duyệt network change. Network owner cần quyền
quản lý tài nguyên/route thuộc họ; infra/delivery owner cần manifest và quyền
read/plan/deploy đúng scope riêng. Thử nghiệm tương lai phải xác nhận đường đi,
nguồn IP, khả năng pull/log/HTTPS và rollback route do network owner thực hiện.
Nếu design yêu cầu đổi public-IP mode hoặc SG, phải duyệt contract mới trước.
Chưa có các inputs/quyền này: giữ nguyên D5, không triển khai NAT.

## N-1 capacity — pending

Giữ `workspace.Args.ReplicaCount` và `workload.Args.ReplicaCount` kiểu `int`;
root vẫn đọc persisted `workspace:desiredCount` → `ecs.ServiceArgs.DesiredCount`.
Examples hiện tại NonProd 1, UAT 2. Không thêm config key, autoscaling, placement
rule hoặc đổi capacity trong D6.

Nếu N nghĩa là số task chạy và chỉ mất một task, phép tính minh họa để lại 0 task
ở NonProd hoặc 1 task ở UAT. Đây không phải kết quả load/failure test hay bảo đảm
SLO: mất một AZ/domain có thể mất nhiều task, hai subnet refs không chứng minh
khác AZ hoặc phân bố task. Khả năng của task còn lại chưa được đo.

Cần owner app/ops cấp SLO, traffic peak, capacity mỗi task, CPU/memory và latency
budget, cold start/recovery time; network/infra owner cấp failure-domain mapping,
placement thực tế, service quotas và dependency bottlenecks. Owner capacity
cần chốt N là task hay domain, load còn phải chịu khi mất domain, surge khi rollout,
giá trị desiredCount được duyệt và ngân sách. Trong mô hình task độc lập giản lược,
cần chứng minh `(N-1) × capacity khả dụng mỗi task` đáp ứng tải/SLO với headroom;
mô hình domain phải tính phần capacity mất theo domain thực tế.

Kiểm chứng sau này cần image/probe và quyền chạy load/failure test cùng quyền
thay config/deploy qua approval hiện có. Rollback capacity cũng cần kế hoạch
tránh giảm service dưới tải; chưa duyệt con số hoặc phạm vi thử nghiệm thì không
thực hiện. Task hiện giữ CPU256/memory512, port8080, health `/health`, log7.

## Kiểm chứng local và phần chưa chạy

Từ thư mục `infra`, dùng toolchain/dependencies đã có, không tải mạng:

```powershell
$env:GOTOOLCHAIN = 'local'
$env:GOPROXY = 'off'
$env:GOSUMDB = 'off'
gofmt -l .
go mod tidy -diff
go vet ./...
go build ./...
go test ./... -count=1 -v
```

Kết quả lần chạy D6 được ghi trong [HANDOFF](HANDOFF.md), không kế thừa pass từ
checkpoint cũ. Không thêm test phản chiếu comment; dùng regression tests có sẵn
để bảo vệ behavior/config/identity. Check source trước/sau xác nhận Go chỉ thêm
comment đã duyệt, config/dependencies/delivery và tests không đổi.

Preview/refresh/apply, cloud/state/auth/config commands, CI dispatch và kiểm tra
kết nối/load/failure live đều skipped vì track offline chưa cấp quyền/identity.
Delivery D4 chỉ đọc source: PR-origin entry vẫn manual, fixed NonProd và backend
label `fixture-backend-nonprod`, exact revision đi qua input/checkout/entry/trace;
label không phải backend live. Không chạy entry/stub hoặc Python delivery tests
vì chúng gọi native child CLI. Deploy manual có approval là contract giữ riêng;
không có run CI/approval live được kiểm chứng. Pack/control/app không đổi nên
không chạy check của chúng. Không commit/push hay tự bootstrap identity.
