# Bàn giao D6 — tiếp nối accepted D5

Người tiếp quản chỉ cần repository này. Bắt đầu từ [AGENTS](../AGENTS.md),
[skill Pulumi](../.agents/skills/pulumi/SKILL.md), [review D6](review-d6.md) và
[OPERATIONS](OPERATIONS.md). Các contract [gốc](CONTRACTS.md),
[delivery D4](D4-DELIVERY.md) và [network D5](D5-NETWORK-CONTRACT.md) là input
chỉ đọc. DECISIONS/CONTRACTS ghi bối cảnh ban đầu; checkpoint hiện tại D5 được
thể hiện ở source, examples và [README](../README.md), gồm UAT và aliases D3b.

## Kết quả và patch được giao

Observation [synthetic-drift-d6.json](synthetic-drift-d6.json) là fixture controller,
không phải cloud/state read hoặc CI release. Nó ghi LogGroup
`nonprod-workload-logs` retention 14; workload source khai báo retention 7 cho
cả NonProd/UAT. Mismatch chỉ được xác nhận giữa fixture và declared source;
chưa có drift live hoặc tác nhân thay đổi được xác nhận. Không sửa fixture hay
retention để che mismatch.

Hai review comment đã duyệt được thực hiện bằng comment tiếng Việt không dấu
tại tạo LogGroup trong `infra/internal/workload/workload.go` và hai tài liệu
OPERATIONS/HANDOFF tiếng Việt có dấu. Go chỉ thêm comment; API, logic và tests
giữ nguyên. D6 không có migration identity hoặc thay đổi deployment; theo source
không dự kiến replacement/deletion do patch này, chưa có observed plan.

## Các contract tiếp tục giữ

| Phạm vi | Source/config hiện tại |
| --- | --- |
| Root và Go API | `infra/cmd/workspace/run` đọc config namespace `workspace`; environment quyết định logical workspace. `ReplicaCount int` qua Workspace/Workload, persisted key vẫn `workspace:desiredCount` |
| NonProd example | `nonprod`, region `ap-southeast-1`, prefix `xbrain-nonprod-uploads-`, capacity 1, VPC `fixture-vpc`, legacy `subnetId=fixture-subnet-a`, broad IPv4 egress mọi protocol |
| UAT example | `uat`, cùng region, prefix `xbrain-uat-uploads-`, capacity 2, VPC `fixture-vpc-uat`, `subnetIds=[fixture-subnet-uat-a,fixture-subnet-uat-b]`; root validate `outboundHttpsCidr`, UAT chỉ TCP443 tới `10.42.0.0/24` |
| Workload | Ingress TCP8080 từ `10.30.0.0/16`, public-IP mode bật, CPU256/memory512, health `/health`, retention7, image offline `fixture.invalid/api@sha256:` cộng 64 ký tự `a`; không pull/build app |
| Ownership/identity | Workspace sở hữu provider `<workspace>-aws` ở stack root; storage/workload là con Workspace, resources con kế thừa provider. Shared VPC/subnets/routes/TGW/peer thuộc network team, chỉ consume refs |
| Storage/Outputs | `<workspace>-object-store` cùng children uploads/access, alias component về `<workspace>-storage` và inherited child coverage; BucketPrefix auto-name/public-access blocks không đổi. Root exports `bucketName`/`serviceName`; Output/log-policy wiring không đổi |
| Delivery | D4 manual PR-origin preview fixture chỉ NonProd/backend label cố định, giữ exact revision; deploy manual approval là luồng riêng. Không thêm auto PR trigger, đổi gates hoặc bootstrap quyền |

## Evidence D6

Đã chạy mới trong D6, trên Go files cuối, từ module `infra` với
`GOTOOLCHAIN=local`, `GOPROXY=off`, `GOSUMDB=off`:

| Check đã chạy | Kết quả quan sát local |
| --- | --- |
| `gofmt -l .` | Exit 0, không có file cần format |
| `go mod tidy -diff` | Exit 0, không có dependency diff |
| `go vet ./...` | Exit 0 |
| `go build ./...` | Exit 0, chỉ module hạ tầng |
| `go test ./... -count=1 -v` | Exit 0; `cmd/workspace` pass 0.161s, `internal/workspace` pass 0.124s; storage/testutil/workload không có test riêng |
| So sánh source đầu/cuối D6 | 17 files Go/config/dependencies/delivery được đối chiếu SHA256; chỉ workload.go đổi. Bỏ đúng hai dòng comment mới thì nội dung workload.go bằng baseline, không đổi logic |
| Parse fixture và links bằng PowerShell built-ins | JSON đúng track/resource/retention fixture14; 31 local links trong README/OPERATIONS/HANDOFF có đích tồn tại |

Tests đã thực sự chạy gồm root với hai examples, persisted desiredCount,
subnet compatibility, outbound input thiếu/sai/forwarding, Go API ReplicaCount,
known/unknown-image DryRun và UAT direct-Args guard. Cả hai target giữ đủ 13
registrations với retention7; kiểm tra names/types/parents/provider/Outputs và
storage alias declarations. Đây là observed **local mock registrations**, không
phải observed cloud hoặc state reconciliation.

Review final docs/source theo skill: **pass**, không có finding cần sửa từ
`pulumi-component-reviewer` (contract/ownership, NAT/N-1 pending) và
`pulumi-delivery-reviewer` (reconcile/state, retention loss/rollback, delivery gates).
Reviewers chỉ đọc files; checks do primary chạy. Pass chỉ bao phủ source/docs
offline, không xác nhận integration live hoặc cấp quyền hành động. Quy trình chạy và skipped scope ở
[OPERATIONS](OPERATIONS.md). Preview/refresh/apply, cloud/state/auth/config,
CI dispatch và live connectivity/load/failure tests skipped vì offline/chưa cấp
quyền. Entry/stub và Python delivery tests skipped vì gọi native child CLI;
delivery chỉ được đối chiếu source. Pack/control/app không đổi nên không chạy
checks của các scope đó. Không có cloud result, deployment approval hoặc dữ
liệu secret thật được lấy trong D6.

## Owner, inputs và bước tiếp quản

| Owner cần chỉ định | Inputs/quyền còn thiếu và hành động tiếp theo |
| --- | --- |
| Infra/reconciliation owner | Manifest live đầy đủ project/stack/backend/region/target/revision/config và mapping LogGroup; quyền read/plan riêng. Xác nhận candidate drift cùng identity trước đề xuất restore policy7 |
| Policy/logs owner | Xác nhận retention7 vẫn được duyệt, yêu cầu giữ log 7–14 ngày và bản bảo toàn đã kiểm tra trước giảm retention; approval data-risk và recovery limits |
| Backend/state owner | Backend thật, scope/access/locking/encryption/recovery; label fixture không cấp các yếu tố này. Không đưa state/identifiers nhạy cảm vào handoff |
| Delivery/cloud identity owner | Run CI đáng tin cậy của exact revision, quyền read/plan theo target và deploy identity/approval riêng. Plan review trước reconcile; xác minh retention và log delivery sau hành động được duyệt |
| Network owner | Topology/refs live, routes hai chiều, peer HTTPS policy; quyết định và quyền với shared network/NAT. Workspace không quản lý thay họ |
| App/ops/capacity owner | Image pull được, endpoint/probe, SLO/load/failure-domain estimate, headroom và approved N-1 capacity; quyền thử nghiệm riêng |

Reconcile dự kiến là khôi phục retention7 trên đúng resource nếu bằng chứng live
xác nhận 14 và policy7 vẫn được duyệt. Approval apply chưa có; bước này chưa chạy.
Giảm retention có thể xóa log cũ; tăng lại retention hoặc revert Git không phục hồi
dữ liệu đã xóa. Xem các checkpoints bảo toàn/rollback và điều kiện dừng trong
OPERATIONS trước khi đề nghị hành động live.

Regional NAT **pending**: thiếu topology, định nghĩa dịch vụ/mô hình, support của
region/provider, quyết định cost/availability, owner và quyền shared network.
N-1 **pending**: thiếu SLO, failure-domain/placement, capacity estimate, load evidence
và giá trị được duyệt. Phân tích tác động có trong OPERATIONS; chưa triển khai cả
hai và giữ capacity NonProd1/UAT2, public-IP/egress hiện tại.

Chưa xác nhận cloud retention, route/DNS/connectivity, image pull, capacity/SLO,
preview/migration engine, physical IDs hoặc giữ dữ liệu storage. Mocks chỉ chứng
minh declarations/wiring/scope; aliases chưa được resolve với state. Người tiếp
quản cần track có quyền riêng để kiểm chứng integration; không tự bootstrap để
đóng ticket offline. Không commit/push, dispatch hoặc chạy native child CLI.
