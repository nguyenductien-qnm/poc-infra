# xbrain daily infrastructure lab

Repo kế thừa cho ticket bảo trì Pulumi Go. Đây là fixture offline, chưa deploy.
`infra/cmd/workspace` đọc config; `infra/internal/workspace` ghép component;
storage và workload có owner riêng trong workspace, network được consume.

Đọc docs/DECISIONS.md và docs/CONTRACTS.md. Kiểm tra từ infra:
`gofmt -l .`, `go mod tidy -diff`, `go vet ./...`, `go build ./...`, `go test ./...`.
Mocks không chứng minh preview, cloud connectivity hoặc migration thành công.
App là module scope-control riêng, không phải image runtime và không build nó.

## Dùng component workspace cho môi trường khác

`workspace.New` không gắn với NonProd. Mọi giá trị theo môi trường được đọc ở
`infra/cmd/workspace` từ namespace config `workspace` và truyền qua `workspace.Args`:

| Key | NonProd | UAT (chưa onboard) |
| --- | --- | --- |
| `environment` | `nonprod` | `uat` |
| `storagePrefix` | `xbrain-nonprod-uploads-` | `xbrain-uat-uploads-` |
| `desiredCount` | `1` | `2` |
| `region`, `image`, `vpcId`, `subnetId`, `peerCidr` | theo contract cấp riêng | theo contract cấp riêng |

- `environment` vừa là tag `Environment` vừa là logical name của component.
  NonProd phải giữ đúng `nonprod` để identity `nonprod`, `nonprod-aws`,
  `nonprod-storage`, `nonprod-workload` không đổi.
- `storagePrefix` được truyền vào `storage.Args.Prefix` và dùng làm
  `BucketPrefix` (auto-name), không đặt physical name cố định.
- VPC/subnet vẫn chỉ được consume qua contract mạng; không import hay tạo mới.
- Onboard môi trường mới cần stack, backend và contract mạng/image được cấp
  trước; repo này không tạo stack hay set config.

Kiểm tra offline cho cả hai cấu hình nằm trong
`infra/internal/workspace/workspace_test.go` (`TestExistingNonProd`, `TestUAT`).
