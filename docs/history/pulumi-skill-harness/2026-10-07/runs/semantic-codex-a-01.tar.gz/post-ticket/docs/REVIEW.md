# Rà soát archive

**Kết luận: pass trong phạm vi rà soát tài liệu và bằng chứng mock.** Tự đối chiếu theo `AGENTS.md`, kỹ năng Pulumi và `docs/DECISIONS.md`; sửa hai nhận định vượt quá bằng chứng, giữ hai bảo đảm chính xác. Chỉ cập nhật tài liệu này.

## Tham số không hợp lệ

- **Sửa — `NewLate`:** `KeepDays=0` bị từ chối sau khi `prepare` khai báo provider, component, bucket và cấu hình chặn truy cập công khai. `newAudit` mới kiểm tra tham số, nên không đăng ký LogGroup và không tới bước đăng ký outputs của component (`infra/archive/archive.go:29–39,50–77`). `TestLateRejectedInput` xác nhận lỗi và đúng bốn loại yêu cầu đăng ký, không phải danh mục rỗng (`infra/archive/archive_test.go:61–73`); log baseline cũng có bốn mục.
- **Giữ — `NewEarly`:** `KeepDays=0` bị từ chối tại điểm vào, trước mọi đăng ký do ứng dụng khai báo (`infra/archive/archive.go:21–25,43–47`). `TestEarlyRejectedInput` xác nhận lỗi và danh mục rỗng (`infra/archive/archive_test.go:76–83`); Stack ngầm của SDK được loại khỏi danh mục (`infra/archive/archive_test.go:29–36`).

## Quan hệ parent

- **Sửa — `TestSelectedParents`:** với `NewEarly`, `KeepDays=7`, test xác nhận có năm đăng ký nhưng chỉ kiểm tra parent của bucket và LogGroup là component archive, đồng thời yêu cầu đúng hai mục được kiểm tra. Parent của cấu hình chặn truy cập công khai, provider và component gốc không được assertion này kiểm tra (`infra/archive/archive_test.go:89–108`). Mã nguồn khai báo parent của hai tài nguyên được chọn tại `infra/archive/archive.go:59,77`.
- **Giữ — `TestCompleteFrozenParents`:** với cùng đầu vào, `reflect.DeepEqual` so sánh toàn bộ danh mục đã sắp xếp với năm bộ `(type, name, parent)` đóng băng: bucket, cấu hình chặn truy cập công khai và LogGroup thuộc component; component gốc và provider thuộc Stack (`infra/archive/archive_test.go:38–43,86–87,111–126`). Nguồn khai báo tại `infra/archive/archive.go:50–66,77`; baseline ghi nhận đầy đủ năm mục. Danh mục đã sắp xếp không chứng minh thứ tự thực thi đăng ký.

## Kết quả kiểm tra

Đã đối chiếu SHA-256 hiện tại của `infra/archive/archive.go`, `infra/archive/archive_test.go`, `infra/go.mod`, `infra/go.sum`: **4/4 khớp** `docs/baseline-checks.json:5–9`. Dùng bằng chứng chạy cục bộ thực thu ngày 06/10/2026 UTC; không chạy lại Go trong lượt rà soát này.

| Kiểm tra tại `infra` | Kết quả baseline |
| --- | --- |
| `gofmt -l .` | Mã thoát 0, không liệt kê tệp |
| `go mod tidy -diff` | Mã thoát 0, không có diff |
| `go vet ./...` | Mã thoát 0 |
| `go build ./...` | Mã thoát 0 |
| `go test -count=1 -v ./...` | Mã thoát 0; cả bốn test nêu trên PASS |

Nguồn kết quả: `docs/baseline-checks.json:14–97`; môi trường ghi nhận `GOPROXY=off`, `GOSUMDB=off`, `AWS_EC2_METADATA_DISABLED=true`. Thông báo kiểm tra tĩnh của gói kỹ năng không thay thế bằng chứng Go hoặc rà soát này.

## Phạm vi và điều chưa kiểm chứng

Module dùng tài nguyên AWS Go thật (provider v7.48.0, SDK v3.263.0); các test chạy qua `WithMocks` (`infra/archive/archive_test.go:45–58`). Recorder chỉ lưu type, name và parent của yêu cầu đăng ký; không tạo tài nguyên AWS. Các assertion chỉ bao phủ `KeepDays=0` và `7`, không xác nhận mọi giá trị dương được AWS chấp nhận, provider binding, thuộc tính cấu hình hay outputs.

Không có bằng chứng triển khai hoặc preview, không đọc state/backend hay giá trị bí mật; chưa xác định kế hoạch thay thế/xóa, drift hoặc trạng thái cloud. Go/mock PASS không bảo đảm kế hoạch không thay đổi. Mã nguồn, kiểm thử, module và thiết lập runtime được giữ nguyên.
