# xbrain daily infrastructure lab

Repo kế thừa cho ticket bảo trì Pulumi Go. Đây là fixture offline, chưa deploy.
`infra/cmd/workspace` đọc config; `infra/internal/workspace` ghép component;
storage và workload có owner riêng trong workspace, network được consume.

Đọc docs/DECISIONS.md và docs/CONTRACTS.md. Kiểm tra từ infra:
`gofmt -l .`, `go mod tidy -diff`, `go vet ./...`, `go build ./...`, `go test ./...`.
Mocks không chứng minh preview, cloud connectivity hoặc migration thành công.
App là module scope-control riêng, không phải image runtime và không build nó.

## Log retention

Retention của CloudWatch LogGroup cấu hình qua `workspace:logRetentionDays` ở
composition root, truyền qua `workspace.Args.LogRetentionDays` tới
`workload.Args.LogRetentionDays`. Không cấp hoặc `0` giữ mặc định 7 ngày
(NonProd); giá trị âm bị từ chối. UAT cấp `14`, consumer tương lai cấp giá trị
riêng (ví dụ `30`) qua cùng capability. Đổi retention chỉ cập nhật thuộc tính
`retentionInDays` của LogGroup `<workspace>-workload-logs`, không thay identity.
`go test ./...` có hồi quy cho 0/7/14/30 ngày, cấu hình UAT và giá trị âm.

Consumer tương lai cần 30 ngày không cần sửa Go: stack của consumer đặt
`workspace:logRetentionDays: 30` cùng các key bắt buộc khác của `workspace`
(environment, prefix riêng, capacity, network/image contract), rồi
`cmd/workspace` truyền giá trị qua `workspace.Args.LogRetentionDays`. Lưu ý
`cmd/workspace` hiện cố định logical name `nonprod`; consumer dùng root này trong
stack riêng sẽ có state riêng nhưng vẫn mang tên logical `nonprod-*`. Đổi tên đó
là thay đổi identity, cần quyết định riêng. Ticket này không tạo stack hay config
thật; `TestFutureConsumerRetention30` kiểm tra case này bằng mocks.
