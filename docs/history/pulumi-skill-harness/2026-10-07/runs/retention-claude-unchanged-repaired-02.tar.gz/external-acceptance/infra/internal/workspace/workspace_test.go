package workspace

import (
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
	"strings"
	"testing"
	"xbrain.local/daily/internal/testutil"
)

func NonProdArgs() *Args {
	return &Args{Environment: "nonprod", Region: "ap-southeast-1", StoragePrefix: "xbrain-nonprod-uploads-", DesiredCount: 1,
		Image: pulumi.String("fixture.invalid/api@sha256:" + strings.Repeat("a", 64)),
		VpcID: pulumi.String("fixture-vpc"), SubnetIDs: pulumi.StringArray{pulumi.String("fixture-subnet-a")}, PeerCIDR: "10.30.0.0/16"}
}

func TestExistingNonProd(t *testing.T) {
	mocks := &testutil.Mocks{}
	err := pulumi.RunErr(func(ctx *pulumi.Context) error {
		result, err := New(ctx, "nonprod", NonProdArgs())
		if err != nil {
			return err
		}
		ctx.Export("bucketName", result.BucketName)
		ctx.Export("serviceName", result.ServiceName)
		return nil
	}, pulumi.WithMocks("daily-workspace", "nonprod", mocks))
	if err != nil {
		t.Fatal(err)
	}
	seenBucket, seenService := false, false
	for _, item := range mocks.Resources() {
		switch item.TypeToken {
		case "aws:s3/bucket:Bucket":
			seenBucket = true
			if item.Name != "nonprod-storage-uploads" || item.Inputs["bucketPrefix"].StringValue() != "xbrain-nonprod-uploads-" {
				t.Fatal("existing bucket contract changed")
			}
			if item.RegisterRPC.GetParent() == "" || item.Provider == "" {
				t.Fatal("bucket must have parent/provider")
			}
		case "aws:ecs/service:Service":
			seenService = true
			if item.Inputs["desiredCount"].NumberValue() != 1 {
				t.Fatal("existing capacity changed")
			}
			network := item.Inputs["networkConfiguration"].ObjectValue()
			if network["subnets"].ArrayValue()[0].StringValue() != "fixture-subnet-a" {
				t.Fatal("external subnet not consumed")
			}
		case "aws:ec2/vpc:Vpc", "aws:ec2/subnet:Subnet":
			t.Fatal("workspace must not own external network")
		}
	}
	if !seenBucket || !seenService {
		t.Fatal("missing existing resources")
	}
}

// UATArgs la cau hinh thu hai hop le theo contract, chua onboard
func UATArgs() *Args {
	args := NonProdArgs()
	args.Environment, args.StoragePrefix, args.DesiredCount, args.LogRetentionDays = "uat", "xbrain-uat-uploads-", 2, 14
	return args
}

// runWorkspace chay workspace voi mocks va tra ve resource da dang ky
func runWorkspace(t *testing.T, name string, args *Args) []pulumi.MockResourceArgs {
	t.Helper()
	mocks := &testutil.Mocks{}
	err := pulumi.RunErr(func(ctx *pulumi.Context) error {
		_, err := New(ctx, name, args)
		return err
	}, pulumi.WithMocks("daily-workspace", name, mocks))
	if err != nil {
		t.Fatal(err)
	}
	return mocks.Resources()
}

func findResource(t *testing.T, resources []pulumi.MockResourceArgs, typeToken string) pulumi.MockResourceArgs {
	t.Helper()
	for _, item := range resources {
		if item.TypeToken == typeToken {
			return item
		}
	}
	t.Fatalf("missing resource %s", typeToken)
	return pulumi.MockResourceArgs{}
}

func TestLogRetention(t *testing.T) {
	cases := []struct {
		name      string
		retention int
		want      float64
	}{
		{"nonprod-unset-default", 0, 7},
		{"nonprod-explicit", 7, 7},
		{"uat", 14, 14},
		{"future-consumer", 30, 30},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			args := NonProdArgs()
			args.LogRetentionDays = tc.retention
			resources := runWorkspace(t, "nonprod", args)
			logs := findResource(t, resources, "aws:cloudwatch/logGroup:LogGroup")
			if got := logs.Inputs["retentionInDays"].NumberValue(); got != tc.want {
				t.Fatalf("retention = %v, want %v", got, tc.want)
			}
			// identity va ownership cua LogGroup khong doi
			workload := findResource(t, resources, "xbrain:workload:Workload")
			if logs.Name != "nonprod-workload-logs" || workload.Name != "nonprod-workload" {
				t.Fatalf("log group identity changed: %s / %s", logs.Name, workload.Name)
			}
			if !strings.HasSuffix(logs.RegisterRPC.GetParent(), "::nonprod-workload") || logs.Provider == "" {
				t.Fatal("log group must stay under workload with inherited provider")
			}
			// policy van sinh tu LogGroup Output
			policy := findResource(t, resources, "aws:iam/rolePolicy:RolePolicy")
			if !strings.Contains(policy.Inputs["policy"].StringValue(), "fixture-reference-nonprod-workload-logs:*") {
				t.Fatal("log policy must derive from log group output")
			}
		})
	}
}

func TestUATConsumer(t *testing.T) {
	resources := runWorkspace(t, "uat", UATArgs())
	logs := findResource(t, resources, "aws:cloudwatch/logGroup:LogGroup")
	if logs.Inputs["retentionInDays"].NumberValue() != 14 {
		t.Fatal("uat retention must be 14 days")
	}
	if logs.Inputs["tags"].ObjectValue()["Environment"].StringValue() != "uat" {
		t.Fatal("uat tags not applied")
	}
	bucket := findResource(t, resources, "aws:s3/bucket:Bucket")
	if bucket.Inputs["bucketPrefix"].StringValue() != "xbrain-uat-uploads-" {
		t.Fatal("uat storage prefix not applied")
	}
	service := findResource(t, resources, "aws:ecs/service:Service")
	if service.Inputs["desiredCount"].NumberValue() != 2 {
		t.Fatal("uat capacity not applied")
	}
	if service.Inputs["networkConfiguration"].ObjectValue()["subnets"].ArrayValue()[0].StringValue() != "fixture-subnet-a" {
		t.Fatal("external subnet not consumed")
	}
	for _, item := range resources {
		if item.TypeToken == "aws:ec2/vpc:Vpc" || item.TypeToken == "aws:ec2/subnet:Subnet" {
			t.Fatal("workspace must not own external network")
		}
	}
}

// consumer tuong lai cap 30 ngay qua cung capability, khong can code rieng
func TestFutureConsumerRetention30(t *testing.T) {
	args := NonProdArgs()
	args.Environment, args.StoragePrefix, args.LogRetentionDays = "future", "xbrain-future-uploads-", 30
	resources := runWorkspace(t, "future", args)
	logs := findResource(t, resources, "aws:cloudwatch/logGroup:LogGroup")
	if logs.Inputs["retentionInDays"].NumberValue() != 30 {
		t.Fatal("future consumer retention must be 30 days")
	}
	// identity sinh tu ten workspace cua consumer, khong dung chung voi nonprod
	if logs.Name != "future-workload-logs" || !strings.HasSuffix(logs.RegisterRPC.GetParent(), "::future-workload") || logs.Provider == "" {
		t.Fatal("future log group must be owned by its own workload with inherited provider")
	}
	policy := findResource(t, resources, "aws:iam/rolePolicy:RolePolicy")
	if !strings.Contains(policy.Inputs["policy"].StringValue(), "fixture-reference-future-workload-logs:*") {
		t.Fatal("log policy must derive from future log group output")
	}
	for _, item := range resources {
		if strings.HasPrefix(item.Name, "nonprod") {
			t.Fatalf("future consumer must not register nonprod resource %s", item.Name)
		}
	}
	// NonProd khong cap gia tri van giu 7 ngay
	nonprod := findResource(t, runWorkspace(t, "nonprod", NonProdArgs()), "aws:cloudwatch/logGroup:LogGroup")
	if nonprod.Inputs["retentionInDays"].NumberValue() != 7 {
		t.Fatal("nonprod default retention changed")
	}
}

func TestNegativeLogRetentionRejected(t *testing.T) {
	args := NonProdArgs()
	args.LogRetentionDays = -1
	err := pulumi.RunErr(func(ctx *pulumi.Context) error {
		_, err := New(ctx, "nonprod", args)
		return err
	}, pulumi.WithMocks("daily-workspace", "nonprod", &testutil.Mocks{}))
	if err == nil {
		t.Fatal("negative retention must be rejected")
	}
}
