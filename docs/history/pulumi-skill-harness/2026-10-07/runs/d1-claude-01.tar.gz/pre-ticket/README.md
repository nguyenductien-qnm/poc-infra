# xbrain daily infrastructure lab

Repo kế thừa cho ticket bảo trì Pulumi Go. Đây là fixture offline, chưa deploy.
`infra/cmd/workspace` đọc config; `infra/internal/workspace` ghép component;
storage và workload có owner riêng trong workspace, network được consume.

Đọc docs/DECISIONS.md và docs/CONTRACTS.md. Kiểm tra từ infra:
`gofmt -l .`, `go mod tidy -diff`, `go vet ./...`, `go build ./...`, `go test ./...`.
Mocks không chứng minh preview, cloud connectivity hoặc migration thành công.
App là module scope-control riêng, không phải image runtime và không build nó.
