package workspace

import (
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
	"strings"
	"testing"
	"xbrain.local/daily/internal/testutil"
)

func NonProdArgs() *Args {
	return &Args{Environment: "nonprod", Region: "ap-southeast-1", StoragePrefix: "xbrain-nonprod-uploads-", DesiredCount: 1,
		Image: pulumi.String("fixture.invalid/api@sha256:" + strings.Repeat("a", 64)),
		VpcID: pulumi.String("fixture-vpc"), SubnetIDs: pulumi.StringArray{pulumi.String("fixture-subnet-a")}, PeerCIDR: "10.30.0.0/16"}
}

func TestExistingNonProd(t *testing.T) {
	mocks := &testutil.Mocks{}
	err := pulumi.RunErr(func(ctx *pulumi.Context) error {
		result, err := New(ctx, "nonprod", NonProdArgs())
		if err != nil {
			return err
		}
		ctx.Export("bucketName", result.BucketName)
		ctx.Export("serviceName", result.ServiceName)
		return nil
	}, pulumi.WithMocks("daily-workspace", "nonprod", mocks))
	if err != nil {
		t.Fatal(err)
	}
	seenBucket, seenService := false, false
	for _, item := range mocks.Resources() {
		switch item.TypeToken {
		case "aws:s3/bucket:Bucket":
			seenBucket = true
			if item.Name != "nonprod-storage-uploads" || item.Inputs["bucketPrefix"].StringValue() != "xbrain-nonprod-uploads-" {
				t.Fatal("existing bucket contract changed")
			}
			if item.RegisterRPC.GetParent() == "" || item.Provider == "" {
				t.Fatal("bucket must have parent/provider")
			}
		case "aws:ecs/service:Service":
			seenService = true
			if item.Inputs["desiredCount"].NumberValue() != 1 {
				t.Fatal("existing capacity changed")
			}
			network := item.Inputs["networkConfiguration"].ObjectValue()
			if network["subnets"].ArrayValue()[0].StringValue() != "fixture-subnet-a" {
				t.Fatal("external subnet not consumed")
			}
		case "aws:ec2/vpc:Vpc", "aws:ec2/subnet:Subnet":
			t.Fatal("workspace must not own external network")
		}
	}
	if !seenBucket || !seenService {
		t.Fatal("missing existing resources")
	}
}
