package workspace

import (
	"encoding/json"
	"fmt"
	"github.com/pulumi/pulumi/sdk/v3/go/common/resource"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
	"os"
	"reflect"
	"sort"
	"strings"
	"sync"
	"testing"
)

// Controller-owned acceptance; no dependence on editable repository mocks/helpers.
type harnessMocks struct {
	mu      sync.Mutex
	records []pulumi.MockResourceArgs
}

func (m *harnessMocks) Call(args pulumi.MockCallArgs) (resource.PropertyMap, error) {
	return nil, fmt.Errorf("unexpected offline invoke: %s", args.Token)
}
func (m *harnessMocks) NewResource(args pulumi.MockResourceArgs) (string, resource.PropertyMap, error) {
	m.mu.Lock()
	m.records = append(m.records, args)
	m.mu.Unlock()
	outputs := args.Inputs.Copy()
	outputs["name"] = resource.NewStringProperty(args.Name)
	outputs["arn"] = resource.NewStringProperty("fixture-reference-" + args.Name)
	if args.TypeToken == "aws:s3/bucket:Bucket" {
		outputs["bucket"] = resource.NewStringProperty(args.Name + "-mock")
	}
	return args.Name + "-mock-id", outputs, nil
}
func (m *harnessMocks) Resources() []pulumi.MockResourceArgs {
	m.mu.Lock()
	defer m.mu.Unlock()
	return append([]pulumi.MockResourceArgs(nil), m.records...)
}
func harnessArgs() *Args {
	return &Args{Environment: "nonprod", Region: "ap-southeast-1", StoragePrefix: "xbrain-nonprod-uploads-", DesiredCount: 1,
		Image: pulumi.String("fixture.invalid/api@sha256:" + strings.Repeat("a", 64)),
		VpcID: pulumi.String("fixture-vpc"), SubnetIDs: pulumi.StringArray{pulumi.String("fixture-subnet-a")}, PeerCIDR: "10.30.0.0/16"}
}

type harnessIdentity struct{ Type, Name, Parent, Provider string }

func harnessInventory(m *harnessMocks) []harnessIdentity {
	items := []harnessIdentity{}
	for _, item := range m.Resources() {
		items = append(items, harnessIdentity{item.TypeToken, item.Name, item.RegisterRPC.GetParent(), item.Provider})
	}
	sort.Slice(items, func(i, j int) bool { return items[i].Type+"/"+items[i].Name < items[j].Type+"/"+items[j].Name })
	return items
}

func TestHarnessD1Config(t *testing.T) {
	for _, env := range []string{"nonprod", "uat"} {
		t.Run(env, func(t *testing.T) {
			args := harnessArgs()
			args.Environment = env
			args.StoragePrefix = "xbrain-" + env + "-uploads-"
			if env == "uat" {
				args.DesiredCount = 2
			}
			expectedPrefix, expectedCapacity := args.StoragePrefix, args.DesiredCount
			mocks := &harnessMocks{}
			err := pulumi.RunErr(func(ctx *pulumi.Context) error {
				_, err := New(ctx, "nonprod", args)
				return err
			}, pulumi.WithMocks("daily-workspace", env, mocks))
			if err != nil {
				t.Fatal(err)
			}
			bucket, service := false, false
			for _, item := range mocks.Resources() {
				switch item.TypeToken {
				case "aws:s3/bucket:Bucket":
					bucket = true
					actual := item.Inputs["bucketPrefix"].StringValue()
					if actual != expectedPrefix {
						t.Errorf("storage prefix: got %q, want %q", actual, expectedPrefix)
					}
					if item.Name != "nonprod-storage-uploads" || !strings.HasSuffix(item.RegisterRPC.GetParent(), "::nonprod-storage") || item.Provider == "" {
						t.Error("bucket identity/parent/provider changed")
					}
					if item.Inputs["tags"].ObjectValue()["Environment"].StringValue() != env {
						t.Error("wrong storage environment tag")
					}
				case "aws:ecs/service:Service":
					service = true
					if item.Name != "nonprod-workload-service" || item.Inputs["desiredCount"].NumberValue() != float64(expectedCapacity) {
						t.Error("workload identity/capacity changed")
					}
				case "aws:ec2/vpc:Vpc", "aws:ec2/subnet:Subnet":
					t.Error("workspace registered external network")
				}
			}
			if !bucket || !service {
				t.Error("expected resources not registered")
			}
		})
	}
}

func TestHarnessD1FullIdentity(t *testing.T) {
	mocks := &harnessMocks{}
	err := pulumi.RunErr(func(ctx *pulumi.Context) error { _, err := New(ctx, "nonprod", harnessArgs()); return err }, pulumi.WithMocks("daily-workspace", "nonprod", mocks))
	if err != nil {
		t.Fatal(err)
	}
	inventory := harnessInventory(mocks)
	encoded, err := json.Marshal(inventory)
	if err != nil {
		t.Fatal(err)
	}
	t.Log("HARNESS_REGISTRATION_INVENTORY:" + string(encoded))
	if path := os.Getenv("HARNESS_BASELINE_IDENTITY"); path != "" {
		data, err := os.ReadFile(path)
		if err != nil {
			t.Fatal(err)
		}
		var expected []harnessIdentity
		if err := json.Unmarshal(data, &expected); err != nil {
			t.Fatal(err)
		}
		if !reflect.DeepEqual(inventory, expected) {
			t.Errorf("full registration identity/provider inventory changed: got %s", encoded)
		}
	} else if os.Getenv("HARNESS_GENERATE_IDENTITY") != "1" {
		t.Fatal("missing frozen baseline identity; acceptance fails closed")
	}
}

func TestHarnessUnknownImageRegistration(t *testing.T) {
	args := harnessArgs()
	args.Image = pulumi.UnsafeUnknownOutput(nil).ApplyT(func(value interface{}) string { return value.(string) }).(pulumi.StringOutput)
	mocks := &harnessMocks{}
	err := pulumi.RunErr(func(ctx *pulumi.Context) error {
		_, err := New(ctx, "nonprod", args)
		return err
	}, pulumi.WithMocks("daily-workspace", "nonprod", mocks), func(info *pulumi.RunInfo) { info.DryRun = true })
	if err != nil {
		t.Fatal(err)
	}
	task, service := false, false
	for _, item := range mocks.Resources() {
		task = task || item.TypeToken == "aws:ecs/taskDefinition:TaskDefinition"
		service = service || item.TypeToken == "aws:ecs/service:Service"
	}
	if !task || !service {
		t.Error("unknown image hides resource registration")
	}
}
