package workspace

import (
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
	"strings"
	"testing"
	"xbrain.local/daily/internal/storage"
	"xbrain.local/daily/internal/testutil"
)

func fixtureArgs(environment, prefix string, count int) *Args {
	return &Args{Environment: environment, Region: "ap-southeast-1", StoragePrefix: prefix, DesiredCount: count,
		Image: pulumi.String("fixture.invalid/api@sha256:" + strings.Repeat("a", 64)),
		VpcID: pulumi.String("fixture-vpc"), SubnetIDs: pulumi.StringArray{pulumi.String("fixture-subnet-a")}, PeerCIDR: "10.30.0.0/16"}
}

func NonProdArgs() *Args { return fixtureArgs("nonprod", "xbrain-nonprod-uploads-", 1) }
func UATArgs() *Args     { return fixtureArgs("uat", "xbrain-uat-uploads-", 2) }

func run(t *testing.T, name string, args *Args) []pulumi.MockResourceArgs {
	t.Helper()
	mocks := &testutil.Mocks{}
	err := pulumi.RunErr(func(ctx *pulumi.Context) error {
		result, err := New(ctx, name, args)
		if err != nil {
			return err
		}
		ctx.Export("bucketName", result.BucketName)
		ctx.Export("serviceName", result.ServiceName)
		return nil
	}, pulumi.WithMocks("daily-workspace", name, mocks))
	if err != nil {
		t.Fatal(err)
	}
	return mocks.Resources()
}

// Hai cau hinh trong docs/CONTRACTS.md; nonprod giu nguyen identity va behavior hien co.
func TestEnvironments(t *testing.T) {
	cases := []struct {
		name, prefix string
		count        float64
		args         *Args
	}{
		{"nonprod", "xbrain-nonprod-uploads-", 1, NonProdArgs()},
		{"uat", "xbrain-uat-uploads-", 2, UATArgs()},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			resources := run(t, tc.name, tc.args)
			byName := map[string]pulumi.MockResourceArgs{}
			for _, item := range resources {
				byName[item.Name] = item
				switch item.TypeToken {
				case "aws:ec2/vpc:Vpc", "aws:ec2/subnet:Subnet":
					t.Fatal("workspace must not own external network")
				case "aws:s3/bucket:Bucket", "aws:ecs/service:Service", "aws:cloudwatch/logGroup:LogGroup":
					tags := item.Inputs["tags"].ObjectValue()
					if tags["Team"].StringValue() != "xbrain" || tags["Environment"].StringValue() != tc.name {
						t.Fatalf("%s tags do not match contract", item.Name)
					}
				}
			}
			expectType := map[string]string{
				tc.name:                          "xbrain:workspace:Workspace",
				tc.name + "-aws":                 "pulumi:providers:aws",
				tc.name + "-storage":             "xbrain:storage:Storage",
				tc.name + "-workload":            "xbrain:workload:Workload",
				tc.name + "-storage-uploads":     "aws:s3/bucket:Bucket",
				tc.name + "-workload-service":    "aws:ecs/service:Service",
				tc.name + "-workload-logs":       "aws:cloudwatch/logGroup:LogGroup",
				tc.name + "-workload-service-sg": "aws:ec2/securityGroup:SecurityGroup",
			}
			for name, token := range expectType {
				if byName[name].TypeToken != token {
					t.Fatalf("missing %s (%s)", name, token)
				}
			}
			bucket := byName[tc.name+"-storage-uploads"]
			if bucket.Inputs["bucketPrefix"].StringValue() != tc.prefix || bucket.Inputs.HasValue("bucket") {
				t.Fatal("bucket must use the environment prefix with auto-name")
			}
			// parent va provider phai dung component/provider cua moi truong
			parents := map[string]string{
				tc.name + "-storage":         "xbrain:workspace:Workspace::" + tc.name,
				tc.name + "-workload":        "xbrain:workspace:Workspace::" + tc.name,
				tc.name + "-storage-uploads": "xbrain:storage:Storage::" + tc.name + "-storage",
				tc.name + "-workload-service": "xbrain:workload:Workload::" + tc.name + "-workload",
			}
			for name, suffix := range parents {
				if !strings.HasSuffix(byName[name].RegisterRPC.GetParent(), suffix) {
					t.Fatalf("%s parent changed", name)
				}
			}
			for _, name := range []string{tc.name + "-storage-uploads", tc.name + "-workload-service"} {
				if !strings.Contains(byName[name].Provider, "pulumi:providers:aws::"+tc.name+"-aws") {
					t.Fatalf("%s must inherit %s-aws", name, tc.name)
				}
			}
			service := byName[tc.name+"-workload-service"]
			if service.Inputs["desiredCount"].NumberValue() != tc.count {
				t.Fatal("capacity does not match contract")
			}
			network := service.Inputs["networkConfiguration"].ObjectValue()
			if network["subnets"].ArrayValue()[0].StringValue() != "fixture-subnet-a" {
				t.Fatal("external subnet not consumed")
			}
			ingress := byName[tc.name+"-workload-service-sg"].Inputs["ingress"].ArrayValue()[0].ObjectValue()
			if ingress["fromPort"].NumberValue() != 8080 || ingress["cidrBlocks"].ArrayValue()[0].StringValue() != "10.30.0.0/16" {
				t.Fatal("ingress does not match contract")
			}
			// contract chi chot retention 7 ngay cho nonprod; uat dang dung chung gia tri nay
			if tc.name == "nonprod" && byName[tc.name+"-workload-logs"].Inputs["retentionInDays"].NumberValue() != 7 {
				t.Fatal("log retention changed")
			}
		})
	}
}

// storage khong duoc roi ve prefix cua moi truong khac khi thieu prefix
func TestStorageRequiresPrefix(t *testing.T) {
	err := pulumi.RunErr(func(ctx *pulumi.Context) error {
		_, err := storage.New(ctx, "uat-storage", &storage.Args{Tags: pulumi.StringMap{}})
		return err
	}, pulumi.WithMocks("daily-workspace", "uat", &testutil.Mocks{}))
	if err == nil {
		t.Fatal("storage without prefix must fail")
	}
}

func TestRejectsMissingPrefix(t *testing.T) {
	args := UATArgs()
	args.StoragePrefix = ""
	err := pulumi.RunErr(func(ctx *pulumi.Context) error {
		_, err := New(ctx, "uat", args)
		return err
	}, pulumi.WithMocks("daily-workspace", "uat", &testutil.Mocks{}))
	if err == nil {
		t.Fatal("missing storage prefix must fail")
	}
}
