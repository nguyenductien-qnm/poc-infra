# xbrain daily infrastructure lab

Repo kế thừa cho ticket bảo trì Pulumi Go. Đây là fixture offline, chưa deploy.
`infra/cmd/workspace` đọc config; `infra/internal/workspace` ghép component;
storage và workload có owner riêng trong workspace, network được consume.

Đọc docs/DECISIONS.md và docs/CONTRACTS.md. Kiểm tra từ infra:
`gofmt -l .`, `go mod tidy -diff`, `go vet ./...`, `go build ./...`, `go test ./...`.
Mocks không chứng minh preview, cloud connectivity hoặc migration thành công.
App là module scope-control riêng, không phải image runtime và không build nó.

## Dùng component workspace cho một môi trường

`workspace.New(ctx, name, args)` không còn gắn cứng NonProd. Mọi giá trị riêng
của môi trường đi qua `workspace.Args`, được đọc ở `cmd/workspace` từ namespace
config `workspace`:

| Key | NonProd | UAT (chưa onboard) |
| --- | --- | --- |
| `environment` | `nonprod` | `uat` |
| `storagePrefix` | `xbrain-nonprod-uploads-` | `xbrain-uat-uploads-` |
| `desiredCount` | `1` | `2` |
| `region`, `image`, `vpcId`, `subnetId`, `peerCidr` | theo contract | theo contract mạng cấp riêng |

- Logical name của workspace là giá trị `environment`. Với NonProd nó vẫn là
  `nonprod`, nên type token, logical name, parent và children
  (`nonprod-aws`, `nonprod-storage`, `nonprod-workload`...) giữ nguyên.
- Tag `Team=xbrain` và `Environment=<environment>` được gắn ở workspace.
- Bucket dùng `BucketPrefix` auto-name từ `storagePrefix`; thiếu prefix thì
  `storage.New` trả lỗi thay vì rơi về prefix NonProd.
- VPC/subnet chỉ được consume qua ID; workspace không tạo hay import chúng.
- Log retention 7 ngày, Fargate 256/512, port 8080 và `/health` đang dùng
  chung cho mọi môi trường; contract chưa nêu giá trị khác cho UAT.
- Onboard UAT cần stack/backend và contract mạng thật; ticket này không tạo
  stack hay config.

`internal/workspace/workspace_test.go` chạy cả hai cấu hình trong
docs/CONTRACTS.md bằng mocks.
