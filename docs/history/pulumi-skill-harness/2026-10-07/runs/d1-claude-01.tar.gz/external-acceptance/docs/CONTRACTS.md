# Contract được cấp

Toàn bộ giá trị dưới đây là fixture không chứa account/ARN/credentials thật.
Network team sở hữu VPC/subnets; IDs `fixture-vpc` và `fixture-subnet-a` chỉ
dùng mocks. App team cung cấp image contract offline `fixture.invalid/api@sha256:`
cộng 64 ký tự `a`; đó không phải image pull được. Port 8080, health `/health`,
Linux/AMD64, Fargate 256 CPU/512 MiB. Image live và topology phải cấp trước AWS.

NonProd: environment `nonprod`, storage prefix `xbrain-nonprod-uploads-`,
desired count 1, tags `Team=xbrain`, `Environment=nonprod`, log retention 7 ngày.
UAT là cấu hình thứ hai hợp lệ: environment `uat`, storage prefix
`xbrain-uat-uploads-`, desired count 2, tags Environment=uat. Chưa onboard UAT.
Hai môi trường dùng contract mạng cấp riêng; không sở hữu VPC/subnet.
Cho phép ingress nội bộ từ `10.30.0.0/16` tới port 8080, egress theo mô hình lab.

Read-only inputs không được sửa để che lỗi IaC. Task execution role ghi log
qua policy sinh từ LogGroup Output; task không có secret giá trị để đọc.
Backend live S3/KMS và runtime secret references chưa được cấp.
