# Quyết định của lab

- Track offline/code. Chưa có AWS state hay resource; IDs và image chỉ là fixture.
- Một project Go `daily-workspace`; consumer hiện tại là NonProd. Cấu hình môi
  trường được đọc ở composition root và dùng chung các capability cụ thể.
- Workspace sở hữu bucket, SG, logs, execution role, ECS cluster/task/service.
  VPC và subnets thuộc network team, chỉ consume qua contract. Không import hay
  register lại chúng. Provider thuộc workspace.New, được đăng ký ở stack root với tên <workspace>-aws; children kế thừa provider qua parent. Composition root cmd/workspace đọc config. Giữ cách sở hữu provider này trong ticket cấu hình.
- Identity hiện tại: type token `xbrain:workspace:Workspace`, logical name
  `nonprod`, child components `nonprod-storage` / `nonprod-workload` và các
  resource suffix trong source. Refactor giữ chúng hoặc nêu migration/aliases.
- NonProd cho phép protection=false; không thêm production guardrails unasked.
- Delivery mode: kiểm tra PR, preview thủ công và deploy manual-dispatch có
  approval. Chưa cấp backend/CI identity; không dispatch hoặc đổi delivery mode.
- StoragePrefix hiện tại `xbrain-nonprod-uploads-`; dùng BucketPrefix auto-name,
  không lấy physical name cố định. Consumer mới có prefix riêng theo contract.
- Args/Outputs có consumer thật; không thêm registry, plugin engine hoặc flags
  chưa dùng. Không nâng major SDK. Mocks không phải observed Pulumi preview.
