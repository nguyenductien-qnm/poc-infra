Read AGENTS.md and the local .agents/skills/pulumi/SKILL.md for infrastructure work.
