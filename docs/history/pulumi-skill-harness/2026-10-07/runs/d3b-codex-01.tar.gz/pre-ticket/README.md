# xbrain daily infrastructure lab

Repo kế thừa cho ticket bảo trì Pulumi Go. Đây là fixture offline, chưa deploy.
`infra/cmd/workspace` đọc config; `infra/internal/workspace` ghép component;
storage và workload có owner riêng trong workspace, network được consume.

Đọc docs/DECISIONS.md và docs/CONTRACTS.md. Kiểm tra từ infra:
`gofmt -l .`, `go mod tidy -diff`, `go vet ./...`, `go build ./...`, `go test ./...`.
Mocks không chứng minh preview, cloud connectivity hoặc migration thành công.
App là module scope-control riêng, không phải image runtime và không build nó.

## Dùng lại component Workspace

`infra/internal/workspace.New(ctx, name, args, opts...)` ghép storage và workload
qua Args cụ thể. Component không đọc stack config. Composition root
`infra/cmd/workspace` đọc namespace `workspace` và dùng `environment` làm
logical name; tên stack không quyết định tên component. Khi dùng trong một
composition root khác của module `infra`, truyền name ổn định và các giá trị từ
contract của môi trường đó.

| Config ở root | Args | Ý nghĩa |
| --- | --- | --- |
| `workspace:environment` | `Environment` | Tag `Environment`; root dùng làm logical name |
| `workspace:region` | `Region` | Region cho provider và container logs |
| `workspace:storagePrefix` | `StoragePrefix` | Truyền xuống `storage.Args.BucketPrefix`; giữ S3 auto-naming |
| `workspace:desiredCount` | `ReplicaCount` | Số task ECS, phải lớn hơn 0; giữ config key đã lưu |
| `workspace:image` | `Image` | Image do app team cấp, truyền qua Pulumi Input |
| `workspace:vpcId` | `VpcID` | VPC ngoài workspace, chỉ consume |
| `workspace:subnetIds` | `SubnetIDs` | List refs subnet ngoài, giữ nguyên thứ tự và truyền tất cả vào service |
| `workspace:subnetId` | `SubnetIDs` | Tương thích legacy: một ref khi không có `subnetIds` |
| `workspace:peerCidr` | `PeerCIDR` | CIDR được ingress TCP tới port 8080 |

Environment, region và storage prefix phải khác rỗng. `BucketName` và
`ServiceName` là Pulumi StringOutput, được đăng ký trên component và export ở
root thành `bucketName` / `serviceName`; giữ Output khi nối với consumer tiếp theo.

Go API D3a dùng `workspace.Args.ReplicaCount` và `workload.Args.ReplicaCount`,
cùng kiểu `int`; field `DesiredCount` cũ đã được loại bỏ khỏi hai Args này.
Caller Go chuyển field sang `ReplicaCount`. Config đã lưu và hai target examples
tiếp tục dùng `workspace:desiredCount`; không đổi thành `workspace:replicaCount`.
Root đọc `desiredCount`, truyền qua hai capability bằng `ReplicaCount`, rồi
workload map vào `ecs.ServiceArgs.DesiredCount`. NonProd giữ 1 task, UAT giữ 2.
Đây là đổi Go identifier, không đổi identity tài nguyên của cả hai target;
không cần aliases hay migration Pulumi và không dự kiến replacement/deletion.

Ví dụ Go cho UAT từ contract offline (dùng trong module `infra`):

```go
result, err := workspace.New(ctx, "uat", &workspace.Args{
    Environment:   "uat",
    Region:        "ap-southeast-1",
    StoragePrefix: "xbrain-uat-uploads-",
    ReplicaCount:  2,
    Image:         pulumi.String("fixture.invalid/api@sha256:" + strings.Repeat("a", 64)),
    VpcID:         pulumi.String("fixture-vpc-uat"),
    SubnetIDs: pulumi.StringArray{
        pulumi.String("fixture-subnet-uat-a"),
        pulumi.String("fixture-subnet-uat-b"),
    },
    PeerCIDR:      "10.30.0.0/16",
})
if err != nil {
    return err
}
ctx.Export("bucketName", result.BucketName)
ctx.Export("serviceName", result.ServiceName)
```

Ví dụ cần import `strings`, `github.com/pulumi/pulumi/sdk/v3/go/pulumi` và
`xbrain.local/daily/internal/workspace`. Region trong ví dụ là fixture test.
Theo [contract](docs/CONTRACTS.md), NonProd dùng environment/name `nonprod`,
prefix `xbrain-nonprod-uploads-`, desired count 1; UAT dùng `uat`,
`xbrain-uat-uploads-`, desired count 2. Cả hai giữ tag `Team=xbrain`, retention
7 ngày, port 8080, health `/health`, Fargate 256 CPU/512 MiB và wiring logs.
UAT đã có target config được kiểm tra qua root ở mức offline; chưa deploy cloud.
Mỗi môi trường vẫn phải nhận refs mạng live và image live trước khi triển khai;
fixture không dùng trên AWS.

## Supply config cho hai target

Checkpoint D2 nối tiếp D1r2 trong repo này. [Contract gốc](docs/CONTRACTS.md)
giữ nguyên; refs UAT và dạng list dưới đây là input D2 được cấp cho ticket.
Hai file mẫu nằm cạnh composition root, trong thư mục `examples`:

| Target | File mẫu | VPC ngoài | Subnet refs |
| --- | --- | --- | --- |
| NonProd | [Pulumi.nonprod.yaml](infra/cmd/workspace/examples/Pulumi.nonprod.yaml) | `fixture-vpc` | Legacy `workspace:subnetId: fixture-subnet-a` |
| UAT | [Pulumi.uat.yaml](infra/cmd/workspace/examples/Pulumi.uat.yaml) | `fixture-vpc-uat` | List `fixture-subnet-uat-a`, `fixture-subnet-uat-b` |

Mỗi file cấp đủ environment, region, storagePrefix, desiredCount, vpcId, image
và peerCidr; image chứa digest gồm đúng 64 ký tự `a`. Không có backend, cloud
identity hay secret trong mẫu. Root chọn logical workspace từ environment:
NonProd là `nonprod`, UAT là `uat`, độc lập tên stack; không cần thêm registry
hoặc target flag.

Để supply refs D2, giữ `workspace:vpcId` và subnet legacy trong mẫu NonProd.
Mẫu UAT dùng đúng YAML list sau, không phải chuỗi ghép bằng dấu phẩy:

```yaml
workspace:vpcId: fixture-vpc-uat
workspace:subnetIds:
  - fixture-subnet-uat-a
  - fixture-subnet-uat-b
```

Khi root nhận config, `subnetIds` được ưu tiên nếu có cả hai khóa; `subnetId`
chỉ là fallback khi `subnetIds` vắng mặt. List rỗng, null, sai kiểu, JSON không
hợp lệ hoặc ref trắng trả lỗi trước khi đăng ký tài nguyên workspace; không
fallback âm thầm sang mạng legacy. Thiếu cả hai khóa hoặc legacy trắng cũng
trả lỗi. VPC/subnet chỉ đi qua Args thành inputs SG/service, không lookup hay
nhận ownership mạng.

Ở mức offline, chạy `go test ./cmd/workspace -run TestTargetExamples -v` từ
`infra`: tests đọc chính hai file mẫu bằng parser stack YAML của SDK đã pin,
đưa config vào Pulumi context mock và gọi cùng `run` mà `main` sử dụng.
Đây là kiểm chứng target root/config, không chỉ constructor. Các file trong
`examples` không tự trở thành stack đang chọn. Khi tích hợp với runtime được
cấp riêng, nội dung mẫu cấu hình được supply qua file `Pulumi.<stack>.yaml`
cạnh `Pulumi.yaml`, giữ environment/name ổn định và thay fixture bằng refs
live do network/app team cấp. Ticket này chỉ đọc mẫu trong tests; không tạo
stack, ghi config đang hoạt động hay chạy lệnh Pulumi.

Giữ retention 7 ngày cho cả hai target, public-IP mode bật và egress lab
`0.0.0.0/0`. Bucket public-access blocks, execution/log policy và Outputs
giữ nguyên D1r2; không áp dụng retention 14/30 từ thử nghiệm khác.

Workspace sở hữu provider `<name>-aws` ở stack root, bucket và public-access
block, SG, logs, execution role/policy, ECS cluster/task/service. Child components
`<name>-storage` và `<name>-workload` có parent là Workspace; tài nguyên có
parent là component tương ứng và kế thừa provider. VPC/subnet không được tạo,
đọc lookup hay import. Caller options được truyền vào đăng ký Workspace;
giữ provider do Workspace sở hữu theo [quyết định](docs/DECISIONS.md).

Với NonProd hiện tại, giữ environment/name `nonprod`, region và prefix cũ:
type token `xbrain:workspace:Workspace`, toàn bộ logical names, parents và
provider ownership giữ nguyên; bucket vẫn dùng `BucketPrefix`, không có physical
name cố định. Theo source không dự kiến replacement/deletion và không cần alias
cho refactor này. Đổi environment/name, parent, region hay prefix về sau cần
đánh giá migration riêng. Chưa có observed preview hoặc kiểm chứng cloud.

## Kiểm chứng offline

Trong PowerShell, từ thư mục `infra`, dùng dependency/toolchain đã có sẵn để
không tải mạng:

```powershell
$env:GOTOOLCHAIN = 'local'
$env:GOPROXY = 'off'
$env:GOSUMDB = 'off'
gofmt -l .
go mod tidy -diff
go vet ./...
go build ./...
go test ./...
```

`TestWorkspaceContracts` kiểm tra cả NonProd và UAT: inventory/identity,
parent/provider, prefix, tags, capacity, Outputs, mạng ngoài, container và quyền
ghi log nối từ LogGroup Output. `TestTargetExamples` đọc hai mẫu và chạy root
với tên stack độc lập, kiểm tra identity/parent/provider, tags, region, prefix,
capacity, VPC/subnets riêng, image và Outputs. `TestReplicaCountAPI` kiểm tra
field mới là int và field Go cũ đã loại bỏ ở cả hai Args.
`TestPersistedCapacityConfig` chạy root cho cả hai target, xác nhận config
`workspace:desiredCount` quyết định capacity ngay cả khi có khóa
`workspace:replicaCount` khác giá trị. `TestSubnetConfigCompatibility`
kiểm tra ưu tiên list và config lỗi trước registration. Mocks từ chối provider invoke;
tests chỉ dùng giá trị fixture. Các check này không chứng minh preview,
image pull, connectivity hay migration thành công.
