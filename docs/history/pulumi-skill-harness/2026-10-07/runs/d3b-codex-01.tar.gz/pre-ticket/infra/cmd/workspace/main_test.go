package main

import (
	"encoding/json"
	"fmt"
	"path/filepath"
	"strings"
	"testing"

	"github.com/pulumi/pulumi/sdk/v3/go/common/resource"
	commonworkspace "github.com/pulumi/pulumi/sdk/v3/go/common/workspace"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
	"xbrain.local/daily/internal/testutil"
)

func loadExample(t *testing.T, target string) map[string]string {
	t.Helper()
	project, err := commonworkspace.LoadProject("Pulumi.yaml")
	if err != nil {
		t.Fatal(err)
	}
	stack, err := commonworkspace.LoadProjectStack(nil, project, filepath.Join("examples", "Pulumi."+target+".yaml"))
	if err != nil {
		t.Fatal(err)
	}
	values := make(map[string]string, len(stack.Config))
	for key, value := range stack.Config {
		if value.Secure() {
			t.Fatal("offline examples must contain only public fixtures")
		}
		plain, err := value.Value(nil)
		if err != nil {
			t.Fatal("invalid public fixture config")
		}
		values[key.String()] = plain
	}
	return values
}

func TestTargetExamples(t *testing.T) {
	for _, tc := range []struct {
		environment string
		prefix      string
		capacity    int
		vpc         string
		subnets     []string
	}{
		{"nonprod", "xbrain-nonprod-uploads-", 1, "fixture-vpc", []string{"fixture-subnet-a"}},
		{"uat", "xbrain-uat-uploads-", 2, "fixture-vpc-uat", []string{"fixture-subnet-uat-a", "fixture-subnet-uat-b"}},
	} {
		t.Run(tc.environment, func(t *testing.T) {
			values := loadExample(t, tc.environment)
			mocks := &testutil.Mocks{}
			err := pulumi.RunErr(func(ctx *pulumi.Context) error {
				if err := run(ctx); err != nil {
					return err
				}
				exports := ctx.GetCurrentExportMap()
				if len(exports) != 2 || exports["bucketName"] == nil || exports["serviceName"] == nil {
					return fmt.Errorf("root outputs changed")
				}
				ctx.Export("outputsChecked", pulumi.All(exports["bucketName"], exports["serviceName"]).ApplyT(func(values []interface{}) (bool, error) {
					if values[0] != tc.environment+"-storage-uploads-mock" || values[1] != tc.environment+"-workload-service" {
						return false, fmt.Errorf("root must export its target's child outputs")
					}
					return true, nil
				}))
				return nil
			}, pulumi.WithMocks("daily-workspace", "fixture-stack", mocks), func(info *pulumi.RunInfo) {
				info.Config = values
			})
			if err != nil {
				t.Fatal(err)
			}

			expected := map[string]string{
				"pulumi:providers:aws":                                   "-aws",
				"xbrain:workspace:Workspace":                             "",
				"xbrain:storage:Storage":                                 "-storage",
				"xbrain:workload:Workload":                               "-workload",
				"aws:s3/bucket:Bucket":                                   "-storage-uploads",
				"aws:s3/bucketPublicAccessBlock:BucketPublicAccessBlock": "-storage-uploads-access",
				"aws:cloudwatch/logGroup:LogGroup":                       "-workload-logs",
				"aws:iam/role:Role":                                      "-workload-execution",
				"aws:iam/rolePolicy:RolePolicy":                          "-workload-logs-policy",
				"aws:ec2/securityGroup:SecurityGroup":                    "-workload-service-sg",
				"aws:ecs/cluster:Cluster":                                "-workload-cluster",
				"aws:ecs/taskDefinition:TaskDefinition":                  "-workload-task",
				"aws:ecs/service:Service":                                "-workload-service",
			}
			urn := func(token, name string) string {
				return "urn:pulumi:fixture-stack::daily-workspace::" + token + "::" + name
			}
			workspaceURN := urn("xbrain:workspace:Workspace", tc.environment)
			provider := urn("pulumi:providers:aws", tc.environment+"-aws") + "::" + tc.environment + "-aws-mock-id"
			resources := map[string]pulumi.MockResourceArgs{}
			for _, item := range mocks.Resources() {
				suffix, ok := expected[item.TypeToken]
				if !ok || item.Name != tc.environment+suffix {
					t.Fatalf("unexpected target resource: %s (%s)", item.Name, item.TypeToken)
				}
				if _, duplicate := resources[item.TypeToken]; duplicate {
					t.Fatal("duplicate resource owner")
				}
				resources[item.TypeToken] = item
				parent := urn("pulumi:pulumi:Stack", "daily-workspace-fixture-stack")
				if strings.HasPrefix(item.TypeToken, "xbrain:") && suffix != "" {
					parent = workspaceURN
				} else if strings.HasPrefix(item.TypeToken, "aws:") {
					parent = urn("xbrain:workspace:Workspace$xbrain:workload:Workload", tc.environment+"-workload")
					if strings.HasPrefix(suffix, "-storage") {
						parent = urn("xbrain:workspace:Workspace$xbrain:storage:Storage", tc.environment+"-storage")
					}
					if item.Provider != provider {
						t.Errorf("provider inheritance changed for %s", item.Name)
					}
					if item.TypeToken != "aws:s3/bucketPublicAccessBlock:BucketPublicAccessBlock" && item.TypeToken != "aws:iam/rolePolicy:RolePolicy" {
						checkRootProperty(t, item.Inputs, "tags", map[string]string{"Team": "xbrain", "Environment": tc.environment})
					}
				}
				if item.RegisterRPC == nil || item.RegisterRPC.GetParent() != parent || item.ID != "" || item.ReadRPC != nil {
					t.Errorf("resource ownership/parent changed for %s", item.Name)
				}
			}
			if len(resources) != len(expected) {
				t.Fatal("target resource inventory changed")
			}
			checkRootProperty(t, resources["pulumi:providers:aws"].Inputs, "region", "ap-southeast-1")
			checkRootProperty(t, resources["aws:s3/bucket:Bucket"].Inputs, "bucketPrefix", tc.prefix)
			checkRootProperty(t, resources["aws:cloudwatch/logGroup:LogGroup"].Inputs, "retentionInDays", 7)
			group := resources["aws:ec2/securityGroup:SecurityGroup"].Inputs
			checkRootProperty(t, group, "vpcId", tc.vpc)
			checkRootProperty(t, group, "ingress", []interface{}{map[string]interface{}{
				"protocol": "tcp", "fromPort": 8080, "toPort": 8080, "cidrBlocks": []string{"10.30.0.0/16"},
			}})
			service := resources["aws:ecs/service:Service"].Inputs
			checkRootProperty(t, service, "desiredCount", tc.capacity)
			checkRootProperty(t, service, "networkConfiguration", map[string]interface{}{
				"subnets": tc.subnets, "securityGroups": []string{tc.environment + "-workload-service-sg-mock-id"}, "assignPublicIp": true,
			})
			task := resources["aws:ecs/taskDefinition:TaskDefinition"].Inputs
			var containers []struct {
				Image            string `json:"image"`
				LogConfiguration struct {
					Options map[string]string `json:"options"`
				} `json:"logConfiguration"`
			}
			if err := json.Unmarshal([]byte(task["containerDefinitions"].StringValue()), &containers); err != nil {
				t.Fatal("invalid container JSON")
			}
			if len(containers) != 1 || containers[0].Image != "fixture.invalid/api@sha256:"+strings.Repeat("a", 64) ||
				containers[0].LogConfiguration.Options["awslogs-region"] != "ap-southeast-1" {
				t.Error("root image/region config did not reach workload")
			}
		})
	}
}

func TestPersistedCapacityConfig(t *testing.T) {
	for _, tc := range []struct {
		target   string
		capacity int
	}{
		{"nonprod", 1},
		{"uat", 2},
	} {
		t.Run(tc.target, func(t *testing.T) {
			values := loadExample(t, tc.target)
			values["workspace:replicaCount"] = "99"
			mocks := &testutil.Mocks{}
			err := pulumi.RunErr(run, pulumi.WithMocks("daily-workspace", "fixture-stack", mocks), func(info *pulumi.RunInfo) {
				info.Config = values
			})
			if err != nil {
				t.Fatal(err)
			}
			seenService := false
			for _, item := range mocks.Resources() {
				if item.TypeToken == "aws:ecs/service:Service" {
					seenService = true
					if item.Name != tc.target+"-workload-service" {
						t.Error("target service identity changed")
					}
					checkRootProperty(t, item.Inputs, "desiredCount", tc.capacity)
				}
			}
			if !seenService {
				t.Error("missing configured service")
			}
		})
	}
}

func TestSubnetConfigCompatibility(t *testing.T) {
	for _, tc := range []struct {
		name      string
		list      string
		wantError string
	}{
		{"list wins over legacy", `["fixture-subnet-uat-a","fixture-subnet-uat-b"]`, ""},
		{"empty list does not fall back", `[]`, "workspace:subnetIds must be a non-empty list"},
		{"null list does not fall back", `null`, "workspace:subnetIds must be a non-empty list"},
		{"string instead of list", `"fixture-subnet-uat-a"`, "workspace:subnetIds must be a non-empty list"},
		{"malformed list", `[`, "workspace:subnetIds must be a non-empty list"},
		{"non-string reference", `[42]`, "workspace:subnetIds must be a non-empty list"},
		{"blank reference", `[" "]`, "workspace subnet references must not be blank"},
		{"no subnet config", "", "workspace requires subnetIds or legacy subnetId"},
		{"blank legacy reference", "", "workspace requires subnetIds or legacy subnetId"},
	} {
		t.Run(tc.name, func(t *testing.T) {
			values := loadExample(t, "nonprod")
			if tc.list != "" {
				values["workspace:subnetIds"] = tc.list
			} else if tc.name == "blank legacy reference" {
				values["workspace:subnetId"] = " "
			} else {
				delete(values, "workspace:subnetId")
			}
			mocks := &testutil.Mocks{}
			err := pulumi.RunErr(run, pulumi.WithMocks("daily-workspace", "fixture-stack", mocks), func(info *pulumi.RunInfo) {
				info.Config = values
			})
			if tc.wantError != "" {
				if err == nil || !strings.Contains(err.Error(), tc.wantError) {
					t.Fatal("expected subnet config validation error")
				}
				if len(mocks.Resources()) != 0 {
					t.Error("invalid config must fail before registering workspace resources")
				}
				return
			}
			if err != nil {
				t.Fatal(err)
			}
			seenService := false
			for _, item := range mocks.Resources() {
				if item.TypeToken == "aws:ecs/service:Service" {
					seenService = true
					checkRootProperty(t, item.Inputs["networkConfiguration"].ObjectValue(), "subnets", []string{"fixture-subnet-uat-a", "fixture-subnet-uat-b"})
				}
			}
			if !seenService {
				t.Error("missing configured service")
			}
		})
	}
}

func checkRootProperty(t *testing.T, properties resource.PropertyMap, key string, want interface{}) {
	t.Helper()
	if !properties[resource.PropertyKey(key)].DeepEquals(resource.NewPropertyValue(want)) {
		t.Errorf("root property %s does not match the target contract", key)
	}
}
