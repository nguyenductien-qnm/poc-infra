# Infrastructure work

Use the local Pulumi Go skill for infrastructure and delivery. Discover roots,
consumers and decisions from the repository. Application implementation/builds
are outside scope. Never expose secrets, tokens, account IDs or ARNs.
This run is offline: no cloud reads/writes, Pulumi login/preview/config/state
commands, GitHub dispatch/push, credentials inspection or sibling-repo access.
Local Go/source/docs/tests edits and local checks are authorized.
Use scoped lowercase English Conventional Commits if a commit is requested.
Code comments are unaccented Vietnamese; guides use accented Vietnamese.
Read docs/DECISIONS.md and docs/CONTRACTS.md before infrastructure changes.
