package workspace

import (
	"encoding/json"
	"fmt"
	"github.com/pulumi/pulumi/sdk/v3/go/common/resource"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
	pulumirpc "github.com/pulumi/pulumi/sdk/v3/proto/go"
	"os"
	"os/exec"
	"reflect"
	"sort"
	"strings"
	"sync"
	"testing"
	"xbrain.local/daily/internal/workload"
)

// Controller-owned mocks and contracts do not depend on coder-editable helpers.
type d3bMocks struct {
	mu      sync.Mutex
	records []pulumi.MockResourceArgs
	outputs map[string]string
}

func (m *d3bMocks) Call(args pulumi.MockCallArgs) (resource.PropertyMap, error) {
	return nil, fmt.Errorf("unexpected offline invoke: %s", args.Token)
}
func (m *d3bMocks) NewResource(args pulumi.MockResourceArgs) (string, resource.PropertyMap, error) {
	m.mu.Lock()
	m.records = append(m.records, args)
	m.mu.Unlock()
	outputs := args.Inputs.Copy()
	outputs["name"] = resource.NewStringProperty(args.Name)
	outputs["arn"] = resource.NewStringProperty("fixture-reference-" + args.Name)
	if args.TypeToken == "aws:s3/bucket:Bucket" {
		outputs["bucket"] = resource.NewStringProperty(args.Name + "-mock")
	}
	return args.Name + "-mock-id", outputs, nil
}
func (m *d3bMocks) resources() []pulumi.MockResourceArgs {
	m.mu.Lock()
	defer m.mu.Unlock()
	return append([]pulumi.MockResourceArgs(nil), m.records...)
}

// Expectations are frozen before constructors run, independently of supplied Args.
type d3bContract struct {
	name, environment, region, prefix, vpc, cidr string
	capacity                                     int
	subnets                                      []string
}

func d3bContracts() []d3bContract {
	return []d3bContract{
		{name: "nonprod", environment: "nonprod", region: "ap-southeast-1", prefix: "xbrain-nonprod-uploads-", capacity: 1, vpc: "fixture-vpc", subnets: []string{"fixture-subnet-a"}, cidr: "10.30.0.0/16"},
		{name: "uat", environment: "uat", region: "ap-southeast-1", prefix: "xbrain-uat-uploads-", capacity: 2, vpc: "fixture-vpc-uat", subnets: []string{"fixture-subnet-uat-a", "fixture-subnet-uat-b"}, cidr: "10.30.0.0/16"},
	}
}
func d3bArgs(spec d3bContract) *Args {
	subnets := pulumi.StringArray{}
	for _, subnet := range spec.subnets {
		subnets = append(subnets, pulumi.String(subnet))
	}
	return &Args{Environment: spec.environment, Region: spec.region, StoragePrefix: spec.prefix, ReplicaCount: spec.capacity,
		Image: pulumi.String("fixture.invalid/api@sha256:" + strings.Repeat("a", 64)), VpcID: pulumi.String(spec.vpc), SubnetIDs: subnets, PeerCIDR: spec.cidr}
}

type d3bIdentity struct{ Type, Name, Parent, Provider string }

func d3bInventory(m *d3bMocks) []d3bIdentity {
	result := []d3bIdentity{}
	for _, item := range m.resources() {
		result = append(result, d3bIdentity{item.TypeToken, item.Name, item.RegisterRPC.GetParent(), item.Provider})
	}
	sort.Slice(result, func(i, j int) bool { return result[i].Type+"/"+result[i].Name < result[j].Type+"/"+result[j].Name })
	return result
}

func d3bAssertInventory(t *testing.T, spec d3bContract, m *d3bMocks) {
	t.Helper()
	var expected []d3bIdentity
	data := strings.ReplaceAll(d3bFrozenNonProdIdentity, "nonprod", spec.name)
	if err := json.Unmarshal([]byte(data), &expected); err != nil {
		t.Fatal(err)
	}
	component := d3bOne(t, m, "xbrain:storage:Storage")
	componentURN := d3bURN(spec.name, "daily-workspace", component.TypeToken, component.Name, component.RegisterRPC.GetParent())
	for i := range expected {
		item := &expected[i]
		switch item.Type {
		case "xbrain:storage:Storage":
			item.Name = spec.name + "-object-store"
		case "aws:s3/bucket:Bucket", "aws:s3/bucketPublicAccessBlock:BucketPublicAccessBlock":
			actual := d3bOne(t, m, item.Type)
			// The exact requested new name is independent of coverage of its old identity.
			desiredName := strings.Replace(item.Name, spec.name+"-storage", spec.name+"-object-store", 1)
			if actual.Name != desiredName {
				t.Errorf("D3B_CURRENT_STORAGE_NAME:%s: got %s, want %s", item.Type, actual.Name, desiredName)
			}
			// Continue checking parent/provider and runtime wiring even after a name finding.
			item.Name = actual.Name
			item.Parent = componentURN
		}
	}
	sort.Slice(expected, func(i, j int) bool {
		return expected[i].Type+"/"+expected[i].Name < expected[j].Type+"/"+expected[j].Name
	})
	actual := d3bInventory(m)
	encoded, _ := json.Marshal(actual)
	t.Log("D3b_REGISTRATION_INVENTORY:" + string(encoded))
	if len(expected) != 13 || !reflect.DeepEqual(actual, expected) {
		t.Fatalf("thirteen-resource type/parent/provider inventory or other ten identities changed: got %s", encoded)
	}
	for _, item := range m.resources() {
		if item.ID != "" || item.ReadRPC != nil || item.RegisterRPC.GetImportId() != "" {
			t.Errorf("unexpected external read/import: %s/%s", item.TypeToken, item.Name)
		}
		if item.TypeToken == "aws:ec2/vpc:Vpc" || item.TypeToken == "aws:ec2/subnet:Subnet" {
			t.Error("workspace registered externally owned network")
		}
	}
}

func d3bOne(t *testing.T, m *d3bMocks, token string) pulumi.MockResourceArgs {
	t.Helper()
	found := []pulumi.MockResourceArgs{}
	for _, item := range m.resources() {
		if item.TypeToken == token {
			found = append(found, item)
		}
	}
	if len(found) != 1 {
		t.Fatalf("got %d resources for %s, want 1", len(found), token)
	}
	return found[0]
}
func d3bString(t *testing.T, props resource.PropertyMap, key string) string {
	t.Helper()
	value, ok := props[resource.PropertyKey(key)]
	if !ok || !value.IsString() {
		t.Fatalf("%s must be a concrete string", key)
	}
	return value.StringValue()
}
func d3bObject(t *testing.T, props resource.PropertyMap, key string) resource.PropertyMap {
	t.Helper()
	value, ok := props[resource.PropertyKey(key)]
	if !ok || !value.IsObject() {
		t.Fatalf("%s must be an object", key)
	}
	return value.ObjectValue()
}
func d3bArray(t *testing.T, props resource.PropertyMap, key string) []resource.PropertyValue {
	t.Helper()
	value, ok := props[resource.PropertyKey(key)]
	if !ok || !value.IsArray() {
		t.Fatalf("%s must be an array", key)
	}
	return value.ArrayValue()
}
func d3bStrings(t *testing.T, props resource.PropertyMap, key string) []string {
	t.Helper()
	result := []string{}
	for _, value := range d3bArray(t, props, key) {
		if !value.IsString() {
			t.Fatalf("%s array must contain strings", key)
		}
		result = append(result, value.StringValue())
	}
	return result
}
func d3bWantString(t *testing.T, props resource.PropertyMap, key, want string) {
	t.Helper()
	if got := d3bString(t, props, key); got != want {
		t.Errorf("%s: got %q, want %q", key, got, want)
	}
}
func d3bWantNumber(t *testing.T, props resource.PropertyMap, key string, want float64) {
	t.Helper()
	value, ok := props[resource.PropertyKey(key)]
	if !ok || !value.IsNumber() {
		t.Fatalf("%s must be a concrete number", key)
	}
	if got := value.NumberValue(); got != want {
		t.Errorf("%s: got %v, want %v", key, got, want)
	}
}
func d3bWantBool(t *testing.T, props resource.PropertyMap, key string, want bool) {
	t.Helper()
	value, ok := props[resource.PropertyKey(key)]
	if !ok || !value.IsBool() {
		t.Fatalf("%s must be a concrete boolean", key)
	}
	if got := value.BoolValue(); got != want {
		t.Errorf("%s: got %v, want %v", key, got, want)
	}
}
func d3bCaptureOutputs(ctx *pulumi.Context, m *d3bMocks, result *Workspace) {
	result.BucketName.ApplyT(func(value string) string { m.mu.Lock(); m.outputs["bucketName"] = value; m.mu.Unlock(); return value })
	result.ServiceName.ApplyT(func(value string) string { m.mu.Lock(); m.outputs["serviceName"] = value; m.mu.Unlock(); return value })
	ctx.Export("bucketName", result.BucketName)
	ctx.Export("serviceName", result.ServiceName)
}
func TestHarnessD3bConsumers(t *testing.T) {
	for _, spec := range d3bContracts() {
		t.Run(spec.name, func(t *testing.T) {
			args := d3bArgs(spec)
			mocks := &d3bMocks{outputs: map[string]string{}}
			err := pulumi.RunErr(func(ctx *pulumi.Context) error {
				result, err := New(ctx, spec.name, args)
				if err != nil {
					return err
				}
				d3bCaptureOutputs(ctx, mocks, result)
				return nil
			}, pulumi.WithMocks("daily-workspace", spec.name, mocks))
			if err != nil {
				t.Fatal(err)
			}
			d3bAssertInventory(t, spec, mocks)
			provider := d3bOne(t, mocks, "pulumi:providers:aws")
			if provider.Name != spec.name+"-aws" {
				t.Error("provider logical name changed")
			}
			d3bWantString(t, provider.Inputs, "region", spec.region)
			for _, token := range []string{"aws:s3/bucket:Bucket", "aws:cloudwatch/logGroup:LogGroup", "aws:ec2/securityGroup:SecurityGroup", "aws:iam/role:Role", "aws:ecs/cluster:Cluster", "aws:ecs/taskDefinition:TaskDefinition", "aws:ecs/service:Service"} {
				tags := d3bObject(t, d3bOne(t, mocks, token).Inputs, "tags")
				d3bWantString(t, tags, "Team", "xbrain")
				d3bWantString(t, tags, "Environment", spec.environment)
			}
			bucket := d3bOne(t, mocks, "aws:s3/bucket:Bucket")
			d3bWantString(t, bucket.Inputs, "bucketPrefix", spec.prefix)
			block := d3bOne(t, mocks, "aws:s3/bucketPublicAccessBlock:BucketPublicAccessBlock")
			d3bWantString(t, block.Inputs, "bucket", bucket.Name+"-mock-id")
			for _, key := range []string{"blockPublicAcls", "blockPublicPolicy", "ignorePublicAcls", "restrictPublicBuckets"} {
				d3bWantBool(t, block.Inputs, key, true)
			}
			group := d3bOne(t, mocks, "aws:ec2/securityGroup:SecurityGroup")
			d3bWantString(t, group.Inputs, "vpcId", spec.vpc)
			ingress := d3bArray(t, group.Inputs, "ingress")
			if len(ingress) != 1 || !ingress[0].IsObject() {
				t.Fatal("expected one internal ingress rule")
			}
			rule := ingress[0].ObjectValue()
			d3bWantString(t, rule, "protocol", "tcp")
			d3bWantNumber(t, rule, "fromPort", 8080)
			d3bWantNumber(t, rule, "toPort", 8080)
			if got := d3bStrings(t, rule, "cidrBlocks"); !reflect.DeepEqual(got, []string{spec.cidr}) {
				t.Errorf("ingress CIDR: got %v, want %v", got, spec.cidr)
			}
			egress := d3bArray(t, group.Inputs, "egress")
			if len(egress) != 1 || !egress[0].IsObject() {
				t.Fatal("expected one lab egress rule")
			}
			outbound := egress[0].ObjectValue()
			d3bWantString(t, outbound, "protocol", "-1")
			d3bWantNumber(t, outbound, "fromPort", 0)
			d3bWantNumber(t, outbound, "toPort", 0)
			if got := d3bStrings(t, outbound, "cidrBlocks"); !reflect.DeepEqual(got, []string{"0.0.0.0/0"}) {
				t.Errorf("egress CIDR: got %v", got)
			}
			logs := d3bOne(t, mocks, "aws:cloudwatch/logGroup:LogGroup")
			d3bWantNumber(t, logs.Inputs, "retentionInDays", 7)
			role := d3bOne(t, mocks, "aws:iam/role:Role")
			var assume, wantAssume map[string]interface{}
			if err := json.Unmarshal([]byte(d3bString(t, role.Inputs, "assumeRolePolicy")), &assume); err != nil {
				t.Fatal(err)
			}
			json.Unmarshal([]byte(`{"Version":"2012-10-17","Statement":[{"Effect":"Allow","Principal":{"Service":"ecs-tasks.amazonaws.com"},"Action":"sts:AssumeRole"}]}`), &wantAssume)
			if !reflect.DeepEqual(assume, wantAssume) {
				t.Error("task execution trust changed")
			}
			policy := d3bOne(t, mocks, "aws:iam/rolePolicy:RolePolicy")
			d3bWantString(t, policy.Inputs, "role", spec.name+"-workload-execution-mock-id")
			var policyJSON, wantPolicy map[string]interface{}
			if err := json.Unmarshal([]byte(d3bString(t, policy.Inputs, "policy")), &policyJSON); err != nil {
				t.Fatal(err)
			}
			expectedPolicy := fmt.Sprintf(`{"Version":"2012-10-17","Statement":[{"Effect":"Allow","Action":["logs:CreateLogStream","logs:PutLogEvents"],"Resource":"fixture-reference-%s-workload-logs:*"}]}`, spec.name)
			json.Unmarshal([]byte(expectedPolicy), &wantPolicy)
			if !reflect.DeepEqual(policyJSON, wantPolicy) {
				t.Error("log policy output wiring changed")
			}
			task := d3bOne(t, mocks, "aws:ecs/taskDefinition:TaskDefinition")
			d3bWantString(t, task.Inputs, "family", spec.name+"-workload")
			d3bWantString(t, task.Inputs, "cpu", "256")
			d3bWantString(t, task.Inputs, "memory", "512")
			d3bWantString(t, task.Inputs, "networkMode", "awsvpc")
			d3bWantString(t, task.Inputs, "executionRoleArn", "fixture-reference-"+spec.name+"-workload-execution")
			if got := d3bStrings(t, task.Inputs, "requiresCompatibilities"); !reflect.DeepEqual(got, []string{"FARGATE"}) {
				t.Errorf("runtime compatibility changed: %v", got)
			}
			var containers, wantContainers []map[string]interface{}
			if err := json.Unmarshal([]byte(d3bString(t, task.Inputs, "containerDefinitions")), &containers); err != nil {
				t.Fatal(err)
			}
			expectedContainers := fmt.Sprintf(`[{"name":"api","image":"fixture.invalid/api@sha256:%s","essential":true,"portMappings":[{"containerPort":8080,"protocol":"tcp"}],"healthCheck":{"command":["CMD-SHELL","curl -f http://localhost:8080/health || exit 1"],"interval":30,"timeout":5,"retries":3},"logConfiguration":{"logDriver":"awslogs","options":{"awslogs-group":"%s-workload-logs","awslogs-region":"%s","awslogs-stream-prefix":"api"}}}]`, strings.Repeat("a", 64), spec.name, spec.region)
			if err := json.Unmarshal([]byte(expectedContainers), &wantContainers); err != nil {
				t.Fatal(err)
			}
			if !reflect.DeepEqual(containers, wantContainers) {
				t.Error("container runtime/image/health/log output wiring changed")
			}
			service := d3bOne(t, mocks, "aws:ecs/service:Service")
			d3bWantNumber(t, service.Inputs, "desiredCount", float64(spec.capacity))
			d3bWantString(t, service.Inputs, "cluster", "fixture-reference-"+spec.name+"-workload-cluster")
			d3bWantString(t, service.Inputs, "taskDefinition", "fixture-reference-"+spec.name+"-workload-task")
			d3bWantString(t, service.Inputs, "launchType", "FARGATE")
			network := d3bObject(t, service.Inputs, "networkConfiguration")
			if got := d3bStrings(t, network, "subnets"); !reflect.DeepEqual(got, spec.subnets) {
				t.Errorf("ECS subnet wiring: got %v, want %v", got, spec.subnets)
			}
			if got := d3bStrings(t, network, "securityGroups"); !reflect.DeepEqual(got, []string{spec.name + "-workload-service-sg-mock-id"}) {
				t.Errorf("ECS SG output wiring: got %v", got)
			}
			d3bWantBool(t, network, "assignPublicIp", true)
			dependsOnPolicy := false
			for _, dependency := range service.RegisterRPC.GetDependencies() {
				dependsOnPolicy = dependsOnPolicy || strings.HasSuffix(dependency, "::"+spec.name+"-workload-logs-policy")
			}
			if !dependsOnPolicy {
				t.Error("service log policy dependency missing")
			}
			mocks.mu.Lock()
			outputs := map[string]string{"bucketName": mocks.outputs["bucketName"], "serviceName": mocks.outputs["serviceName"]}
			mocks.mu.Unlock()
			expectedOutputs := map[string]string{"bucketName": bucket.Name + "-mock", "serviceName": spec.name + "-workload-service"}
			if !reflect.DeepEqual(outputs, expectedOutputs) {
				t.Errorf("workspace outputs: got %v, want %v", outputs, expectedOutputs)
			}
		})
	}
}
func TestHarnessD3bUnknownImageRegistration(t *testing.T) {
	for _, spec := range d3bContracts() {
		t.Run(spec.name, func(t *testing.T) {
			args := d3bArgs(spec)
			args.Image = pulumi.UnsafeUnknownOutput(nil).ApplyT(func(value interface{}) string { return value.(string) }).(pulumi.StringOutput)
			mocks := &d3bMocks{outputs: map[string]string{}}
			err := pulumi.RunErr(func(ctx *pulumi.Context) error { _, err := New(ctx, spec.name, args); return err }, pulumi.WithMocks("daily-workspace", spec.name, mocks), func(info *pulumi.RunInfo) { info.DryRun = true })
			if err != nil {
				t.Fatal(err)
			}
			d3bAssertInventory(t, spec, mocks)
			d3bOne(t, mocks, "aws:ecs/taskDefinition:TaskDefinition")
			d3bOne(t, mocks, "aws:ecs/service:Service")
		})
	}
}

// Frozen pre-rename NonProd identities are independent of coder files and environment.
const d3bFrozenNonProdIdentity = `[
  {
    "Type": "aws:cloudwatch/logGroup:LogGroup",
    "Name": "nonprod-workload-logs",
    "Parent": "urn:pulumi:nonprod::daily-workspace::xbrain:workspace:Workspace$xbrain:workload:Workload::nonprod-workload",
    "Provider": "urn:pulumi:nonprod::daily-workspace::pulumi:providers:aws::nonprod-aws::nonprod-aws-mock-id"
  },
  {
    "Type": "aws:ec2/securityGroup:SecurityGroup",
    "Name": "nonprod-workload-service-sg",
    "Parent": "urn:pulumi:nonprod::daily-workspace::xbrain:workspace:Workspace$xbrain:workload:Workload::nonprod-workload",
    "Provider": "urn:pulumi:nonprod::daily-workspace::pulumi:providers:aws::nonprod-aws::nonprod-aws-mock-id"
  },
  {
    "Type": "aws:ecs/cluster:Cluster",
    "Name": "nonprod-workload-cluster",
    "Parent": "urn:pulumi:nonprod::daily-workspace::xbrain:workspace:Workspace$xbrain:workload:Workload::nonprod-workload",
    "Provider": "urn:pulumi:nonprod::daily-workspace::pulumi:providers:aws::nonprod-aws::nonprod-aws-mock-id"
  },
  {
    "Type": "aws:ecs/service:Service",
    "Name": "nonprod-workload-service",
    "Parent": "urn:pulumi:nonprod::daily-workspace::xbrain:workspace:Workspace$xbrain:workload:Workload::nonprod-workload",
    "Provider": "urn:pulumi:nonprod::daily-workspace::pulumi:providers:aws::nonprod-aws::nonprod-aws-mock-id"
  },
  {
    "Type": "aws:ecs/taskDefinition:TaskDefinition",
    "Name": "nonprod-workload-task",
    "Parent": "urn:pulumi:nonprod::daily-workspace::xbrain:workspace:Workspace$xbrain:workload:Workload::nonprod-workload",
    "Provider": "urn:pulumi:nonprod::daily-workspace::pulumi:providers:aws::nonprod-aws::nonprod-aws-mock-id"
  },
  {
    "Type": "aws:iam/role:Role",
    "Name": "nonprod-workload-execution",
    "Parent": "urn:pulumi:nonprod::daily-workspace::xbrain:workspace:Workspace$xbrain:workload:Workload::nonprod-workload",
    "Provider": "urn:pulumi:nonprod::daily-workspace::pulumi:providers:aws::nonprod-aws::nonprod-aws-mock-id"
  },
  {
    "Type": "aws:iam/rolePolicy:RolePolicy",
    "Name": "nonprod-workload-logs-policy",
    "Parent": "urn:pulumi:nonprod::daily-workspace::xbrain:workspace:Workspace$xbrain:workload:Workload::nonprod-workload",
    "Provider": "urn:pulumi:nonprod::daily-workspace::pulumi:providers:aws::nonprod-aws::nonprod-aws-mock-id"
  },
  {
    "Type": "aws:s3/bucket:Bucket",
    "Name": "nonprod-storage-uploads",
    "Parent": "urn:pulumi:nonprod::daily-workspace::xbrain:workspace:Workspace$xbrain:storage:Storage::nonprod-storage",
    "Provider": "urn:pulumi:nonprod::daily-workspace::pulumi:providers:aws::nonprod-aws::nonprod-aws-mock-id"
  },
  {
    "Type": "aws:s3/bucketPublicAccessBlock:BucketPublicAccessBlock",
    "Name": "nonprod-storage-uploads-access",
    "Parent": "urn:pulumi:nonprod::daily-workspace::xbrain:workspace:Workspace$xbrain:storage:Storage::nonprod-storage",
    "Provider": "urn:pulumi:nonprod::daily-workspace::pulumi:providers:aws::nonprod-aws::nonprod-aws-mock-id"
  },
  {
    "Type": "pulumi:providers:aws",
    "Name": "nonprod-aws",
    "Parent": "urn:pulumi:nonprod::daily-workspace::pulumi:pulumi:Stack::daily-workspace-nonprod",
    "Provider": ""
  },
  {
    "Type": "xbrain:storage:Storage",
    "Name": "nonprod-storage",
    "Parent": "urn:pulumi:nonprod::daily-workspace::xbrain:workspace:Workspace::nonprod",
    "Provider": ""
  },
  {
    "Type": "xbrain:workload:Workload",
    "Name": "nonprod-workload",
    "Parent": "urn:pulumi:nonprod::daily-workspace::xbrain:workspace:Workspace::nonprod",
    "Provider": ""
  },
  {
    "Type": "xbrain:workspace:Workspace",
    "Name": "nonprod",
    "Parent": "urn:pulumi:nonprod::daily-workspace::pulumi:pulumi:Stack::daily-workspace-nonprod",
    "Provider": ""
  }
]`

// The accepted public Go API exports ReplicaCount and removes DesiredCount.
func TestHarnessD3bPublicAPI(t *testing.T) {
	types := []struct {
		name  string
		value reflect.Type
	}{
		{name: "workspace.Args", value: reflect.TypeOf(Args{})},
		{name: "workload.Args", value: reflect.TypeOf(workload.Args{})},
	}
	for _, item := range types {
		t.Run(item.name, func(t *testing.T) {
			field, exists := item.value.FieldByName("ReplicaCount")
			if !exists || field.PkgPath != "" || field.Type.Kind() != reflect.Int {
				t.Error("public ReplicaCount int field is required")
			}
			if _, exists := item.value.FieldByName("DesiredCount"); exists {
				t.Error("legacy DesiredCount Go API must be removed")
			}
		})
	}
}

// This matcher verifies declarations and predicts the documented prefix inheritance only.
// Default WithMocks does not resolve aliases, old physical IDs, retained data, or migration.
// References: SDK v3.263.0 alias.go:112-149, context.go:2192-2233/2551-2606, mocks.go:200.
func d3bURN(stack, project, token, name, parent string) string {
	if parent != "" {
		return parent[:strings.LastIndex(parent, "::")] + "$" + token + "::" + name
	}
	return "urn:pulumi:" + stack + "::" + project + "::" + token + "::" + name
}
func d3bValidURN(value string) bool {
	parts := strings.Split(value, "::")
	return len(parts) == 4 && strings.HasPrefix(parts[0], "urn:pulumi:") && len(strings.TrimPrefix(parts[0], "urn:pulumi:")) > 0 && parts[1] != "" && parts[2] != "" && parts[3] != ""
}
func d3bAliasDeclarations(spec d3bContract, item pulumi.MockResourceArgs) (map[string]bool, []string) {
	result := map[string]bool{}
	qualified := []string{}
	rpc := item.RegisterRPC
	for _, value := range rpc.GetAliasURNs() {
		if d3bValidURN(value) {
			result[value] = true
		} else {
			qualified = append(qualified, "unrecognized legacy alias URN")
		}
	}
	for _, alias := range rpc.GetAliases() {
		if value := alias.GetUrn(); value != "" {
			if d3bValidURN(value) {
				result[value] = true
			} else {
				qualified = append(qualified, "unrecognized alias URN")
			}
			continue
		}
		old := alias.GetSpec()
		if old == nil || len(alias.ProtoReflect().GetUnknown()) != 0 || (old != nil && len(old.ProtoReflect().GetUnknown()) != 0) {
			qualified = append(qualified, "unrecognized alias representation requires source review")
			continue
		}
		name, token, stack, project, parent := item.Name, item.TypeToken, spec.name, "daily-workspace", rpc.GetParent()
		if old.GetName() != "" {
			name = old.GetName()
		}
		if old.GetType() != "" {
			token = old.GetType()
		}
		if old.GetStack() != "" {
			stack = old.GetStack()
		}
		if old.GetProject() != "" {
			project = old.GetProject()
		}
		switch previous := old.GetParent().(type) {
		case nil:
		case *pulumirpc.Alias_Spec_ParentUrn:
			parent = previous.ParentUrn
		case *pulumirpc.Alias_Spec_NoParent:
			if previous.NoParent {
				parent = ""
			}
		default:
			qualified = append(qualified, "unrecognized alias parent representation requires source review")
			continue
		}
		if parent != "" && !d3bValidURN(parent) {
			qualified = append(qualified, "unrecognized alias parent URN")
			continue
		}
		// Explicit stack/project changes cannot cover the frozen current target identity.
		if stack != spec.name || project != "daily-workspace" {
			continue
		}
		result[d3bURN(stack, project, token, name, parent)] = true
	}
	return result, qualified
}
func d3bAssertAliasCoverage(t *testing.T, spec d3bContract, m *d3bMocks) {
	t.Helper()
	var old []d3bIdentity
	if err := json.Unmarshal([]byte(strings.ReplaceAll(d3bFrozenNonProdIdentity, "nonprod", spec.name)), &old); err != nil {
		t.Fatal(err)
	}
	component := d3bOne(t, m, "xbrain:storage:Storage")
	componentURN := d3bURN(spec.name, "daily-workspace", component.TypeToken, component.Name, component.RegisterRPC.GetParent())
	declaredParent, parentQualified := d3bAliasDeclarations(spec, component)
	coverage := map[string]string{}
	missing := []string{}
	qualification := []string{}
	for _, expected := range old {
		if expected.Type != "xbrain:storage:Storage" && expected.Type != "aws:s3/bucket:Bucket" && expected.Type != "aws:s3/bucketPublicAccessBlock:BucketPublicAccessBlock" {
			continue
		}
		target := d3bURN(spec.name, "daily-workspace", expected.Type, expected.Name, expected.Parent)
		current := d3bOne(t, m, expected.Type)
		declarations, unfamiliar := d3bAliasDeclarations(spec, current)
		raw, _ := json.Marshal(current.RegisterRPC.GetAliases())
		t.Logf("D3b_ALIAS_DECLARATIONS:%s/%s:%s", spec.name, expected.Type, raw)
		if declarations[target] {
			coverage[target] = "declared equivalent old identity"
			continue
		}
		if expected.Type != "xbrain:storage:Storage" && current.RegisterRPC.GetParent() == componentURN && strings.HasPrefix(current.Name, component.Name) {
			// SDK collapseAliases also combines each declared child alias with each parent alias.
			candidates := map[string]bool{d3bURN(spec.name, "daily-workspace", current.TypeToken, current.Name, current.RegisterRPC.GetParent()): true}
			for candidate := range declarations {
				candidates[candidate] = true
			}
			for parentAlias := range declaredParent {
				parentParts := strings.Split(parentAlias, "::")
				for childAlias := range candidates {
					childParts := strings.Split(childAlias, "::")
					childName := childParts[3]
					childType := childParts[2][strings.LastIndex(childParts[2], "$")+1:]
					if strings.HasPrefix(childName, component.Name) {
						childName = parentParts[3] + childName[len(component.Name):]
					}
					candidate := d3bURN(spec.name, "daily-workspace", childType, childName, parentAlias)
					if candidate == target {
						coverage[target] = "documented inherited component/child alias coverage"
						break
					}
				}
				if coverage[target] != "" {
					break
				}
			}
		}
		if coverage[target] != "" {
			continue
		}
		unfamiliar = append(unfamiliar, parentQualified...)
		if len(unfamiliar) > 0 {
			qualification = append(qualification, target+": "+strings.Join(unfamiliar, "; "))
		} else {
			missing = append(missing, target)
		}
	}
	encoded, _ := json.Marshal(coverage)
	t.Log("D3b_OLD_IDENTITY_COVERAGE:" + string(encoded))
	for _, target := range missing {
		t.Errorf("D3B_UNCOVERED_OLD_IDENTITY:%s", target)
	}
	if len(qualification) > 0 {
		// Unproven coverage requires source-backed review and cannot exit as a clean check.
		// This classification does not assert that the unfamiliar declaration is a defect.
		t.Errorf("D3B_ALIAS_REVIEW_QUALIFICATION: %s", strings.Join(qualification, " | "))
	}
}
func TestHarnessD3bAliasCoverage(t *testing.T) {
	for _, spec := range d3bContracts() {
		for _, unknown := range []bool{false, true} {
			mode := "known-image"
			if unknown {
				mode = "unknown-image"
			}
			t.Run(spec.name+"/"+mode, func(t *testing.T) {
				args := d3bArgs(spec)
				if unknown {
					args.Image = pulumi.UnsafeUnknownOutput(nil).ApplyT(func(value interface{}) string { return value.(string) }).(pulumi.StringOutput)
				}
				mocks := &d3bMocks{outputs: map[string]string{}}
				err := pulumi.RunErr(func(ctx *pulumi.Context) error { _, err := New(ctx, spec.name, args); return err }, pulumi.WithMocks("daily-workspace", spec.name, mocks), func(info *pulumi.RunInfo) { info.DryRun = unknown })
				if err != nil {
					t.Fatal(err)
				}
				d3bAssertInventory(t, spec, mocks)
				d3bAssertAliasCoverage(t, spec, mocks)
			})
		}
	}
}

// Independent controller records exercise an equivalent combined declaration, without coder helpers.
func TestHarnessD3bEquivalentCombinedDeclarations(t *testing.T) {
	spec := d3bContracts()[0]
	stem := spec.name + "-object-store"
	workspaceURN := "urn:pulumi:" + spec.name + "::daily-workspace::xbrain:workspace:Workspace::" + spec.name
	componentURN := d3bURN(spec.name, "daily-workspace", "xbrain:storage:Storage", stem, workspaceURN)
	for _, fullURN := range []bool{false, true} {
		t.Run(fmt.Sprintf("child-full-URN-%t", fullURN), func(t *testing.T) {
			child := &pulumirpc.Alias{Alias: &pulumirpc.Alias_Spec_{Spec: &pulumirpc.Alias_Spec{Name: stem + "-uploads"}}}
			if fullURN {
				child = &pulumirpc.Alias{Alias: &pulumirpc.Alias_Urn{Urn: d3bURN(spec.name, "daily-workspace", "aws:s3/bucket:Bucket", stem+"-uploads", componentURN)}}
			}
			records := []pulumi.MockResourceArgs{
				{TypeToken: "xbrain:storage:Storage", Name: stem, RegisterRPC: &pulumirpc.RegisterResourceRequest{Parent: workspaceURN, Aliases: []*pulumirpc.Alias{{Alias: &pulumirpc.Alias_Spec_{Spec: &pulumirpc.Alias_Spec{Name: spec.name + "-storage"}}}}}},
				{TypeToken: "aws:s3/bucket:Bucket", Name: stem + "-uploads-v2", RegisterRPC: &pulumirpc.RegisterResourceRequest{Parent: componentURN, Aliases: []*pulumirpc.Alias{child}}},
				{TypeToken: "aws:s3/bucketPublicAccessBlock:BucketPublicAccessBlock", Name: stem + "-uploads-access", RegisterRPC: &pulumirpc.RegisterResourceRequest{Parent: componentURN}},
			}
			d3bAssertAliasCoverage(t, spec, &d3bMocks{records: records})
		})
	}
}

// A child process proves the unfamiliar-representation branch fails the test executable.
// The parent succeeds only after observing the explicit source-review classification.
func TestHarnessD3bUnfamiliarAliasRequiresReview(t *testing.T) {
	const branch = "D3B_CONTROLLER_UNKNOWN_ALIAS_BRANCH"
	if os.Getenv(branch) == "1" {
		spec := d3bContracts()[0]
		stem := spec.name + "-object-store"
		workspaceURN := "urn:pulumi:" + spec.name + "::daily-workspace::xbrain:workspace:Workspace::" + spec.name
		componentURN := d3bURN(spec.name, "daily-workspace", "xbrain:storage:Storage", stem, workspaceURN)
		future := &pulumirpc.Alias{}
		// Unknown protobuf field 3 models a representation outside the pinned matcher.
		future.ProtoReflect().SetUnknown([]byte{0x18, 0x01})
		records := []pulumi.MockResourceArgs{
			{TypeToken: "xbrain:storage:Storage", Name: stem, RegisterRPC: &pulumirpc.RegisterResourceRequest{Parent: workspaceURN, Aliases: []*pulumirpc.Alias{future}}},
			{TypeToken: "aws:s3/bucket:Bucket", Name: stem + "-uploads", RegisterRPC: &pulumirpc.RegisterResourceRequest{Parent: componentURN}},
			{TypeToken: "aws:s3/bucketPublicAccessBlock:BucketPublicAccessBlock", Name: stem + "-uploads-access", RegisterRPC: &pulumirpc.RegisterResourceRequest{Parent: componentURN}},
		}
		d3bAssertAliasCoverage(t, spec, &d3bMocks{records: records})
		return
	}
	command := exec.Command(os.Args[0], "-test.v", "-test.run=^TestHarnessD3bUnfamiliarAliasRequiresReview$")
	command.Env = append(os.Environ(), branch+"=1")
	output, err := command.CombinedOutput()
	failure, ok := err.(*exec.ExitError)
	if !ok || failure.ExitCode() != 1 {
		t.Fatalf("unproven coverage must fail the child test executable: err=%v output=%s", err, output)
	}
	text := string(output)
	if !strings.Contains(text, "D3B_ALIAS_REVIEW_QUALIFICATION:") || strings.Contains(text, "D3B_UNCOVERED_OLD_IDENTITY:") {
		t.Fatalf("child must request source review without asserting a confirmed coverage defect: %s", output)
	}
	t.Log("D3B_QUALIFICATION_GUARD: child exit 1; explicit source-review classification observed")
}
