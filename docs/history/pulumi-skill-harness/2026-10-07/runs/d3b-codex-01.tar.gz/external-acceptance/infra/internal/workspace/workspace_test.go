package workspace

import (
	"encoding/json"
	"fmt"
	"reflect"
	"strings"
	"testing"

	"github.com/pulumi/pulumi/sdk/v3/go/common/resource"
	"github.com/pulumi/pulumi/sdk/v3/go/common/resource/plugin"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
	"xbrain.local/daily/internal/testutil"
	"xbrain.local/daily/internal/workload"
)

func TestReplicaCountAPI(t *testing.T) {
	for _, tc := range []struct {
		name string
		args reflect.Type
	}{
		{"workspace", reflect.TypeOf(Args{})},
		{"workload", reflect.TypeOf(workload.Args{})},
	} {
		t.Run(tc.name, func(t *testing.T) {
			field, ok := tc.args.FieldByName("ReplicaCount")
			if !ok || field.Type != reflect.TypeOf(int(0)) {
				t.Error("ReplicaCount must be an exported int field")
			}
			if _, legacy := tc.args.FieldByName("DesiredCount"); legacy {
				t.Error("DesiredCount must be removed from the Go API")
			}
		})
	}
}

func TestWorkspaceContracts(t *testing.T) {
	for _, tc := range []struct {
		environment string
		prefix      string
		capacity    int
		vpc         string
		subnets     []string
	}{
		{"nonprod", "xbrain-nonprod-uploads-", 1, "fixture-vpc", []string{"fixture-subnet-a"}},
		{"uat", "xbrain-uat-uploads-", 2, "fixture-vpc-uat", []string{"fixture-subnet-uat-a", "fixture-subnet-uat-b"}},
	} {
		for _, unknownImage := range []bool{false, true} {
			mode := "known-image"
			if unknownImage {
				mode = "unknown-image-dryrun"
			}
			t.Run(tc.environment+"/"+mode, func(t *testing.T) {
				name := tc.environment
				image := "fixture.invalid/api@sha256:" + strings.Repeat("a", 64)
				imageInput := pulumi.StringInput(pulumi.String(image))
				if unknownImage {
					imageInput = pulumi.UnsafeUnknownOutput(nil).ApplyT(func(_ interface{}) string {
						t.Error("unknown image callback must not run")
						return ""
					}).(pulumi.StringOutput)
				}
				mocks := &testutil.Mocks{}
				subnets := make(pulumi.StringArray, len(tc.subnets))
				for i, ref := range tc.subnets {
					subnets[i] = pulumi.String(ref)
				}
				err := pulumi.RunErr(func(ctx *pulumi.Context) error {
					result, err := New(ctx, name, &Args{
						Environment: tc.environment, Region: "ap-southeast-1", StoragePrefix: tc.prefix, ReplicaCount: tc.capacity,
						Image: imageInput, VpcID: pulumi.String(tc.vpc),
						SubnetIDs: subnets, PeerCIDR: "10.30.0.0/16",
					})
					if err != nil {
						return err
					}
					ctx.Export("outputsChecked", pulumi.All(result.BucketName, result.ServiceName).ApplyT(func(values []interface{}) (bool, error) {
						if values[0] != name+"-object-store-uploads-mock" || values[1] != name+"-workload-service" {
							return false, fmt.Errorf("workspace outputs do not come from its children")
						}
						return true, nil
					}))
					return nil
				}, pulumi.WithMocks("daily-workspace", name, mocks), func(info *pulumi.RunInfo) {
					info.DryRun = unknownImage
				})
				if err != nil {
					t.Fatal(err)
				}

				urn := func(token, logicalName string) string {
					return "urn:pulumi:" + name + "::daily-workspace::" + token + "::" + logicalName
				}
				workspaceURN := urn("xbrain:workspace:Workspace", name)
				stackURN := urn("pulumi:pulumi:Stack", "daily-workspace-"+name)
				storageURN := urn("xbrain:workspace:Workspace$xbrain:storage:Storage", name+"-object-store")
				workloadURN := urn("xbrain:workspace:Workspace$xbrain:workload:Workload", name+"-workload")
				provider := urn("pulumi:providers:aws", name+"-aws") + "::" + name + "-aws-mock-id"
				expected := map[string]struct{ token, parent string }{
					name + "-aws":                         {"pulumi:providers:aws", stackURN},
					name:                                  {"xbrain:workspace:Workspace", stackURN},
					name + "-object-store":                {"xbrain:storage:Storage", workspaceURN},
					name + "-object-store-uploads":        {"aws:s3/bucket:Bucket", storageURN},
					name + "-object-store-uploads-access": {"aws:s3/bucketPublicAccessBlock:BucketPublicAccessBlock", storageURN},
					name + "-workload":                    {"xbrain:workload:Workload", workspaceURN},
					name + "-workload-logs":               {"aws:cloudwatch/logGroup:LogGroup", workloadURN},
					name + "-workload-execution":          {"aws:iam/role:Role", workloadURN},
					name + "-workload-logs-policy":        {"aws:iam/rolePolicy:RolePolicy", workloadURN},
					name + "-workload-service-sg":         {"aws:ec2/securityGroup:SecurityGroup", workloadURN},
					name + "-workload-cluster":            {"aws:ecs/cluster:Cluster", workloadURN},
					name + "-workload-task":               {"aws:ecs/taskDefinition:TaskDefinition", workloadURN},
					name + "-workload-service":            {"aws:ecs/service:Service", workloadURN},
				}
				resources := map[string]pulumi.MockResourceArgs{}
				for _, item := range mocks.Resources() {
					identity, ok := expected[item.Name]
					if !ok || item.TypeToken != identity.token {
						t.Fatalf("unexpected resource identity: %s (%s)", item.Name, item.TypeToken)
					}
					if _, duplicate := resources[item.Name]; duplicate {
						t.Fatalf("duplicate owner: %s", item.Name)
					}
					resources[item.Name] = item
					if item.RegisterRPC == nil || item.RegisterRPC.GetParent() != identity.parent {
						t.Errorf("parent changed for %s", item.Name)
					}
					if item.ID != "" || item.ReadRPC != nil {
						t.Errorf("unexpected import/read for %s", item.Name)
					}
					if strings.HasPrefix(item.TypeToken, "aws:") {
						if item.Provider != provider {
							t.Errorf("provider inheritance changed for %s", item.Name)
						}
						if item.TypeToken != "aws:s3/bucketPublicAccessBlock:BucketPublicAccessBlock" && item.TypeToken != "aws:iam/rolePolicy:RolePolicy" {
							checkProperty(t, item.Inputs, "tags", map[string]string{"Team": "xbrain", "Environment": tc.environment})
						}
					}
				}
				if len(resources) != len(expected) {
					t.Fatalf("resource inventory changed: got %d, want %d", len(resources), len(expected))
				}
				testutil.CheckStorageAliasCoverage(t, mocks.Resources(), "daily-workspace", name, name)
				checkProperty(t, resources[name+"-aws"].Inputs, "region", "ap-southeast-1")
				bucket := resources[name+"-object-store-uploads"].Inputs
				checkProperty(t, bucket, "bucketPrefix", tc.prefix)
				if _, fixedName := bucket["bucket"]; fixedName {
					t.Error("bucket must keep provider auto-naming")
				}
				access := resources[name+"-object-store-uploads-access"].Inputs
				checkProperty(t, access, "bucket", name+"-object-store-uploads-mock-id")
				for _, key := range []string{"blockPublicAcls", "blockPublicPolicy", "ignorePublicAcls", "restrictPublicBuckets"} {
					checkProperty(t, access, key, true)
				}
				checkProperty(t, resources[name+"-workload-logs"].Inputs, "retentionInDays", 7)
				group := resources[name+"-workload-service-sg"].Inputs
				checkProperty(t, group, "vpcId", tc.vpc)
				checkProperty(t, group, "ingress", []interface{}{map[string]interface{}{
					"protocol": "tcp", "fromPort": 8080, "toPort": 8080, "cidrBlocks": []string{"10.30.0.0/16"},
				}})
				checkProperty(t, group, "egress", []interface{}{map[string]interface{}{
					"protocol": "-1", "fromPort": 0, "toPort": 0, "cidrBlocks": []string{"0.0.0.0/0"},
				}})
				task := resources[name+"-workload-task"].Inputs
				for key, value := range map[string]interface{}{
					"family": name + "-workload", "cpu": "256", "memory": "512", "networkMode": "awsvpc",
					"requiresCompatibilities": []string{"FARGATE"}, "executionRoleArn": "fixture-reference-" + name + "-workload-execution",
				} {
					checkProperty(t, task, key, value)
				}
				var containers []map[string]interface{}
				if unknownImage {
					wireInputs, err := plugin.UnmarshalProperties(resources[name+"-workload-task"].RegisterRPC.GetObject(), plugin.MarshalOptions{
						KeepUnknowns: true, KeepSecrets: true, KeepResources: true,
					})
					if err != nil {
						t.Fatal("cannot decode DryRun task registration")
					}
					if !wireInputs["containerDefinitions"].ContainsUnknowns() {
						t.Error("DryRun task must keep unknown image-dependent definitions")
					}
				} else if err := json.Unmarshal([]byte(task["containerDefinitions"].StringValue()), &containers); err != nil {
					t.Fatal("invalid container JSON")
				}
				wantContainers := []map[string]interface{}{{
					"name": "api", "image": image, "essential": true,
					"portMappings": []interface{}{map[string]interface{}{"containerPort": float64(8080), "protocol": "tcp"}},
					"healthCheck": map[string]interface{}{
						"command":  []interface{}{"CMD-SHELL", "curl -f http://localhost:8080/health || exit 1"},
						"interval": float64(30), "timeout": float64(5), "retries": float64(3),
					},
					"logConfiguration": map[string]interface{}{"logDriver": "awslogs", "options": map[string]interface{}{
						"awslogs-group": name + "-workload-logs", "awslogs-region": "ap-southeast-1", "awslogs-stream-prefix": "api",
					}},
				}}
				if !unknownImage && !reflect.DeepEqual(containers, wantContainers) {
					t.Error("container contract changed")
				}
				policy := resources[name+"-workload-logs-policy"].Inputs
				checkProperty(t, policy, "role", name+"-workload-execution-mock-id")
				var logPolicy map[string]interface{}
				if err := json.Unmarshal([]byte(policy["policy"].StringValue()), &logPolicy); err != nil {
					t.Fatal("invalid log policy JSON")
				}
				wantPolicy := map[string]interface{}{"Version": "2012-10-17", "Statement": []interface{}{map[string]interface{}{
					"Effect": "Allow", "Action": []interface{}{"logs:CreateLogStream", "logs:PutLogEvents"},
					"Resource": "fixture-reference-" + name + "-workload-logs:*",
				}}}
				if !reflect.DeepEqual(logPolicy, wantPolicy) {
					t.Error("log policy must consume the log group output")
				}
				service := resources[name+"-workload-service"]
				checkProperty(t, service.Inputs, "desiredCount", tc.capacity)
				checkProperty(t, service.Inputs, "launchType", "FARGATE")
				checkProperty(t, service.Inputs, "cluster", "fixture-reference-"+name+"-workload-cluster")
				checkProperty(t, service.Inputs, "taskDefinition", "fixture-reference-"+name+"-workload-task")
				checkProperty(t, service.Inputs, "networkConfiguration", map[string]interface{}{
					"subnets": tc.subnets, "securityGroups": []string{name + "-workload-service-sg-mock-id"}, "assignPublicIp": true,
				})
				policyURN := urn("xbrain:workspace:Workspace$xbrain:workload:Workload$aws:iam/rolePolicy:RolePolicy", name+"-workload-logs-policy")
				foundPolicyDependency := false
				for _, dependency := range service.RegisterRPC.GetDependencies() {
					foundPolicyDependency = foundPolicyDependency || dependency == policyURN
				}
				if !foundPolicyDependency {
					t.Error("service must wait for execution log policy")
				}
			})
		}
	}
}

func checkProperty(t *testing.T, properties resource.PropertyMap, key string, want interface{}) {
	t.Helper()
	if !properties[resource.PropertyKey(key)].DeepEquals(resource.NewPropertyValue(want)) {
		t.Errorf("property %s does not match the contract", key)
	}
}
