package testutil

import (
	"fmt"
	"github.com/pulumi/pulumi/sdk/v3/go/common/resource"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
	"sync"
)

type Mocks struct {
	mu        sync.Mutex
	resources []pulumi.MockResourceArgs
}

func (m *Mocks) Call(args pulumi.MockCallArgs) (resource.PropertyMap, error) {
	return nil, fmt.Errorf("unexpected provider invoke in offline fixture: %s", args.Token)
}
func (m *Mocks) NewResource(args pulumi.MockResourceArgs) (string, resource.PropertyMap, error) {
	m.mu.Lock()
	m.resources = append(m.resources, args)
	m.mu.Unlock()
	outputs := args.Inputs.Copy()
	outputs["name"] = resource.NewStringProperty(args.Name)
	outputs["arn"] = resource.NewStringProperty("fixture-reference-" + args.Name)
	if args.TypeToken == "aws:s3/bucket:Bucket" {
		outputs["bucket"] = resource.NewStringProperty(args.Name + "-mock")
	}
	return args.Name + "-mock-id", outputs, nil
}
func (m *Mocks) Resources() []pulumi.MockResourceArgs {
	m.mu.Lock()
	defer m.mu.Unlock()
	return append([]pulumi.MockResourceArgs(nil), m.resources...)
}
