package testutil

import (
	"strings"
	"testing"

	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
)

// Chi kiem tra declarations va dieu kien inheritance; khong resolve aliases nhu engine.
func CheckStorageAliasCoverage(t *testing.T, resources []pulumi.MockResourceArgs, project, stack, target string) {
	t.Helper()
	newStem, oldStem := target+"-object-store", target+"-storage"
	qualifiedType := "xbrain:workspace:Workspace$xbrain:storage:Storage"
	newParent := "urn:pulumi:" + stack + "::" + project + "::" + qualifiedType + "::" + newStem
	oldParent := "urn:pulumi:" + stack + "::" + project + "::" + qualifiedType + "::" + oldStem
	var component pulumi.MockResourceArgs
	children := make(map[string]pulumi.MockResourceArgs)
	for _, item := range resources {
		switch item.TypeToken {
		case "xbrain:storage:Storage":
			component = item
		case "aws:s3/bucket:Bucket":
			children["-uploads"] = item
		case "aws:s3/bucketPublicAccessBlock:BucketPublicAccessBlock":
			children["-uploads-access"] = item
		default:
			if item.RegisterRPC != nil && len(item.RegisterRPC.GetAliases()) != 0 {
				t.Errorf("unexpected alias outside storage: %s", item.Name)
			}
		}
	}
	if component.Name != newStem || component.RegisterRPC == nil {
		t.Fatal("missing renamed storage component")
	}
	covered := false
	for _, alias := range component.RegisterRPC.GetAliases() {
		if alias.GetUrn() == oldParent {
			covered = true
		}
		if spec := alias.GetSpec(); spec != nil && spec.GetName() == oldStem &&
			(spec.GetType() == "" || spec.GetType() == component.TypeToken) &&
			(spec.GetProject() == "" || spec.GetProject() == project) &&
			(spec.GetStack() == "" || spec.GetStack() == stack) && !spec.GetNoParent() &&
			(spec.GetParentUrn() == "" || spec.GetParentUrn() == component.RegisterRPC.GetParent()) {
			covered = true
		}
	}
	if !covered {
		t.Error("storage alias declaration does not cover its old identity")
	}
	for suffix, child := range children {
		if child.Name != newStem+suffix || child.RegisterRPC == nil || child.RegisterRPC.GetParent() != newParent ||
			!strings.HasPrefix(child.Name, component.Name) {
			t.Errorf("child %s does not satisfy parent alias name-prefix inheritance", child.Name)
		}
	}
	if len(children) != 2 {
		t.Error("missing storage children for inherited alias coverage")
	}
}
