package main

// Upstream app scope control; khong phai runtime image cua lab.
func main() {}
