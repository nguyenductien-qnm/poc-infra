module xbrain.local/app-scope-control

go 1.26.6
