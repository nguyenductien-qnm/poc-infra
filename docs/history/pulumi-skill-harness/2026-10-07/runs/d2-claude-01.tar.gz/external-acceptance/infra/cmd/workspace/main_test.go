package main

import (
	"encoding/json"
	"fmt"
	"os"
	"strings"
	"testing"

	"github.com/pulumi/pulumi/sdk/v3/go/common/resource"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
	"gopkg.in/yaml.v3"
	"xbrain.local/daily/internal/testutil"
)

// loadExample doc file config vi du va chuyen sang dang PULUMI_CONFIG (list -> JSON string)
func loadExample(t *testing.T, path string) map[string]string {
	t.Helper()
	data, err := os.ReadFile(path)
	if err != nil {
		t.Fatal(err)
	}
	var doc struct {
		Config map[string]interface{} `yaml:"config"`
	}
	if err := yaml.Unmarshal(data, &doc); err != nil {
		t.Fatal(err)
	}
	cfg := map[string]string{}
	for key, value := range doc.Config {
		switch v := value.(type) {
		case string:
			cfg[key] = v
		case []interface{}:
			encoded, err := json.Marshal(v)
			if err != nil {
				t.Fatal(err)
			}
			cfg[key] = string(encoded)
		default:
			cfg[key] = fmt.Sprint(v)
		}
	}
	return cfg
}

func withConfig(cfg map[string]string) pulumi.RunOption {
	return func(info *pulumi.RunInfo) { info.Config = cfg }
}

// runRoot chay composition root that (run) voi config va mocks, khong can engine hay cloud
func runRoot(stack string, cfg map[string]string) (*testutil.Mocks, error) {
	mocks := &testutil.Mocks{}
	err := pulumi.RunErr(run, pulumi.WithMocks("daily-workspace", stack, mocks), withConfig(cfg))
	return mocks, err
}

type target struct {
	file, name, prefix string
	desiredCount       float64
	vpc                string
	subnets            []string
}

var targets = []target{
	{file: "Pulumi.nonprod.example.yaml", name: "nonprod", prefix: "xbrain-nonprod-uploads-", desiredCount: 1,
		vpc: "fixture-vpc", subnets: []string{"fixture-subnet-a"}},
	{file: "Pulumi.uat.example.yaml", name: "uat", prefix: "xbrain-uat-uploads-", desiredCount: 2,
		vpc: "fixture-vpc-uat", subnets: []string{"fixture-subnet-uat-a", "fixture-subnet-uat-b"}},
}

func stringValues(values []resource.PropertyValue) []string {
	out := make([]string, 0, len(values))
	for _, v := range values {
		out = append(out, v.StringValue())
	}
	return out
}

func TestRootTargets(t *testing.T) {
	for _, tc := range targets {
		t.Run(tc.name, func(t *testing.T) {
			mocks, err := runRoot(tc.name, loadExample(t, tc.file))
			if err != nil {
				t.Fatal(err)
			}
			// identity mong doi duoi workspace cua target; khong co resource ngoai danh sach nay
			want := map[string]string{
				tc.name:                             "xbrain:workspace:Workspace",
				tc.name + "-aws":                    "pulumi:providers:aws",
				tc.name + "-storage":                "xbrain:storage:Storage",
				tc.name + "-storage-uploads":        "aws:s3/bucket:Bucket",
				tc.name + "-storage-uploads-access": "aws:s3/bucketPublicAccessBlock:BucketPublicAccessBlock",
				tc.name + "-workload":               "xbrain:workload:Workload",
				tc.name + "-workload-logs":          "aws:cloudwatch/logGroup:LogGroup",
				tc.name + "-workload-execution":     "aws:iam/role:Role",
				tc.name + "-workload-logs-policy":   "aws:iam/rolePolicy:RolePolicy",
				tc.name + "-workload-service-sg":    "aws:ec2/securityGroup:SecurityGroup",
				tc.name + "-workload-cluster":       "aws:ecs/cluster:Cluster",
				tc.name + "-workload-task":          "aws:ecs/taskDefinition:TaskDefinition",
				tc.name + "-workload-service":       "aws:ecs/service:Service",
			}
			parents := map[string]string{
				tc.name + "-storage": tc.name, tc.name + "-workload": tc.name,
				tc.name + "-storage-uploads": tc.name + "-storage", tc.name + "-workload-service": tc.name + "-workload",
			}
			seen := map[string]bool{}
			for _, item := range mocks.Resources() {
				token, ok := want[item.Name]
				if !ok || token != item.TypeToken {
					t.Fatalf("unexpected resource %s (%s)", item.Name, item.TypeToken)
				}
				seen[item.Name] = true
				if parent, ok := parents[item.Name]; ok && !strings.HasSuffix(item.RegisterRPC.GetParent(), "::"+parent) {
					t.Fatalf("%s parent = %s, want %s", item.Name, item.RegisterRPC.GetParent(), parent)
				}
				if strings.HasPrefix(item.TypeToken, "aws:") && !strings.Contains(item.Provider, "::"+tc.name+"-aws::") {
					t.Fatalf("%s provider = %s, want inherited %s-aws", item.Name, item.Provider, tc.name)
				}
				if tags, ok := item.Inputs["tags"]; ok {
					values := tags.ObjectValue()
					if values["Team"].StringValue() != "xbrain" || values["Environment"].StringValue() != tc.name {
						t.Fatalf("%s tags = %v", item.Name, values)
					}
				}
				switch item.TypeToken {
				case "pulumi:providers:aws":
					if item.Inputs["region"].StringValue() != "ap-southeast-1" {
						t.Fatal("provider region changed")
					}
				case "aws:s3/bucket:Bucket":
					if item.Inputs["bucketPrefix"].StringValue() != tc.prefix || item.Inputs.HasValue("bucket") {
						t.Fatal("bucket must auto-name from target prefix")
					}
				case "aws:s3/bucketPublicAccessBlock:BucketPublicAccessBlock":
					for _, key := range []resource.PropertyKey{"blockPublicAcls", "blockPublicPolicy", "ignorePublicAcls", "restrictPublicBuckets"} {
						if !item.Inputs[key].BoolValue() {
							t.Fatalf("public access block %s disabled", key)
						}
					}
				case "aws:cloudwatch/logGroup:LogGroup":
					if item.Inputs["retentionInDays"].NumberValue() != 7 {
						t.Fatal("log retention must stay 7 days")
					}
				case "aws:ec2/securityGroup:SecurityGroup":
					if item.Inputs["vpcId"].StringValue() != tc.vpc {
						t.Fatalf("security group vpc = %v", item.Inputs["vpcId"])
					}
					ingress := item.Inputs["ingress"].ArrayValue()
					rule := ingress[0].ObjectValue()
					if len(ingress) != 1 || rule["protocol"].StringValue() != "tcp" || rule["fromPort"].NumberValue() != 8080 ||
						rule["toPort"].NumberValue() != 8080 || stringValues(rule["cidrBlocks"].ArrayValue())[0] != "10.30.0.0/16" {
						t.Fatalf("ingress changed: %v", ingress)
					}
					// egress giu mo hinh lab: all protocols toi 0.0.0.0/0
					egress := item.Inputs["egress"].ArrayValue()
					out := egress[0].ObjectValue()
					if len(egress) != 1 || out["protocol"].StringValue() != "-1" || out["fromPort"].NumberValue() != 0 ||
						out["toPort"].NumberValue() != 0 || stringValues(out["cidrBlocks"].ArrayValue())[0] != "0.0.0.0/0" {
						t.Fatalf("egress changed: %v", egress)
					}
				case "aws:ecs/taskDefinition:TaskDefinition":
					if item.Inputs["cpu"].StringValue() != "256" || item.Inputs["memory"].StringValue() != "512" {
						t.Fatal("fargate size changed")
					}
					var containers []map[string]interface{}
					if err := json.Unmarshal([]byte(item.Inputs["containerDefinitions"].StringValue()), &containers); err != nil {
						t.Fatal(err)
					}
					if containers[0]["image"] != "fixture.invalid/api@sha256:"+strings.Repeat("a", 64) {
						t.Fatalf("image = %v", containers[0]["image"])
					}
				case "aws:ecs/service:Service":
					if item.Inputs["desiredCount"].NumberValue() != tc.desiredCount {
						t.Fatalf("desiredCount = %v", item.Inputs["desiredCount"])
					}
					network := item.Inputs["networkConfiguration"].ObjectValue()
					if got := stringValues(network["subnets"].ArrayValue()); strings.Join(got, ",") != strings.Join(tc.subnets, ",") {
						t.Fatalf("subnets = %v, want %v", got, tc.subnets)
					}
					if !network["assignPublicIp"].BoolValue() {
						t.Fatal("public-ip mode changed")
					}
				}
			}
			if len(seen) != len(want) {
				t.Fatalf("registered %d of %d expected resources", len(seen), len(want))
			}
		})
	}
}

func TestRootSubnetConfig(t *testing.T) {
	base := loadExample(t, "Pulumi.uat.example.yaml")
	cases := map[string]func(map[string]string){
		"both keys":  func(c map[string]string) { c["workspace:subnetId"] = "fixture-subnet-a" },
		"none":       func(c map[string]string) { delete(c, "workspace:subnetIds") },
		"not a list": func(c map[string]string) { c["workspace:subnetIds"] = "fixture-subnet-uat-a" },
		"empty list": func(c map[string]string) { c["workspace:subnetIds"] = "[]" },
		"empty id":   func(c map[string]string) { c["workspace:subnetIds"] = `["fixture-subnet-uat-a",""]` },
	}
	for name, mutate := range cases {
		t.Run(name, func(t *testing.T) {
			cfg := map[string]string{}
			for k, v := range base {
				cfg[k] = v
			}
			mutate(cfg)
			mocks, err := runRoot("uat", cfg)
			if err == nil {
				t.Fatal("expected subnet config error")
			}
			if len(mocks.Resources()) != 0 {
				t.Fatal("invalid config must fail before registering resources")
			}
		})
	}
}
