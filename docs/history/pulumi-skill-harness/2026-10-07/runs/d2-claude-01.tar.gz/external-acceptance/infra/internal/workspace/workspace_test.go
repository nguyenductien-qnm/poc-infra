package workspace

import (
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
	"strings"
	"testing"
	"xbrain.local/daily/internal/testutil"
)

func NonProdArgs() *Args {
	return &Args{Environment: "nonprod", Region: "ap-southeast-1", StoragePrefix: "xbrain-nonprod-uploads-", DesiredCount: 1,
		Image: pulumi.String("fixture.invalid/api@sha256:" + strings.Repeat("a", 64)),
		VpcID: pulumi.String("fixture-vpc"), SubnetIDs: pulumi.StringArray{pulumi.String("fixture-subnet-a")}, PeerCIDR: "10.30.0.0/16"}
}

// UAT theo contract D2: cung image/region, mang ngoai rieng voi hai subnets
func UATArgs() *Args {
	args := NonProdArgs()
	args.Environment, args.StoragePrefix, args.DesiredCount = "uat", "xbrain-uat-uploads-", 2
	args.VpcID = pulumi.String("fixture-vpc-uat")
	args.SubnetIDs = pulumi.ToStringArray([]string{"fixture-subnet-uat-a", "fixture-subnet-uat-b"})
	return args
}

type expected struct {
	name, prefix, environment string
	desiredCount              float64
	subnets                   []string
}

// chay workspace tren mocks va kiem tra identity, prefix, capacity, tags va network contract
func runWorkspace(t *testing.T, args *Args, want expected) {
	t.Helper()
	mocks := &testutil.Mocks{}
	err := pulumi.RunErr(func(ctx *pulumi.Context) error {
		result, err := New(ctx, want.name, args)
		if err != nil {
			return err
		}
		ctx.Export("bucketName", result.BucketName)
		ctx.Export("serviceName", result.ServiceName)
		return nil
	}, pulumi.WithMocks("daily-workspace", want.name, mocks))
	if err != nil {
		t.Fatal(err)
	}
	components := map[string]string{
		"xbrain:workspace:Workspace": want.name,
		"xbrain:storage:Storage":     want.name + "-storage",
		"xbrain:workload:Workload":   want.name + "-workload",
		"pulumi:providers:aws":       want.name + "-aws",
	}
	seen := map[string]bool{}
	for _, item := range mocks.Resources() {
		if name, ok := components[item.TypeToken]; ok {
			seen[item.TypeToken] = true
			if item.Name != name {
				t.Fatalf("%s logical name = %q, want %q", item.TypeToken, item.Name, name)
			}
			continue
		}
		if tags, ok := item.Inputs["tags"]; ok && tags.IsObject() {
			values := tags.ObjectValue()
			if values["Environment"].StringValue() != want.environment || values["Team"].StringValue() != "xbrain" {
				t.Fatalf("%s tags = %v", item.Name, values)
			}
		}
		switch item.TypeToken {
		case "aws:s3/bucket:Bucket":
			seen[item.TypeToken] = true
			if item.Name != want.name+"-storage-uploads" || item.Inputs["bucketPrefix"].StringValue() != want.prefix {
				t.Fatalf("bucket contract changed: %s %v", item.Name, item.Inputs["bucketPrefix"])
			}
			if !strings.HasSuffix(item.RegisterRPC.GetParent(), "::"+want.name+"-storage") || item.Provider == "" {
				t.Fatal("bucket must have storage parent and inherited provider")
			}
		case "aws:ecs/service:Service":
			seen[item.TypeToken] = true
			if item.Name != want.name+"-workload-service" || item.Inputs["desiredCount"].NumberValue() != want.desiredCount {
				t.Fatalf("service contract changed: %s %v", item.Name, item.Inputs["desiredCount"])
			}
			network := item.Inputs["networkConfiguration"].ObjectValue()
			subnets := network["subnets"].ArrayValue()
			if len(subnets) != len(want.subnets) {
				t.Fatalf("subnets = %v, want %v", subnets, want.subnets)
			}
			for i, id := range want.subnets {
				if subnets[i].StringValue() != id {
					t.Fatalf("external subnet %d = %v, want %s", i, subnets[i], id)
				}
			}
		case "aws:cloudwatch/logGroup:LogGroup":
			if item.Inputs["retentionInDays"].NumberValue() != 7 {
				t.Fatal("log retention changed")
			}
		case "aws:ec2/vpc:Vpc", "aws:ec2/subnet:Subnet":
			t.Fatal("workspace must not own external network")
		}
	}
	for _, token := range []string{"xbrain:workspace:Workspace", "xbrain:storage:Storage", "xbrain:workload:Workload",
		"pulumi:providers:aws", "aws:s3/bucket:Bucket", "aws:ecs/service:Service"} {
		if !seen[token] {
			t.Fatalf("missing %s", token)
		}
	}
}

func TestExistingNonProd(t *testing.T) {
	runWorkspace(t, NonProdArgs(), expected{name: "nonprod", prefix: "xbrain-nonprod-uploads-", environment: "nonprod", desiredCount: 1,
		subnets: []string{"fixture-subnet-a"}})
}

func TestUAT(t *testing.T) {
	runWorkspace(t, UATArgs(), expected{name: "uat", prefix: "xbrain-uat-uploads-", environment: "uat", desiredCount: 2,
		subnets: []string{"fixture-subnet-uat-a", "fixture-subnet-uat-b"}})
}

func TestRejectsIncompleteArgs(t *testing.T) {
	missingPrefix := UATArgs()
	missingPrefix.StoragePrefix = ""
	err := pulumi.RunErr(func(ctx *pulumi.Context) error {
		_, err := New(ctx, "uat", missingPrefix)
		return err
	}, pulumi.WithMocks("daily-workspace", "uat", &testutil.Mocks{}))
	if err == nil {
		t.Fatal("expected error for missing storage prefix")
	}
}
