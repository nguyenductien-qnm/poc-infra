# Quyết định của lab

- Track offline/code. Chưa có AWS state hay resource; IDs và image chỉ là fixture.
- Một project Go `daily-workspace`; consumers là NonProd (hiện có) và UAT (D2,
  onboard ở mức source/config example, chưa có stack). Cấu hình môi trường được
  đọc ở composition root và dùng chung các capability cụ thể.
- Subnets: `workspace:subnetIds` (list) cho UAT/target mới; `workspace:subnetId`
  (single) là key legacy của NonProd, vẫn được hỗ trợ. Hai key loại trừ nhau.
- Workspace sở hữu bucket, SG, logs, execution role, ECS cluster/task/service.
  VPC và subnets thuộc network team, chỉ consume qua contract. Không import hay
  register lại chúng. Provider thuộc workspace.New, được đăng ký ở stack root với tên <workspace>-aws; children kế thừa provider qua parent. Composition root cmd/workspace đọc config. Giữ cách sở hữu provider này trong ticket cấu hình.
- Identity hiện tại: type token `xbrain:workspace:Workspace`, logical name
  `nonprod`, child components `nonprod-storage` / `nonprod-workload` và các
  resource suffix trong source. Refactor giữ chúng hoặc nêu migration/aliases.
  UAT dùng cùng type token và suffix dưới logical name `uat`, provider `uat-aws`.
- NonProd cho phép protection=false; không thêm production guardrails unasked.
- Delivery mode: kiểm tra PR, preview thủ công và deploy manual-dispatch có
  approval. Chưa cấp backend/CI identity; không dispatch hoặc đổi delivery mode.
- StoragePrefix hiện tại `xbrain-nonprod-uploads-`; dùng BucketPrefix auto-name,
  không lấy physical name cố định. Consumer mới có prefix riêng theo contract.
  Prefix đi từ config `storagePrefix` qua `workspace.Args` vào `storage.Args.Prefix`;
  logical name của workspace lấy từ config `environment`.
- Args/Outputs có consumer thật; không thêm registry, plugin engine hoặc flags
  chưa dùng. Không nâng major SDK. Mocks không phải observed Pulumi preview.
