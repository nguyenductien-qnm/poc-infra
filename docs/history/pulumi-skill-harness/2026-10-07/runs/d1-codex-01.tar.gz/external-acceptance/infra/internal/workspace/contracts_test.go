package workspace

import (
	"encoding/json"
	"reflect"
	"slices"
	"strings"
	"testing"

	"github.com/pulumi/pulumi/sdk/v3/go/common/resource"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
	"xbrain.local/daily/internal/testutil"
)

func TestWorkspaceContracts(t *testing.T) {
	for _, fixture := range []struct {
		environment string
		prefix      string
		count       int
	}{
		{"nonprod", "xbrain-nonprod-uploads-", 1},
		{"uat", "xbrain-uat-uploads-", 2},
	} {
		t.Run(fixture.environment, func(t *testing.T) {
			name := fixture.environment
			args := NonProdArgs()
			args.Environment, args.StoragePrefix, args.DesiredCount = fixture.environment, fixture.prefix, fixture.count
			mocks := &testutil.Mocks{}
			err := pulumi.RunErr(func(ctx *pulumi.Context) error {
				result, err := New(ctx, name, args)
				if err != nil {
					return err
				}
				ctx.Export("bucketName", result.BucketName.ApplyT(func(value string) string {
					if value != name+"-storage-uploads-mock" {
						t.Error("bucket output does not come from storage")
					}
					return value
				}))
				ctx.Export("serviceName", result.ServiceName.ApplyT(func(value string) string {
					if value != name+"-workload-service" {
						t.Error("service output does not come from workload")
					}
					return value
				}))
				return nil
			}, pulumi.WithMocks("daily-workspace", name, mocks))
			if err != nil {
				t.Fatal(err)
			}

			resources := assertResourceIdentity(t, name, mocks.Resources())
			assertInput := func(suffix, key string, want interface{}) {
				t.Helper()
				if got := resources[name+suffix].Inputs[resource.PropertyKey(key)].Mappable(); !reflect.DeepEqual(got, want) {
					t.Errorf("%s input %s does not match contract", suffix, key)
				}
			}
			assertInput("-aws", "region", args.Region)
			assertInput("-storage-uploads", "bucketPrefix", fixture.prefix)
			if _, fixed := resources[name+"-storage-uploads"].Inputs["bucket"]; fixed {
				t.Error("bucket must use a prefix with auto-naming")
			}
			assertInput("-storage-uploads-access", "bucket", name+"-storage-uploads-mock-id")
			for _, key := range []string{"blockPublicAcls", "blockPublicPolicy", "ignorePublicAcls", "restrictPublicBuckets"} {
				assertInput("-storage-uploads-access", key, true)
			}
			for _, suffix := range []string{"-storage-uploads", "-workload-logs", "-workload-execution", "-workload-service-sg", "-workload-cluster", "-workload-task", "-workload-service"} {
				assertInput(suffix, "tags", map[string]interface{}{"Team": "xbrain", "Environment": fixture.environment})
			}
			assertInput("-workload-logs", "retentionInDays", float64(7))
			assertInput("-workload-service-sg", "vpcId", "fixture-vpc")
			assertInput("-workload-service-sg", "ingress", []interface{}{map[string]interface{}{
				"protocol": "tcp", "fromPort": float64(8080), "toPort": float64(8080), "cidrBlocks": []interface{}{args.PeerCIDR},
			}})
			assertInput("-workload-service-sg", "egress", []interface{}{map[string]interface{}{
				"protocol": "-1", "fromPort": float64(0), "toPort": float64(0), "cidrBlocks": []interface{}{"0.0.0.0/0"},
			}})
			assertInput("-workload-task", "family", name+"-workload")
			assertInput("-workload-task", "cpu", "256")
			assertInput("-workload-task", "memory", "512")
			assertInput("-workload-task", "networkMode", "awsvpc")
			assertInput("-workload-task", "requiresCompatibilities", []interface{}{"FARGATE"})
			assertInput("-workload-task", "executionRoleArn", "fixture-reference-"+name+"-workload-execution")
			assertInput("-workload-service", "cluster", "fixture-reference-"+name+"-workload-cluster")
			assertInput("-workload-service", "taskDefinition", "fixture-reference-"+name+"-workload-task")
			assertInput("-workload-service", "desiredCount", float64(fixture.count))
			assertInput("-workload-service", "launchType", "FARGATE")
			assertInput("-workload-service", "networkConfiguration", map[string]interface{}{
				"subnets": []interface{}{"fixture-subnet-a"}, "securityGroups": []interface{}{name + "-workload-service-sg-mock-id"}, "assignPublicIp": true,
			})

			var definitions []map[string]interface{}
			if err := json.Unmarshal([]byte(resources[name+"-workload-task"].Inputs["containerDefinitions"].StringValue()), &definitions); err != nil {
				t.Fatal(err)
			}
			wantDefinitions := []map[string]interface{}{{
				"name": "api", "image": "fixture.invalid/api@sha256:" + strings.Repeat("a", 64), "essential": true,
				"portMappings": []interface{}{map[string]interface{}{"containerPort": float64(8080), "protocol": "tcp"}},
				"healthCheck": map[string]interface{}{
					"command":  []interface{}{"CMD-SHELL", "curl -f http://localhost:8080/health || exit 1"},
					"interval": float64(30), "timeout": float64(5), "retries": float64(3),
				},
				"logConfiguration": map[string]interface{}{"logDriver": "awslogs", "options": map[string]interface{}{
					"awslogs-group": name + "-workload-logs", "awslogs-region": args.Region, "awslogs-stream-prefix": "api",
				}},
			}}
			if !reflect.DeepEqual(definitions, wantDefinitions) {
				t.Error("container definition does not match the supplied workload contract")
			}
			assertInput("-workload-logs-policy", "role", name+"-workload-execution-mock-id")
			var policy map[string]interface{}
			if err := json.Unmarshal([]byte(resources[name+"-workload-logs-policy"].Inputs["policy"].StringValue()), &policy); err != nil {
				t.Fatal(err)
			}
			if !reflect.DeepEqual(policy, map[string]interface{}{
				"Version": "2012-10-17", "Statement": []interface{}{map[string]interface{}{
					"Effect": "Allow", "Action": []interface{}{"logs:CreateLogStream", "logs:PutLogEvents"},
					"Resource": "fixture-reference-" + name + "-workload-logs:*",
				}},
			}) {
				t.Error("execution log policy must consume the log group output")
			}
			policyDependency := "urn:pulumi:" + name + "::daily-workspace::xbrain:workspace:Workspace$xbrain:workload:Workload$aws:iam/rolePolicy:RolePolicy::" + name + "-workload-logs-policy"
			if !slices.Contains(resources[name+"-workload-service"].RegisterRPC.GetDependencies(), policyDependency) {
				t.Error("service must wait for its execution log policy")
			}
		})
	}
}

func assertResourceIdentity(t *testing.T, name string, items []pulumi.MockResourceArgs) map[string]pulumi.MockResourceArgs {
	t.Helper()
	base := "urn:pulumi:" + name + "::daily-workspace::"
	root := base + "pulumi:pulumi:Stack::daily-workspace-" + name
	workspace := base + "xbrain:workspace:Workspace::" + name
	storage := base + "xbrain:workspace:Workspace$xbrain:storage:Storage::" + name + "-storage"
	workload := base + "xbrain:workspace:Workspace$xbrain:workload:Workload::" + name + "-workload"
	want := map[string]struct{ token, parent string }{
		name + "-aws":                    {"pulumi:providers:aws", root},
		name:                             {"xbrain:workspace:Workspace", root},
		name + "-storage":                {"xbrain:storage:Storage", workspace},
		name + "-storage-uploads":        {"aws:s3/bucket:Bucket", storage},
		name + "-storage-uploads-access": {"aws:s3/bucketPublicAccessBlock:BucketPublicAccessBlock", storage},
		name + "-workload":               {"xbrain:workload:Workload", workspace},
		name + "-workload-logs":          {"aws:cloudwatch/logGroup:LogGroup", workload},
		name + "-workload-execution":     {"aws:iam/role:Role", workload},
		name + "-workload-logs-policy":   {"aws:iam/rolePolicy:RolePolicy", workload},
		name + "-workload-service-sg":    {"aws:ec2/securityGroup:SecurityGroup", workload},
		name + "-workload-cluster":       {"aws:ecs/cluster:Cluster", workload},
		name + "-workload-task":          {"aws:ecs/taskDefinition:TaskDefinition", workload},
		name + "-workload-service":       {"aws:ecs/service:Service", workload},
	}
	provider := base + "pulumi:providers:aws::" + name + "-aws::" + name + "-aws-mock-id"
	seen := make(map[string]pulumi.MockResourceArgs)
	for _, item := range items {
		if item.TypeToken == "pulumi:pulumi:Stack" {
			continue
		}
		expected, ok := want[item.Name]
		if !ok {
			t.Fatalf("unexpected resource %s (%s); no external network may be registered", item.Name, item.TypeToken)
		}
		if _, duplicate := seen[item.Name]; duplicate {
			t.Fatalf("duplicate resource %s", item.Name)
		}
		seen[item.Name] = item
		if item.TypeToken != expected.token || item.RegisterRPC.GetParent() != expected.parent {
			t.Errorf("resource %s changed type or parent", item.Name)
		}
		if strings.HasPrefix(item.TypeToken, "aws:") && item.Provider != provider {
			t.Errorf("resource %s must inherit the workspace provider", item.Name)
		}
	}
	if len(seen) != len(want) {
		t.Fatalf("expected %d resources, got %d", len(want), len(seen))
	}
	return seen
}
