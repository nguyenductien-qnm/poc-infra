package storage

import "testing"

func TestRequiresBucketPrefix(t *testing.T) {
	for _, args := range []*Args{nil, {}} {
		if _, err := New(nil, "fixture-storage", args); err == nil {
			t.Fatal("missing prefix must fail before registering resources")
		}
	}
}
