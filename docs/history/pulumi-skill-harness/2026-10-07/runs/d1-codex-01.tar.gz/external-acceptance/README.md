# xbrain daily infrastructure lab

Repo kế thừa cho ticket bảo trì Pulumi Go. Đây là fixture offline, chưa deploy.
`infra/cmd/workspace` đọc config; `infra/internal/workspace` ghép component;
storage và workload có owner riêng trong workspace, network được consume.

Đọc docs/DECISIONS.md và docs/CONTRACTS.md. Kiểm tra từ infra:
`gofmt -l .`, `go mod tidy -diff`, `go vet ./...`, `go build ./...`, `go test ./...`.
Mocks không chứng minh preview, cloud connectivity hoặc migration thành công.
App là module scope-control riêng, không phải image runtime và không build nó.

## Dùng lại component Workspace

`workspace.New(ctx, name, args, opts...)` nhận cấu hình cụ thể; component không
đọc config hay tự chọn môi trường. Composition root hiện tại
`infra/cmd/workspace/main.go` đọc namespace `workspace`, giữ logical name
`nonprod` và export `bucketName`, `serviceName`. Tên consumer hiện tại là identity
cần giữ, không đổi theo một config mới trên stack hiện có.

| Config ở root | `workspace.Args` | Cách sử dụng |
| --- | --- | --- |
| `environment` | `Environment` | Tag `Environment`; tag `Team=xbrain` được giữ |
| `region` | `Region` | Provider AWS ở stack root và cấu hình log của task |
| `storagePrefix` | `StoragePrefix` | Truyền xuống `storage.Args.BucketPrefix`, dùng S3 BucketPrefix auto-name |
| `desiredCount` | `DesiredCount` | Số task ECS, phải lớn hơn 0 |
| `image` | `Image` | Image contract của app, nhận `pulumi.StringInput` |
| `vpcId` | `VpcID` | VPC ngoài workspace, nhận `pulumi.StringInput` |
| `subnetId` | `SubnetIDs` | Root hiện tại truyền một subnet; component nhận `pulumi.StringArrayInput` |
| `peerCidr` | `PeerCIDR` | CIDR ingress nội bộ đến TCP 8080 |

Consumer mới gọi constructor với logical name riêng và các Args được đọc tại
composition root của consumer đó. Ví dụ UAT dưới đây chỉ minh họa contract
offline; ticket này chưa onboard stack UAT:

```go
result, err := workspace.New(ctx, "uat", &workspace.Args{
    Environment:   "uat",
    Region:        "ap-southeast-1",
    StoragePrefix: "xbrain-uat-uploads-",
    DesiredCount:  2,
    Image:         image,
    VpcID:         vpcID,
    SubnetIDs:     subnetIDs,
    PeerCIDR:      "10.30.0.0/16",
})
if err != nil {
    return err
}
ctx.Export("bucketName", result.BucketName)
ctx.Export("serviceName", result.ServiceName)
```

`image`, `vpcID`, `subnetIDs` là Input/Output do composition root cấp theo
[CONTRACTS](docs/CONTRACTS.md); truyền trực tiếp để giữ dependency và secret
semantics. Nếu dùng storage độc lập, truyền `storage.Args{BucketPrefix: prefix,
Tags: tags}` cùng parent/provider phù hợp; prefix rỗng bị từ chối trước khi
đăng ký resource. Không dùng tên bucket vật lý cố định.

Workspace sở hữu provider `<name>-aws` ở stack root và các resource storage,
workload; children kế thừa provider qua parent. VPC/subnet chỉ được consume,
không tạo, import hay đăng ký lại. Giữ type token, logical name, parent và suffix
hiện tại của NonProd; không cần alias/migration cho thay đổi này. Với cấu hình
NonProd đã cấp, source không dự kiến replacement hoặc deletion. Prefix mới cho
bucket đang có có thể gây replacement, nên không dùng refactor này để đổi prefix
của consumer hiện tại.

## Kiểm chứng offline

`TestWorkspaceContracts` chạy hai cấu hình NonProd/UAT trong CONTRACTS: prefix
riêng, capacity 1/2 và tags tương ứng. Mocks kiểm tra đủ resource identity,
parent/provider, network ngoài workspace, public access block, log retention,
task/service wiring, health check, policy log từ Output và outputs cho consumer.
`TestRequiresBucketPrefix` kiểm tra input storage thiếu prefix.

Chạy các local checks ở đầu README từ module `infra`, với `GOPROXY=off`,
`GOSUMDB=off`, `GOTOOLCHAIN=local` để không tải dependency/toolchain. Máy cần sẵn
dependency cache cho phiên bản đã pin và Go tương thích; nếu build cache mặc định
không ghi được, đặt `GOCACHE` đến thư mục tạm có quyền ghi. Mocks chỉ chứng minh
resource registration và wiring trong Go; không phải observed preview hay bằng
chứng AWS chấp nhận, kết nối live hoặc migration thành công. Image live,
topology và backend/CI identity vẫn chưa được cấp; không triển khai trong track này.
