# Rà soát archive

## Kết luận

`pass` trong phạm vi đã kiểm (source, test WithMocks, kiểm tra Go cục bộ), sau khi sửa hai nhận định không có căn cứ. Trong bốn nhận định ban đầu, hai nhận định đúng (NewEarly, TestCompleteFrozenParents) và hai nhận định sai (NewLate, TestSelectedParents). Tự rà soát, không dùng reviewer phụ vì đây chỉ là thay đổi tài liệu.

## Kiểm tra đã chạy

Các lệnh chạy lại cục bộ trong `infra/` ngày 2026-10-06 (UTC), với `GOPROXY=off`, `GOSUMDB=off`, `AWS_EC2_METADATA_DISABLED=true` và Go 1.27.1. Mọi lệnh đều trả về exit 0.

- `gofmt -l .`: không có đầu ra.
- `go mod tidy -diff`: không có diff.
- `go vet ./...`, `go build ./...`: không có lỗi.
- `go test -count=1 -v ./...`: PASS cả 4 test, request đăng ký trùng khớp với `docs/baseline-checks.json`.

SHA-256 hiện tại của `infra/archive/archive.go`, `infra/archive/archive_test.go`, `infra/go.mod` và `infra/go.sum` trùng với `provenance.source_sha256` trong baseline. Vì vậy baseline và lần chạy lại cùng áp dụng cho đúng source này.

## Tham số không hợp lệ

- Luồng `NewLate` (đã sửa): `KeepDays=0` bị từ chối, nhưng chỉ sau khi đã đăng ký 4 tài nguyên ứng dụng là provider `ledger-region`, component `ledger`, bucket `ledger-blobs` và `ledger-access`. `NewLate` gọi `prepare` trước (`archive.go:30`, `archive.go:50-71`), còn `validate` chỉ chạy trong `newAudit` (`archive.go:34`, `archive.go:74`). `TestLateRejectedInput` khẳng định có lỗi và khẳng định đúng 4 type này đã được đăng ký (`archive_test.go:61-74`, kỳ vọng ở dòng 66). Test chỉ so sánh type sau khi sắp xếp, không so sánh name hay parent. Theo `docs/DECISIONS.md`, thứ tự đăng ký này được giữ nguyên.
- Luồng `NewEarly` (đúng): `KeepDays=0` bị từ chối trước mọi đăng ký tài nguyên do ứng dụng khai báo, không tính Stack ngầm của SDK. `validate` chạy trước `NewLate` (`archive.go:43-47`). `TestEarlyRejectedInput` khẳng định có lỗi và `len(records) == 0` (`archive_test.go:76-84`). Recorder loại `pulumi:pulumi:Stack` khỏi danh mục (`archive_test.go:31`).

## Quan hệ parent

- `TestSelectedParents` (đã sửa): test chỉ kiểm tra tổng số là 5 đăng ký (`archive_test.go:94`) và chỉ kiểm tra parent của 2 tài nguyên là Bucket và LogGroup, phải là component `ledger` (`archive_test.go:97-108`). Test không kiểm tra parent của `BucketPublicAccessBlock`, provider hay component gốc.
- `TestCompleteFrozenParents` (đúng): test so sánh `reflect.DeepEqual` toàn bộ danh mục 5 tài nguyên ứng dụng, gồm type, name và parent, với danh mục đóng băng (`archive_test.go:111-126`). Danh mục đó gồm cả provider và component gốc, cả hai có parent là Stack, còn ba tài nguyên con có parent là component (`archive_test.go:86-87`, `archive_test.go:117-123`). Danh mục được sắp xếp theo type/name (`archive_test.go:42`), nên test không xác nhận thứ tự đăng ký.

## Phạm vi và điều chưa biết

- Bằng chứng chỉ gồm source, test WithMocks và các kiểm tra Go cục bộ. Không có preview, deploy, state/backend hay tài nguyên AWS nào được tạo hoặc đọc. Kết quả mock thành công không chứng minh kế hoạch không thay đổi (no-change plan) cũng như không chứng minh hành vi trên cloud.
- Các test chỉ chạy `KeepDays` với 0 và 7. Luồng thành công chỉ được chạy qua `NewEarly`. Việc luồng thành công của `NewLate` có cùng danh mục là suy luận từ source (`archive.go:47`), không có test trực tiếp.
- Test không khẳng định `pulumi.Provider(provider)` trên tài nguyên con, giá trị `RetentionInDays`, các cờ `BlockPublic*`/`IgnorePublicAcls`/`RestrictPublicBuckets` hay region `ap-southeast-1` (`archive.go:51`, `archive.go:63-66`, `archive.go:77`).
- Rủi ro dự đoán từ source, chưa quan sát được: với `NewLate` và `KeepDays` không hợp lệ, một lần `pulumi up` thật có thể đã gửi 4 đăng ký trước khi chương trình trả về lỗi. Hệ quả thực tế lên state/cloud chưa được kiểm chứng.
