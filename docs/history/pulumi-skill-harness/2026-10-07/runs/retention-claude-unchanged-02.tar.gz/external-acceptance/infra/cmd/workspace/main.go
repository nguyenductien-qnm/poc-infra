package main

import (
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi/config"
	"xbrain.local/daily/internal/workspace"
)

func main() {
	pulumi.Run(func(ctx *pulumi.Context) error {
		cfg := config.New(ctx, "workspace")
		result, err := workspace.New(ctx, "nonprod", &workspace.Args{
			Environment:      cfg.Require("environment"),
			Region:           cfg.Require("region"),
			StoragePrefix:    cfg.Require("storagePrefix"),
			DesiredCount:     cfg.RequireInt("desiredCount"),
			LogRetentionDays: cfg.GetInt("logRetentionDays"),
			Image:            pulumi.String(cfg.Require("image")),
			VpcID:            pulumi.String(cfg.Require("vpcId")),
			SubnetIDs:        pulumi.StringArray{pulumi.String(cfg.Require("subnetId"))},
			PeerCIDR:         cfg.Require("peerCidr"),
		})
		if err != nil {
			return err
		}
		ctx.Export("bucketName", result.BucketName)
		ctx.Export("serviceName", result.ServiceName)
		return nil
	})
}
