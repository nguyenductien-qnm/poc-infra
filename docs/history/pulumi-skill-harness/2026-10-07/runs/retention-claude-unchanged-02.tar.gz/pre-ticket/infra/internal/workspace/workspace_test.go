package workspace

import (
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
	"strings"
	"testing"
	"xbrain.local/daily/internal/testutil"
)

func NonProdArgs() *Args {
	return &Args{Environment: "nonprod", Region: "ap-southeast-1", StoragePrefix: "xbrain-nonprod-uploads-", DesiredCount: 1,
		Image: pulumi.String("fixture.invalid/api@sha256:" + strings.Repeat("a", 64)),
		VpcID: pulumi.String("fixture-vpc"), SubnetIDs: pulumi.StringArray{pulumi.String("fixture-subnet-a")}, PeerCIDR: "10.30.0.0/16"}
}

func TestExistingNonProd(t *testing.T) {
	mocks := &testutil.Mocks{}
	err := pulumi.RunErr(func(ctx *pulumi.Context) error {
		result, err := New(ctx, "nonprod", NonProdArgs())
		if err != nil {
			return err
		}
		ctx.Export("bucketName", result.BucketName)
		ctx.Export("serviceName", result.ServiceName)
		return nil
	}, pulumi.WithMocks("daily-workspace", "nonprod", mocks))
	if err != nil {
		t.Fatal(err)
	}
	seenBucket, seenService := false, false
	for _, item := range mocks.Resources() {
		switch item.TypeToken {
		case "aws:s3/bucket:Bucket":
			seenBucket = true
			if item.Name != "nonprod-storage-uploads" || item.Inputs["bucketPrefix"].StringValue() != "xbrain-nonprod-uploads-" {
				t.Fatal("existing bucket contract changed")
			}
			if item.RegisterRPC.GetParent() == "" || item.Provider == "" {
				t.Fatal("bucket must have parent/provider")
			}
		case "aws:ecs/service:Service":
			seenService = true
			if item.Inputs["desiredCount"].NumberValue() != 1 {
				t.Fatal("existing capacity changed")
			}
			network := item.Inputs["networkConfiguration"].ObjectValue()
			if network["subnets"].ArrayValue()[0].StringValue() != "fixture-subnet-a" {
				t.Fatal("external subnet not consumed")
			}
		case "aws:ec2/vpc:Vpc", "aws:ec2/subnet:Subnet":
			t.Fatal("workspace must not own external network")
		}
	}
	if !seenBucket || !seenService {
		t.Fatal("missing existing resources")
	}
}

// UATArgs theo contract UAT; network/image dung chung fixture.
func UATArgs() *Args {
	args := NonProdArgs()
	args.Environment, args.StoragePrefix, args.DesiredCount, args.LogRetentionDays = "uat", "xbrain-uat-uploads-", 2, 14
	return args
}

func runWorkspace(t *testing.T, name string, args *Args) ([]pulumi.MockResourceArgs, error) {
	t.Helper()
	mocks := &testutil.Mocks{}
	err := pulumi.RunErr(func(ctx *pulumi.Context) error {
		_, err := New(ctx, name, args)
		return err
	}, pulumi.WithMocks("daily-workspace", name, mocks))
	return mocks.Resources(), err
}

func TestLogRetention(t *testing.T) {
	future := NonProdArgs()
	future.LogRetentionDays = 30
	explicit := NonProdArgs()
	explicit.LogRetentionDays = 7
	cases := []struct {
		name, stack string
		args        *Args
		want        float64
	}{
		{"nonprod default", "nonprod", NonProdArgs(), 7},
		{"nonprod explicit", "nonprod", explicit, 7},
		{"uat", "uat", UATArgs(), 14},
		{"future consumer", "nonprod", future, 30},
	}
	for _, tc := range cases {
		t.Run(tc.name, func(t *testing.T) {
			resources, err := runWorkspace(t, tc.stack, tc.args)
			if err != nil {
				t.Fatal(err)
			}
			seen := 0
			for _, item := range resources {
				if item.TypeToken != "aws:cloudwatch/logGroup:LogGroup" {
					continue
				}
				seen++
				if item.Name != tc.stack+"-workload-logs" {
					t.Fatalf("log group logical name changed: %s", item.Name)
				}
				parent := item.RegisterRPC.GetParent()
				if !strings.HasSuffix(parent, "xbrain:workload:Workload::"+tc.stack+"-workload") {
					t.Fatalf("log group must stay under workload component, got %s", parent)
				}
				if !strings.Contains(item.Provider, "::"+tc.stack+"-aws::") {
					t.Fatalf("log group must inherit workspace provider, got %s", item.Provider)
				}
				if got := item.Inputs["retentionInDays"].NumberValue(); got != tc.want {
					t.Fatalf("retention = %v, want %v", got, tc.want)
				}
				if item.Inputs["tags"].ObjectValue()["Environment"].StringValue() != tc.args.Environment {
					t.Fatal("log group tags must follow environment")
				}
			}
			if seen != 1 {
				t.Fatalf("expected exactly one log group under workload, got %d", seen)
			}
		})
	}
}

func TestUATKeepsContracts(t *testing.T) {
	resources, err := runWorkspace(t, "uat", UATArgs())
	if err != nil {
		t.Fatal(err)
	}
	for _, item := range resources {
		switch item.TypeToken {
		case "aws:s3/bucket:Bucket":
			if item.Inputs["bucketPrefix"].StringValue() != "xbrain-uat-uploads-" {
				t.Fatal("uat bucket prefix mismatch")
			}
		case "aws:ecs/service:Service":
			if item.Inputs["desiredCount"].NumberValue() != 2 {
				t.Fatal("uat capacity mismatch")
			}
		case "aws:ecs/taskDefinition:TaskDefinition":
			definitions := item.Inputs["containerDefinitions"].StringValue()
			if !strings.Contains(definitions, "fixture.invalid/api@sha256:"+strings.Repeat("a", 64)) || !strings.Contains(definitions, `"containerPort":8080`) {
				t.Fatal("image/port contract changed")
			}
		case "aws:ec2/securityGroup:SecurityGroup":
			ingress := item.Inputs["ingress"].ArrayValue()[0].ObjectValue()
			if ingress["cidrBlocks"].ArrayValue()[0].StringValue() != "10.30.0.0/16" || ingress["fromPort"].NumberValue() != 8080 {
				t.Fatal("ingress contract changed")
			}
		case "aws:ec2/vpc:Vpc", "aws:ec2/subnet:Subnet":
			t.Fatal("workspace must not own external network")
		}
	}
}

func TestInvalidLogRetentionRejected(t *testing.T) {
	for _, days := range []int{-1, 2, 8, 10000} {
		args := NonProdArgs()
		args.LogRetentionDays = days
		resources, err := runWorkspace(t, "nonprod", args)
		if err == nil {
			t.Fatalf("retention %d must be rejected", days)
		}
		for _, item := range resources {
			if item.TypeToken == "aws:cloudwatch/logGroup:LogGroup" {
				t.Fatalf("retention %d must not register a log group", days)
			}
		}
	}
}
