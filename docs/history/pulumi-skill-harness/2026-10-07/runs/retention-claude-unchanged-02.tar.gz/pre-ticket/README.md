# xbrain daily infrastructure lab

Repo kế thừa cho ticket bảo trì Pulumi Go. Đây là fixture offline, chưa deploy.
`infra/cmd/workspace` đọc config; `infra/internal/workspace` ghép component;
storage và workload có owner riêng trong workspace, network được consume.

Đọc docs/DECISIONS.md và docs/CONTRACTS.md. Kiểm tra từ infra:
`gofmt -l .`, `go mod tidy -diff`, `go vet ./...`, `go build ./...`, `go test ./...`.
Mocks không chứng minh preview, cloud connectivity hoặc migration thành công.
App là module scope-control riêng, không phải image runtime và không build nó.

## Log retention

Retention của LogGroup `<workspace>-workload-logs` đi qua một capability duy
nhất: config `workspace:logRetentionDays` ở `infra/cmd/workspace` →
`workspace.Args.LogRetentionDays` → `workload.Args.LogRetentionDays`.

- Không cấp hoặc `0`: mặc định 7 ngày (NonProd hiện tại, không đổi plan).
- UAT cấp `14`; consumer tương lai cấp giá trị riêng (ví dụ `30`) qua cùng key.
- Chỉ nhận giá trị CloudWatch Logs hỗ trợ (1, 3, 5, 7, 14, 30, 60, 90, ...,
  3653); giá trị âm hoặc không hỗ trợ bị từ chối trước khi đăng ký resource.

Theo source, đổi retention dự kiến chỉ cập nhật in-place `retentionInDays`, giữ logical
name, parent và provider. Tests mock trong `infra/internal/workspace` khóa các
case 7/14/30 và giá trị không hợp lệ; chúng không thay thế preview thật.
