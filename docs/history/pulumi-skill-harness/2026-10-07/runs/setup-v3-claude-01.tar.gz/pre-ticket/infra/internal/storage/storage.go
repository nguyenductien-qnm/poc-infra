package storage

import (
	"github.com/pulumi/pulumi-aws/sdk/v7/go/aws/s3"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
)

type Args struct{ Tags pulumi.StringMapInput }
type Storage struct {
	pulumi.ResourceState
	BucketName pulumi.StringOutput
}

func New(ctx *pulumi.Context, name string, args *Args, opts ...pulumi.ResourceOption) (*Storage, error) {
	component := &Storage{}
	if err := ctx.RegisterComponentResource("xbrain:storage:Storage", name, component, opts...); err != nil {
		return nil, err
	}
	bucket, err := s3.NewBucket(ctx, name+"-uploads", &s3.BucketArgs{
		BucketPrefix: pulumi.String("xbrain-nonprod-uploads-"),
		Tags:         args.Tags,
	}, pulumi.Parent(component))
	if err != nil {
		return nil, err
	}
	_, err = s3.NewBucketPublicAccessBlock(ctx, name+"-uploads-access", &s3.BucketPublicAccessBlockArgs{
		Bucket: bucket.ID(), BlockPublicAcls: pulumi.Bool(true), BlockPublicPolicy: pulumi.Bool(true),
		IgnorePublicAcls: pulumi.Bool(true), RestrictPublicBuckets: pulumi.Bool(true),
	}, pulumi.Parent(component))
	if err != nil {
		return nil, err
	}
	component.BucketName = bucket.Bucket
	if err := ctx.RegisterResourceOutputs(component, pulumi.Map{"bucketName": component.BucketName}); err != nil {
		return nil, err
	}
	return component, nil
}
