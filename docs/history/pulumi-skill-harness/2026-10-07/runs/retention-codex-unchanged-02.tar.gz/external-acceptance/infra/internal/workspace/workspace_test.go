package workspace

import (
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
	"strings"
	"testing"
	"xbrain.local/daily/internal/testutil"
)

func NonProdArgs() *Args {
	return &Args{Environment: "nonprod", Region: "ap-southeast-1", StoragePrefix: "xbrain-nonprod-uploads-", DesiredCount: 1,
		Image: pulumi.String("fixture.invalid/api@sha256:" + strings.Repeat("a", 64)),
		VpcID: pulumi.String("fixture-vpc"), SubnetIDs: pulumi.StringArray{pulumi.String("fixture-subnet-a")}, PeerCIDR: "10.30.0.0/16"}
}

func TestExistingNonProd(t *testing.T) {
	mocks := &testutil.Mocks{}
	err := pulumi.RunErr(func(ctx *pulumi.Context) error {
		result, err := New(ctx, "nonprod", NonProdArgs())
		if err != nil {
			return err
		}
		ctx.Export("bucketName", result.BucketName)
		ctx.Export("serviceName", result.ServiceName)
		return nil
	}, pulumi.WithMocks("daily-workspace", "nonprod", mocks))
	if err != nil {
		t.Fatal(err)
	}
	seenBucket, seenService, seenLogs := false, false, false
	for _, item := range mocks.Resources() {
		switch item.TypeToken {
		case "aws:cloudwatch/logGroup:LogGroup":
			seenLogs = true
			if item.Inputs["retentionInDays"].NumberValue() != 7 {
				t.Fatal("omitted retention must preserve 7 days for existing consumer")
			}
		case "aws:s3/bucket:Bucket":
			seenBucket = true
			if item.Name != "nonprod-storage-uploads" || item.Inputs["bucketPrefix"].StringValue() != "xbrain-nonprod-uploads-" {
				t.Fatal("existing bucket contract changed")
			}
			if item.RegisterRPC.GetParent() == "" || item.Provider == "" {
				t.Fatal("bucket must have parent/provider")
			}
		case "aws:ecs/service:Service":
			seenService = true
			if item.Inputs["desiredCount"].NumberValue() != 1 {
				t.Fatal("existing capacity changed")
			}
			network := item.Inputs["networkConfiguration"].ObjectValue()
			if network["subnets"].ArrayValue()[0].StringValue() != "fixture-subnet-a" {
				t.Fatal("external subnet not consumed")
			}
		case "aws:ec2/vpc:Vpc", "aws:ec2/subnet:Subnet":
			t.Fatal("workspace must not own external network")
		}
	}
	if !seenBucket || !seenService || !seenLogs {
		t.Fatal("missing existing resources")
	}
}

func TestFutureConsumerLogRetention(t *testing.T) {
	args := NonProdArgs()
	args.Environment = "future"
	args.StoragePrefix = "xbrain-future-uploads-"
	args.LogRetentionDays = 30
	mocks := &testutil.Mocks{}
	err := pulumi.RunErr(func(ctx *pulumi.Context) error {
		_, err := New(ctx, "future", args)
		return err
	}, pulumi.WithMocks("daily-workspace", "offline", mocks))
	if err != nil {
		t.Fatal(err)
	}
	logGroups := 0
	for _, item := range mocks.Resources() {
		if item.TypeToken != "aws:cloudwatch/logGroup:LogGroup" {
			continue
		}
		logGroups++
		if item.Inputs["retentionInDays"].NumberValue() != 30 {
			t.Fatal("future Go consumer must supply 30 days through workspace Args")
		}
		if item.Name != "future-workload-logs" || item.RegisterRPC == nil ||
			item.RegisterRPC.GetParent() != "urn:pulumi:offline::daily-workspace::xbrain:workspace:Workspace$xbrain:workload:Workload::future-workload" {
			t.Fatal("log group must retain the workload naming and parent contract")
		}
		if item.Provider != "urn:pulumi:offline::daily-workspace::pulumi:providers:aws::future-aws::future-aws-mock-id" {
			t.Fatal("log group must inherit the workspace provider")
		}
	}
	if logGroups != 1 {
		t.Fatal("future consumer must create exactly one workload log group")
	}
	if args.LogRetentionDays != 30 {
		t.Fatal("workspace must not mutate consumer retention Args")
	}
}
