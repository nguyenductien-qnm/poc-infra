package main

import (
	"encoding/json"
	"reflect"
	"strings"
	"testing"

	"github.com/pulumi/pulumi/sdk/v3/go/common/resource"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
	"xbrain.local/daily/internal/testutil"
)

func TestLogRetentionConfig(t *testing.T) {
	for _, tc := range []struct {
		name, environment, retention string
		capacity, wantDays           int
	}{
		{"nonprod-omitted", "nonprod", "", 1, 7},
		{"nonprod-zero", "nonprod", "0", 1, 7},
		{"nonprod-explicit", "nonprod", "7", 1, 7},
		{"uat", "uat", "14", 2, 14},
		{"future-consumer", "future", "30", 1, 30},
	} {
		t.Run(tc.name, func(t *testing.T) {
			image := "fixture.invalid/api@sha256:" + strings.Repeat("a", 64)
			prefix := "xbrain-" + tc.environment + "-uploads-"
			cfg := map[string]string{
				"workspace:environment": tc.environment, "workspace:region": "ap-southeast-1",
				"workspace:storagePrefix": prefix, "workspace:desiredCount": "1",
				"workspace:image": image, "workspace:vpcId": "fixture-vpc",
				"workspace:subnetId": "fixture-subnet-a", "workspace:peerCidr": "10.30.0.0/16",
			}
			if tc.capacity == 2 {
				cfg["workspace:desiredCount"] = "2"
			}
			if tc.retention != "" {
				cfg["workspace:logRetentionDays"] = tc.retention
			}
			mocks := &testutil.Mocks{}
			if err := pulumi.RunErr(run, pulumi.WithMocks("daily-workspace", "offline", mocks),
				func(info *pulumi.RunInfo) { info.Config = cfg }); err != nil {
				t.Fatal(err)
			}
			items := assertResourceIdentity(t, mocks.Resources())
			logs := items["nonprod-workload-logs"].Inputs
			if logs["retentionInDays"].NumberValue() != float64(tc.wantDays) {
				t.Fatalf("retention = %v, want %d days", logs["retentionInDays"].NumberValue(), tc.wantDays)
			}
			for _, item := range items {
				if strings.HasPrefix(item.TypeToken, "aws:") {
					tags := item.Inputs["tags"]
					if tags.IsObject() {
						assertInput(t, tags.ObjectValue(), "Environment", tc.environment)
						assertInput(t, tags.ObjectValue(), "Team", "xbrain")
					}
				}
			}
			assertInput(t, items["nonprod-aws"].Inputs, "region", "ap-southeast-1")
			bucket := items["nonprod-storage-uploads"].Inputs
			assertInput(t, bucket, "bucketPrefix", prefix)
			if _, fixed := bucket["bucket"]; fixed {
				t.Fatal("bucket must retain automatic naming")
			}
			service := items["nonprod-workload-service"].Inputs
			assertInput(t, service, "desiredCount", float64(tc.capacity))
			assertInput(t, service, "launchType", "FARGATE")
			network := service["networkConfiguration"].ObjectValue()
			assertInput(t, network, "subnets", []interface{}{"fixture-subnet-a"})
			assertInput(t, network, "securityGroups", []interface{}{"nonprod-workload-service-sg-mock-id"})
			assertInput(t, network, "assignPublicIp", true)
			sg := items["nonprod-workload-service-sg"].Inputs
			assertInput(t, sg, "vpcId", "fixture-vpc")
			ingress := sg["ingress"].ArrayValue()[0].ObjectValue()
			assertInput(t, ingress, "fromPort", float64(8080))
			assertInput(t, ingress, "toPort", float64(8080))
			assertInput(t, ingress, "protocol", "tcp")
			assertInput(t, ingress, "cidrBlocks", []interface{}{"10.30.0.0/16"})
			task := items["nonprod-workload-task"].Inputs
			assertInput(t, task, "cpu", "256")
			assertInput(t, task, "memory", "512")
			assertInput(t, task, "networkMode", "awsvpc")
			assertInput(t, task, "requiresCompatibilities", []interface{}{"FARGATE"})
			var containers []struct {
				Image        string
				PortMappings []struct {
					ContainerPort int
					Protocol      string
				}
				HealthCheck      struct{ Command []string }
				LogConfiguration struct {
					LogDriver string
					Options   map[string]string
				}
			}
			if err := json.Unmarshal([]byte(task["containerDefinitions"].StringValue()), &containers); err != nil {
				t.Fatal(err)
			}
			if len(containers) != 1 || containers[0].Image != image {
				t.Fatal("supplied image contract changed")
			}
			container := containers[0]
			if len(container.PortMappings) != 1 || container.PortMappings[0].ContainerPort != 8080 || container.PortMappings[0].Protocol != "tcp" ||
				!reflect.DeepEqual(container.HealthCheck.Command, []string{"CMD-SHELL", "curl -f http://localhost:8080/health || exit 1"}) {
				t.Fatal("port/health contract changed")
			}
			if container.LogConfiguration.LogDriver != "awslogs" || !reflect.DeepEqual(container.LogConfiguration.Options, map[string]string{
				"awslogs-group": "nonprod-workload-logs", "awslogs-region": "ap-southeast-1", "awslogs-stream-prefix": "api",
			}) {
				t.Fatal("task must consume the existing log group output")
			}
		})
	}
}

func assertResourceIdentity(t *testing.T, resources []pulumi.MockResourceArgs) map[string]pulumi.MockResourceArgs {
	t.Helper()
	stack := "urn:pulumi:offline::daily-workspace::pulumi:pulumi:Stack::daily-workspace-offline"
	workspace := "urn:pulumi:offline::daily-workspace::xbrain:workspace:Workspace::nonprod"
	storage := "urn:pulumi:offline::daily-workspace::xbrain:workspace:Workspace$xbrain:storage:Storage::nonprod-storage"
	workload := "urn:pulumi:offline::daily-workspace::xbrain:workspace:Workspace$xbrain:workload:Workload::nonprod-workload"
	provider := "urn:pulumi:offline::daily-workspace::pulumi:providers:aws::nonprod-aws::nonprod-aws-mock-id"
	expected := map[string]struct{ token, parent string }{
		"nonprod-aws":                    {"pulumi:providers:aws", stack},
		"nonprod":                        {"xbrain:workspace:Workspace", stack},
		"nonprod-storage":                {"xbrain:storage:Storage", workspace},
		"nonprod-workload":               {"xbrain:workload:Workload", workspace},
		"nonprod-storage-uploads":        {"aws:s3/bucket:Bucket", storage},
		"nonprod-storage-uploads-access": {"aws:s3/bucketPublicAccessBlock:BucketPublicAccessBlock", storage},
		"nonprod-workload-logs":          {"aws:cloudwatch/logGroup:LogGroup", workload},
		"nonprod-workload-execution":     {"aws:iam/role:Role", workload},
		"nonprod-workload-logs-policy":   {"aws:iam/rolePolicy:RolePolicy", workload},
		"nonprod-workload-service-sg":    {"aws:ec2/securityGroup:SecurityGroup", workload},
		"nonprod-workload-cluster":       {"aws:ecs/cluster:Cluster", workload},
		"nonprod-workload-task":          {"aws:ecs/taskDefinition:TaskDefinition", workload},
		"nonprod-workload-service":       {"aws:ecs/service:Service", workload},
	}
	items := make(map[string]pulumi.MockResourceArgs)
	for _, item := range resources {
		want, ok := expected[item.Name]
		if !ok || item.TypeToken != want.token {
			t.Fatal("resource type/name or ownership changed")
		}
		if _, duplicate := items[item.Name]; duplicate {
			t.Fatal("resource registered more than once")
		}
		if item.RegisterRPC == nil || item.RegisterRPC.GetParent() != want.parent || item.ID != "" {
			t.Fatal("resource parent or import ownership changed")
		}
		if strings.HasPrefix(item.TypeToken, "aws:") && item.Provider != provider {
			t.Fatal("AWS child must inherit the existing workspace provider")
		}
		if item.TypeToken == "pulumi:providers:aws" && item.Provider != "" {
			t.Fatal("workspace provider must remain registered at stack root")
		}
		items[item.Name] = item
	}
	if len(items) != len(expected) {
		t.Fatal("missing existing resources")
	}
	return items
}

func assertInput(t *testing.T, inputs resource.PropertyMap, key resource.PropertyKey, want interface{}) {
	t.Helper()
	value, ok := inputs[key]
	if !ok || !reflect.DeepEqual(value.Mappable(), want) {
		t.Fatalf("input %s does not match the supplied contract", key)
	}
}
