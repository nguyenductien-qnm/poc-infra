# xbrain daily infrastructure lab

Repo kế thừa cho ticket bảo trì Pulumi Go. Đây là fixture offline, chưa deploy.
`infra/cmd/workspace` đọc config; `infra/internal/workspace` ghép component;
storage và workload có owner riêng trong workspace, network được consume.

Đọc docs/DECISIONS.md và docs/CONTRACTS.md. Kiểm tra từ infra:
`gofmt -l .`, `go mod tidy -diff`, `go vet ./...`, `go build ./...`, `go test ./...`.
Mocks không chứng minh preview, cloud connectivity hoặc migration thành công.
App là module scope-control riêng, không phải image runtime và không build nó.

## Cấu hình thời gian giữ log

Composition root `infra/cmd/workspace` đọc `workspace:logRetentionDays` và truyền
qua `workspace.Args.LogRetentionDays` → `workload.Args.LogRetentionDays` →
`LogGroup.RetentionInDays`. Workload áp dụng mặc định 7 ngày khi Args bằng 0;
consumer gọi trực tiếp cũng dùng cùng quy tắc này. Giá trị 0 ở capability này
không có nghĩa là giữ log vô thời hạn.

| Consumer | `workspace:logRetentionDays` | Retention thực tế |
| --- | --- | --- |
| NonProd hiện tại | Không cấp, `0` hoặc `7` | 7 ngày |
| UAT | `14` | 14 ngày |
| Consumer tương lai | `30` | 30 ngày |

Consumer Go cấp số ngày qua `workspace.Args{LogRetentionDays: 30, ...}` cùng
các Args mạng/image/capacity đã được cấp. Nếu dùng composition root, cấp số
nguyên qua key `workspace:logRetentionDays`; dùng các giá trị retention hợp lệ
của CloudWatch theo SDK đang pin. Cấu hình UAT còn cần environment `uat`,
storage prefix `xbrain-uat-uploads-`, desired count 2 và contract mạng riêng.
Các case UAT/tương lai trong tests chỉ dùng fixture offline; chưa onboard UAT.

Thay đổi chỉ áp dụng thuộc tính retention của LogGroup hiện có. Type token,
logical name, parent, provider và owner giữ nguyên; không cần alias/migration
theo source. Root hiện tại vẫn dùng logical name `nonprod`, không tự đổi theo
environment. Network/image contracts và `docs/CONTRACTS.md` được giữ nguyên.
Chưa có preview để xác nhận kế hoạch thay đổi trên cloud.

Regression tests chạy chính composition root bằng Pulumi mocks, kiểm tra config
bỏ trống/0/7/14/30, capacity/tags/prefix của consumer, resource inventory,
parent/provider, network và image/port/health/log wiring. Test consumer Go hiện
có xác nhận không cấp retention vẫn giữ 7 ngày. Chạy checks trong `infra` với
`GOPROXY=off`, `GOSUMDB=off`, `GOTOOLCHAIN=local` để dùng dependencies/toolchain
đã có cục bộ; không chạy lệnh Pulumi hay build module app trong lab offline.
