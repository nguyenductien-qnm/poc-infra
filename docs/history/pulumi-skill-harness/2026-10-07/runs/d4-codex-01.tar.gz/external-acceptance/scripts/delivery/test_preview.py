import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import unittest


ROOT = Path(__file__).resolve().parents[2]
ENTRY = ROOT / "scripts" / "delivery" / "preview.ps1"
WORKFLOW = ROOT / ".github" / "workflows" / "d4-preview.yml"
CAPTURE = ROOT / "fixtures" / "d4-preview.synthetic.log"
PWSH = shutil.which("pwsh")


def traces(output):
    return [json.loads(line.removeprefix("D4_STUB:"))
            for line in output.splitlines() if line.startswith("D4_STUB:")]


class WorkflowSourceTests(unittest.TestCase):
    def test_manual_revision_wiring_and_fixed_backend(self):
        source = WORKFLOW.read_text(encoding="utf-8-sig")
        events = re.search(r"^on:\n(.*?)(?=^\S)", source, re.MULTILINE | re.DOTALL)
        self.assertIsNotNone(events, "missing event declaration")
        self.assertEqual(re.findall(r"^  ([\w-]+):$", events[1], re.MULTILINE),
                         ["workflow_dispatch"])
        self.assertEqual(re.findall(r"^      ([\w-]+):$", events[1], re.MULTILINE),
                         ["revision", "origin", "mode"])
        for declaration in (
            "D4_EVENT_NAME: ${{ github.event_name }}",
            "D4_ORIGIN: ${{ inputs.origin }}",
            "D4_OPERATION: ${{ inputs.mode }}",
            "D4_REVISION: ${{ inputs.revision }}",
            "D4_BACKEND_LABEL: fixture-backend-nonprod",
            "ref: ${{ inputs.revision }}",
            "persist-credentials: false",
            "contents: read",
            "shell: pwsh",
        ):
            self.assertEqual(source.count(declaration), 1, declaration)
        self.assertIn(
            "if: ${{ github.event_name == 'workflow_dispatch' && "
            "inputs.origin == 'pull_request' && inputs.mode == 'preview' }}", source)
        self.assertRegex(source, r"uses: actions/checkout@[0-9a-f]{40}\s")
        self.assertRegex(source, r"run: \|\n +\./scripts/delivery/preview\.ps1\s*")
        self.assertNotRegex(source, r"(?m)^\s*(environment|D4_TARGET):")

    def test_original_capture_exposes_target_mismatch(self):
        source = CAPTURE.read_text(encoding="utf-8-sig")
        self.assertIn("SYNTHETIC", source)
        self.assertEqual(traces(source), [{
            "synthetic": True, "command": "preview", "stack": "uat",
            "backend_label": "fixture-backend-nonprod", "revision": "a" * 40,
        }])


class EntrypointTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        if PWSH is None:
            raise RuntimeError("PowerShell 7 is required for delivery execution tests")

    def execute(self, **overrides):
        environment = os.environ.copy()
        environment.update({
            "D4_EVENT_NAME": "workflow_dispatch", "D4_ORIGIN": "pull_request",
            "D4_OPERATION": "preview", "D4_REVISION": "a" * 40,
            "D4_BACKEND_LABEL": "fixture-backend-nonprod",
        })
        environment.update(overrides)
        return subprocess.run(
            [PWSH, "-NoLogo", "-NoProfile", "-NonInteractive", "-File", str(ENTRY)],
            cwd=ROOT, env=environment, capture_output=True, text=True,
            encoding="utf-8", timeout=30, check=False)

    def test_nonprod_fixed_target_and_exact_revision(self):
        for revision in ("a" * 40, "0123456789abcdef" * 2 + "01234567"):
            with self.subTest(revision=revision):
                result = self.execute(D4_REVISION=revision)
                self.assertEqual(result.returncode, 0, "entrypoint failed")
                self.assertEqual(traces(result.stdout), [{
                    "synthetic": True, "command": "preview", "stack": "nonprod",
                    "backend_label": "fixture-backend-nonprod", "revision": revision,
                }])

    def test_target_environment_override_cannot_select_uat(self):
        result = self.execute(D4_TARGET="uat", D4_STACK="uat", PULUMI_STACK="uat")
        self.assertEqual(result.returncode, 0)
        self.assertEqual(traces(result.stdout), [{
            "synthetic": True, "command": "preview", "stack": "nonprod",
            "backend_label": "fixture-backend-nonprod", "revision": "a" * 40,
        }])

    def test_backend_environment_override_is_rejected(self):
        result = self.execute(D4_BACKEND_LABEL="fixture-backend-uat")
        self.assertNotEqual(result.returncode, 0)
        self.assertEqual(traces(result.stdout), [])
        self.assertIn("Fixed mock backend label required", result.stderr)

    def test_other_operations_events_and_origins_do_not_invoke_stub(self):
        for override in (
            {"D4_OPERATION": "deploy"}, {"D4_EVENT_NAME": "push"},
            {"D4_EVENT_NAME": "pull_request"}, {"D4_ORIGIN": "push"},
            {"D4_ORIGIN": "other"},
        ):
            with self.subTest(override=override):
                result = self.execute(**override)
                self.assertEqual(result.returncode, 0)
                self.assertEqual(traces(result.stdout), [])
                self.assertIn("D4_GATE:blocked", result.stdout)

    def test_invalid_revisions_do_not_invoke_stub(self):
        for revision in ("", "main", "a" * 39, "a" * 41, "g" * 40):
            with self.subTest(revision=revision):
                result = self.execute(D4_REVISION=revision)
                self.assertNotEqual(result.returncode, 0)
                self.assertEqual(traces(result.stdout), [])
                self.assertIn("Full synthetic revision required", result.stderr)


if __name__ == "__main__":
    unittest.main()
