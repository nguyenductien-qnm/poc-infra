# Vận hành D4 — manual preview fixture

Đọc [contract D4](D4-DELIVERY.md) trước khi dùng entry này. Đây là luồng manual
dispatch cho revision có origin PR, chỉ chạy stub local và chỉ chọn NonProd.
Deploy manual có approval vẫn là luồng riêng. Ticket không đổi workflow trigger,
permissions, approval hoặc environment rules.

## Nguyên nhân và sửa lỗi

Log chỉ đọc `fixtures/d4-preview.synthetic.log` ghi một execution PowerShell/stub
với stack `uat` và backend label `fixture-backend-nonprod`. Source entrypoint cũ
hard-code `$target = 'uat'`; workflow không có input chọn target. Stub cho phép
cả hai stack fixture, nên việc stub chạy thành công không xác nhận contract D4.

Sửa duy nhất lỗi delivery này bằng target cố định `nonprod` trong
`scripts/delivery/preview.ps1`. Backend label vẫn cố định; label khác bị từ chối.
Các environment override target/stack không được dùng để chọn UAT. Giữ nguyên
stub và capture cũ làm bằng chứng chẩn đoán, không sửa trace để trông như pass.

Revision đi theo chuỗi source `inputs.revision` → `actions/checkout.with.ref` và
`D4_REVISION` → entrypoint → argument `-Revision` của stub → JSON trace. Root
không thay revision thành branch name hay giá trị mặc định. Workflow giữ
checkout action được pin bằng commit SHA và `persist-credentials: false`.

## Chạy kiểm chứng local

Từ repository root, dùng PowerShell 7 và Python 3 đã có sẵn:

```powershell
python -B -m unittest discover -s scripts/delivery -p test_preview.py -v
```

Tests gọi chính entrypoint bằng PowerShell subprocess và stub chỉ đọc. Các case
bao gồm hai revision khác nhau truyền nguyên vẹn tới trace, NonProd/backend cố
định, target override, backend sai, revision sai và gates chặn deploy/push/origin
khác. Gate bị chặn hiện trả `D4_GATE:blocked` với exit 0 và không gọi stub;
revision/backend sai trả lỗi. Source checks kiểm tra manual-only trigger,
ba inputs, checkout/ref/env wiring, read-only permission và đường gọi entrypoint.
Đây là kiểm tra source theo cấu trúc fixture, không phải parser YAML tổng quát
hay validator GitHub Actions.

Có thể chạy một execution fixture thủ công, vẫn không gọi Pulumi CLI:

```powershell
$env:D4_EVENT_NAME = 'workflow_dispatch'
$env:D4_ORIGIN = 'pull_request'
$env:D4_OPERATION = 'preview'
$env:D4_REVISION = 'a' * 40
$env:D4_BACKEND_LABEL = 'fixture-backend-nonprod'
pwsh -NoProfile -NonInteractive -File ./scripts/delivery/preview.ps1
```

Trace mong đợi có `synthetic=true`, command `preview`, stack `nonprod`, label
`fixture-backend-nonprod` và revision đã supply. Không truyền target/backend từ
PR input. Backend label là metadata mock, không phải endpoint có thể login.
Execution này không đọc config/state/credentials và không tạo observed plan.

Chạy Go checks offline trong từng module `infra` và
`offline-controls/secret-transform`, dùng dependencies đã cache:

```powershell
$env:GOTOOLCHAIN = 'local'
$env:GOPROXY = 'off'
$env:GOSUMDB = 'off'
gofmt -l .
go mod tidy -diff
go vet ./...
go build ./...
go test ./... -count=1 -v
```

Control secret-transform độc lập với lỗi delivery. Nó tạo input trong memory,
bọc Output bằng `ToSecret`, encode thuần trong `ApplyT` và truyền Output trực
tiếp vào property Input của consumer. Test kiểm tra secret metadata và property
dependency tới source; không in input hoặc output đã encode, không fetch secret
hay config thật. Không cần sửa helper/control để sửa target preview.

Hạ tầng D3b giữ nguyên aliases object-store, `ReplicaCount int`, persisted key
`workspace:desiredCount`, capacity NonProd 1/UAT 2, retention 7 và config/network
examples. UAT vẫn là consumer hạ tầng nhưng không thuộc entry preview D4 này.

## Bàn giao integration

| Owner | Input/quyền và bằng chứng còn cần |
| --- | --- |
| Owner delivery | Quyền manual dispatch, PR revision được duyệt, workflow/runner được tin cậy; run CI thật đối chiếu checkout SHA, entrypoint và trace cùng exact revision |
| Owner state/backend — cần chỉ định | Backend live, scope NonProd, cơ chế truy cập, locking/encryption/recovery và contract config; mock label hiện tại không cung cấp các phần này |
| Owner cloud/CI identity — cần chỉ định | Identity và quyền preview theo scope được duyệt, trust boundary cho PR code; deploy identity và approval path riêng |
| Network/app owners | Refs mạng và image live theo contract; các fixture hiện không dùng để triển khai |

Owner delivery cần kiểm tra target/config/backend và quyền preview trên run thật,
đồng thời xác nhận luồng deploy có approval riêng. Workflow fixture chỉ có
`contents: read`; không chứng minh có cloud permissions hoặc deployment approval.
Không tự bootstrap identity để biến local check thành integration.

Kết quả offline chỉ xác nhận source wiring và execution PowerShell/stub đã chạy.
Nó không chứng minh checkout SHA thực tế trong CI, backend/state isolation,
preview AWS, migration aliases, physical IDs, giữ dữ liệu hay deployment gate.
