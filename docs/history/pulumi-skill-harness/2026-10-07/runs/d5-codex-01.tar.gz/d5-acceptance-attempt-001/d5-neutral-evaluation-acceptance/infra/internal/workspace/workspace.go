package workspace

import (
	"fmt"
	"net/netip"

	aws "github.com/pulumi/pulumi-aws/sdk/v7/go/aws"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
	"xbrain.local/daily/internal/storage"
	"xbrain.local/daily/internal/workload"
)

type Args struct {
	Environment       string
	Region            string
	StoragePrefix     string
	ReplicaCount      int
	Image             pulumi.StringInput
	VpcID             pulumi.StringInput
	SubnetIDs         pulumi.StringArrayInput
	PeerCIDR          string
	OutboundHTTPSCIDR netip.Prefix
}

type Workspace struct {
	pulumi.ResourceState
	BucketName  pulumi.StringOutput
	ServiceName pulumi.StringOutput
}

func New(ctx *pulumi.Context, name string, args *Args, opts ...pulumi.ResourceOption) (*Workspace, error) {
	if args == nil || args.Environment == "" || args.Region == "" || args.StoragePrefix == "" || args.ReplicaCount < 1 {
		return nil, fmt.Errorf("workspace requires environment, region, storage prefix and positive capacity")
	}
	var outbound netip.Prefix
	if args.Environment == "uat" {
		if !args.OutboundHTTPSCIDR.IsValid() || !args.OutboundHTTPSCIDR.Addr().Is4() || args.OutboundHTTPSCIDR.Bits() == 0 {
			return nil, fmt.Errorf("UAT requires an outbound HTTPS IPv4 CIDR narrower than /0")
		}
		outbound = args.OutboundHTTPSCIDR.Masked()
	}
	provider, err := aws.NewProvider(ctx, name+"-aws", &aws.ProviderArgs{Region: pulumi.String(args.Region)})
	if err != nil {
		return nil, err
	}
	component := &Workspace{}
	options := append([]pulumi.ResourceOption{pulumi.Providers(provider)}, opts...)
	if err := ctx.RegisterComponentResource("xbrain:workspace:Workspace", name, component, options...); err != nil {
		return nil, err
	}
	tags := pulumi.StringMap{"Team": pulumi.String("xbrain"), "Environment": pulumi.String(args.Environment)}
	uploads, err := storage.New(ctx, name+"-object-store", &storage.Args{
		BucketPrefix: pulumi.String(args.StoragePrefix), Tags: tags,
	}, pulumi.Parent(component), pulumi.Aliases([]pulumi.Alias{
		{Name: pulumi.String(name + "-storage")},
	}))
	if err != nil {
		return nil, err
	}
	service, err := workload.New(ctx, name+"-workload", &workload.Args{
		Image: args.Image, VpcID: args.VpcID, SubnetIDs: args.SubnetIDs,
		PeerCIDR: args.PeerCIDR, ReplicaCount: args.ReplicaCount,
		OutboundHTTPSCIDR: outbound,
		Region:            args.Region, Tags: tags,
	}, pulumi.Parent(component))
	if err != nil {
		return nil, err
	}
	component.BucketName = uploads.BucketName
	component.ServiceName = service.ServiceName
	if err := ctx.RegisterResourceOutputs(component, pulumi.Map{"bucketName": component.BucketName, "serviceName": component.ServiceName}); err != nil {
		return nil, err
	}
	return component, nil
}
