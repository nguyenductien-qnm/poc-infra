package main

import (
	"errors"
	"fmt"
	"net/netip"
	"strings"

	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi/config"
	"xbrain.local/daily/internal/workspace"
)

func main() {
	d5InterceptRun(run)
}

func run(ctx *pulumi.Context) error {
	cfg := config.New(ctx, "workspace")
	environment := cfg.Require("environment")
	outbound, err := readOutboundHTTPSCIDR(cfg, environment)
	if err != nil {
		return err
	}
	subnets, err := readSubnetIDs(cfg)
	if err != nil {
		return err
	}
	result, err := workspace.New(ctx, environment, &workspace.Args{
		Environment:       environment,
		Region:            cfg.Require("region"),
		StoragePrefix:     cfg.Require("storagePrefix"),
		ReplicaCount:      cfg.RequireInt("desiredCount"),
		Image:             pulumi.String(cfg.Require("image")),
		VpcID:             pulumi.String(cfg.Require("vpcId")),
		SubnetIDs:         subnets,
		PeerCIDR:          cfg.Require("peerCidr"),
		OutboundHTTPSCIDR: outbound,
	})
	if err != nil {
		return err
	}
	ctx.Export("bucketName", result.BucketName)
	ctx.Export("serviceName", result.ServiceName)
	return nil
}

func readOutboundHTTPSCIDR(cfg *config.Config, environment string) (netip.Prefix, error) {
	if environment != "uat" {
		return netip.Prefix{}, nil
	}
	raw, err := cfg.Try("outboundHttpsCidr")
	if err != nil {
		return netip.Prefix{}, fmt.Errorf("UAT requires workspace:outboundHttpsCidr")
	}
	prefix, err := netip.ParsePrefix(raw)
	if err != nil || !prefix.Addr().Is4() || prefix.Bits() == 0 {
		return netip.Prefix{}, fmt.Errorf("workspace:outboundHttpsCidr must be an IPv4 CIDR narrower than /0")
	}
	return prefix.Masked(), nil
}

func readSubnetIDs(cfg *config.Config) (pulumi.StringArray, error) {
	var refs []string
	err := cfg.TryObject("subnetIds", &refs)
	if errors.Is(err, config.ErrMissingVar) {
		legacy, err := cfg.Try("subnetId")
		if err != nil || strings.TrimSpace(legacy) == "" {
			return nil, fmt.Errorf("workspace requires subnetIds or legacy subnetId")
		}
		refs = []string{legacy}
	} else if err != nil || len(refs) == 0 {
		return nil, fmt.Errorf("workspace:subnetIds must be a non-empty list of subnet references")
	}
	subnets := make(pulumi.StringArray, len(refs))
	for i, ref := range refs {
		if strings.TrimSpace(ref) == "" {
			return nil, fmt.Errorf("workspace subnet references must not be blank")
		}
		subnets[i] = pulumi.String(ref)
	}
	return subnets, nil
}
