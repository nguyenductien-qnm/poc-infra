package workspace

import (
	"encoding/json"
	"fmt"
	"github.com/pulumi/pulumi/sdk/v3/go/common/resource"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
	pulumirpc "github.com/pulumi/pulumi/sdk/v3/proto/go"
	"net/netip"
	"os"
	"os/exec"
	"reflect"
	"sort"
	"strings"
	"sync"
	"testing"
	"xbrain.local/daily/internal/workload"
)

type d5Mocks struct {
	mu      sync.Mutex
	records []pulumi.MockResourceArgs
	outputs map[string]string
}

func (m *d5Mocks) Call(args pulumi.MockCallArgs) (resource.PropertyMap, error) {
	return nil, fmt.Errorf("unexpected offline invoke: %s", args.Token)
}
func (m *d5Mocks) NewResource(args pulumi.MockResourceArgs) (string, resource.PropertyMap, error) {
	m.mu.Lock()
	m.records = append(m.records, args)
	m.mu.Unlock()
	outputs := args.Inputs.Copy()
	outputs["name"] = resource.NewStringProperty(args.Name)
	outputs["arn"] = resource.NewStringProperty("fixture-reference-" + args.Name)
	if args.TypeToken == "aws:s3/bucket:Bucket" {
		outputs["bucket"] = resource.NewStringProperty(args.Name + "-mock")
	}
	return args.Name + "-mock-id", outputs, nil
}
func (m *d5Mocks) resources() []pulumi.MockResourceArgs {
	m.mu.Lock()
	defer m.mu.Unlock()
	return append([]pulumi.MockResourceArgs(nil), m.records...)
}

type d5Contract struct {
	name, environment, region, prefix, vpc, cidr string
	capacity                                     int
	subnets                                      []string
}

func d5Contracts() []d5Contract {
	return []d5Contract{
		{name: "nonprod", environment: "nonprod", region: "ap-southeast-1", prefix: "xbrain-nonprod-uploads-", capacity: 1, vpc: "fixture-vpc", subnets: []string{"fixture-subnet-a"}, cidr: "10.30.0.0/16"},
		{name: "uat", environment: "uat", region: "ap-southeast-1", prefix: "xbrain-uat-uploads-", capacity: 2, vpc: "fixture-vpc-uat", subnets: []string{"fixture-subnet-uat-a", "fixture-subnet-uat-b"}, cidr: "10.30.0.0/16"},
	}
}
func d5Args(t *testing.T, spec d5Contract) *Args {
	subnets := pulumi.StringArray{}
	for _, subnet := range spec.subnets {
		subnets = append(subnets, pulumi.String(subnet))
	}
	args := &Args{Environment: spec.environment, Region: spec.region, StoragePrefix: spec.prefix, ReplicaCount: spec.capacity,
		Image: pulumi.String("fixture.invalid/api@sha256:" + strings.Repeat("a", 64)), VpcID: pulumi.String(spec.vpc), SubnetIDs: subnets, PeerCIDR: spec.cidr}
	if spec.name == "uat" {
		d5SetOutbound(t, args, "10.42.0.0/24")
	}
	return args
}

type d5Identity struct{ Type, Name, Parent, Provider string }

func d5Inventory(m *d5Mocks) []d5Identity {
	result := []d5Identity{}
	for _, item := range m.resources() {
		result = append(result, d5Identity{item.TypeToken, item.Name, item.RegisterRPC.GetParent(), item.Provider})
	}
	sort.Slice(result, func(i, j int) bool { return result[i].Type+"/"+result[i].Name < result[j].Type+"/"+result[j].Name })
	return result
}

func d5AssertInventory(t *testing.T, spec d5Contract, m *d5Mocks) {
	t.Helper()
	var expected []d5Identity
	data := strings.ReplaceAll(d5FrozenNonProdIdentity, "nonprod", spec.name)
	if err := json.Unmarshal([]byte(data), &expected); err != nil {
		t.Fatal(err)
	}
	component := d5One(t, m, "xbrain:storage:Storage")
	componentURN := d5URN(spec.name, "daily-workspace", component.TypeToken, component.Name, component.RegisterRPC.GetParent())
	for i := range expected {
		item := &expected[i]
		switch item.Type {
		case "xbrain:storage:Storage":
			item.Name = spec.name + "-object-store"
		case "aws:s3/bucket:Bucket", "aws:s3/bucketPublicAccessBlock:BucketPublicAccessBlock":
			actual := d5One(t, m, item.Type)
			desiredName := strings.Replace(item.Name, spec.name+"-storage", spec.name+"-object-store", 1)
			if actual.Name != desiredName {
				t.Errorf("D5_CURRENT_STORAGE_NAME:%s: got %s, want %s", item.Type, actual.Name, desiredName)
			}
			item.Name = actual.Name
			item.Parent = componentURN
		}
	}
	sort.Slice(expected, func(i, j int) bool {
		return expected[i].Type+"/"+expected[i].Name < expected[j].Type+"/"+expected[j].Name
	})
	actual := d5Inventory(m)
	encoded, _ := json.Marshal(actual)
	t.Log("D5_REGISTRATION_INVENTORY:" + string(encoded))
	if len(expected) != 13 || !reflect.DeepEqual(actual, expected) {
		t.Errorf("D5_RESOURCE_INVENTORY: thirteen-resource type/parent/provider inventory changed: got %s", encoded)
	}
	for _, item := range m.resources() {
		if item.ID != "" || item.ReadRPC != nil || item.RegisterRPC.GetImportId() != "" {
			t.Errorf("unexpected external read/import: %s/%s", item.TypeToken, item.Name)
		}
		if strings.HasPrefix(item.TypeToken, "aws:ec2/") && item.TypeToken != "aws:ec2/securityGroup:SecurityGroup" {
			t.Error("D5_SHARED_OWNERSHIP: workspace registered externally owned network")
		}
	}
}

func d5One(t *testing.T, m *d5Mocks, token string) pulumi.MockResourceArgs {
	t.Helper()
	found := []pulumi.MockResourceArgs{}
	for _, item := range m.resources() {
		if item.TypeToken == token {
			found = append(found, item)
		}
	}
	if len(found) != 1 {
		t.Fatalf("got %d resources for %s, want 1", len(found), token)
	}
	return found[0]
}
func d5String(t *testing.T, props resource.PropertyMap, key string) string {
	t.Helper()
	value, ok := props[resource.PropertyKey(key)]
	if !ok || !value.IsString() {
		t.Fatalf("%s must be a concrete string", key)
	}
	return value.StringValue()
}
func d5Object(t *testing.T, props resource.PropertyMap, key string) resource.PropertyMap {
	t.Helper()
	value, ok := props[resource.PropertyKey(key)]
	if !ok || !value.IsObject() {
		t.Fatalf("%s must be an object", key)
	}
	return value.ObjectValue()
}
func d5Array(t *testing.T, props resource.PropertyMap, key string) []resource.PropertyValue {
	t.Helper()
	value, ok := props[resource.PropertyKey(key)]
	if !ok || !value.IsArray() {
		t.Fatalf("%s must be an array", key)
	}
	return value.ArrayValue()
}
func d5Strings(t *testing.T, props resource.PropertyMap, key string) []string {
	t.Helper()
	result := []string{}
	for _, value := range d5Array(t, props, key) {
		if !value.IsString() {
			t.Fatalf("%s array must contain strings", key)
		}
		result = append(result, value.StringValue())
	}
	return result
}
func d5WantString(t *testing.T, props resource.PropertyMap, key, want string) {
	t.Helper()
	if got := d5String(t, props, key); got != want {
		t.Errorf("%s: got %q, want %q", key, got, want)
	}
}
func d5WantNumber(t *testing.T, props resource.PropertyMap, key string, want float64) {
	t.Helper()
	value, ok := props[resource.PropertyKey(key)]
	if !ok || !value.IsNumber() {
		t.Fatalf("%s must be a concrete number", key)
	}
	if got := value.NumberValue(); got != want {
		t.Errorf("%s: got %v, want %v", key, got, want)
	}
}
func d5WantBool(t *testing.T, props resource.PropertyMap, key string, want bool) {
	t.Helper()
	value, ok := props[resource.PropertyKey(key)]
	if !ok || !value.IsBool() {
		t.Fatalf("%s must be a concrete boolean", key)
	}
	if got := value.BoolValue(); got != want {
		t.Errorf("%s: got %v, want %v", key, got, want)
	}
}
func d5CaptureOutputs(ctx *pulumi.Context, m *d5Mocks, result *Workspace) {
	result.BucketName.ApplyT(func(value string) string { m.mu.Lock(); m.outputs["bucketName"] = value; m.mu.Unlock(); return value })
	result.ServiceName.ApplyT(func(value string) string { m.mu.Lock(); m.outputs["serviceName"] = value; m.mu.Unlock(); return value })
	ctx.Export("bucketName", result.BucketName)
	ctx.Export("serviceName", result.ServiceName)
}
func TestHarnessD5Consumers(t *testing.T) {
	for _, spec := range d5Contracts() {
		t.Run(spec.name, func(t *testing.T) {
			args := d5Args(t, spec)
			mocks := &d5Mocks{outputs: map[string]string{}}
			err := pulumi.RunErr(func(ctx *pulumi.Context) error {
				result, err := New(ctx, spec.name, args)
				if err != nil {
					return err
				}
				d5CaptureOutputs(ctx, mocks, result)
				return nil
			}, pulumi.WithMocks("daily-workspace", spec.name, mocks))
			if err != nil {
				t.Fatal(err)
			}
			d5AssertInventory(t, spec, mocks)
			provider := d5One(t, mocks, "pulumi:providers:aws")
			if provider.Name != spec.name+"-aws" {
				t.Error("provider logical name changed")
			}
			d5WantString(t, provider.Inputs, "region", spec.region)
			for _, token := range []string{"aws:s3/bucket:Bucket", "aws:cloudwatch/logGroup:LogGroup", "aws:ec2/securityGroup:SecurityGroup", "aws:iam/role:Role", "aws:ecs/cluster:Cluster", "aws:ecs/taskDefinition:TaskDefinition", "aws:ecs/service:Service"} {
				tags := d5Object(t, d5One(t, mocks, token).Inputs, "tags")
				d5WantString(t, tags, "Team", "xbrain")
				d5WantString(t, tags, "Environment", spec.environment)
			}
			bucket := d5One(t, mocks, "aws:s3/bucket:Bucket")
			d5WantString(t, bucket.Inputs, "bucketPrefix", spec.prefix)
			block := d5One(t, mocks, "aws:s3/bucketPublicAccessBlock:BucketPublicAccessBlock")
			d5WantString(t, block.Inputs, "bucket", bucket.Name+"-mock-id")
			for _, key := range []string{"blockPublicAcls", "blockPublicPolicy", "ignorePublicAcls", "restrictPublicBuckets"} {
				d5WantBool(t, block.Inputs, key, true)
			}
			group := d5One(t, mocks, "aws:ec2/securityGroup:SecurityGroup")
			d5WantString(t, group.Inputs, "vpcId", spec.vpc)
			ingress := d5Array(t, group.Inputs, "ingress")
			if len(ingress) != 1 || !ingress[0].IsObject() {
				t.Fatal("expected one internal ingress rule")
			}
			rule := ingress[0].ObjectValue()
			d5WantString(t, rule, "protocol", "tcp")
			d5WantNumber(t, rule, "fromPort", 8080)
			d5WantNumber(t, rule, "toPort", 8080)
			if got := d5Strings(t, rule, "cidrBlocks"); !reflect.DeepEqual(got, []string{spec.cidr}) {
				t.Errorf("ingress CIDR: got %v, want %v", got, spec.cidr)
			}
			d5AssertEgress(t, spec, group, "10.42.0.0/24")
			logs := d5One(t, mocks, "aws:cloudwatch/logGroup:LogGroup")
			d5WantNumber(t, logs.Inputs, "retentionInDays", 7)
			role := d5One(t, mocks, "aws:iam/role:Role")
			var assume, wantAssume map[string]interface{}
			if err := json.Unmarshal([]byte(d5String(t, role.Inputs, "assumeRolePolicy")), &assume); err != nil {
				t.Fatal(err)
			}
			json.Unmarshal([]byte(`{"Version":"2012-10-17","Statement":[{"Effect":"Allow","Principal":{"Service":"ecs-tasks.amazonaws.com"},"Action":"sts:AssumeRole"}]}`), &wantAssume)
			if !reflect.DeepEqual(assume, wantAssume) {
				t.Error("task execution trust changed")
			}
			policy := d5One(t, mocks, "aws:iam/rolePolicy:RolePolicy")
			d5WantString(t, policy.Inputs, "role", spec.name+"-workload-execution-mock-id")
			var policyJSON, wantPolicy map[string]interface{}
			if err := json.Unmarshal([]byte(d5String(t, policy.Inputs, "policy")), &policyJSON); err != nil {
				t.Fatal(err)
			}
			expectedPolicy := fmt.Sprintf(`{"Version":"2012-10-17","Statement":[{"Effect":"Allow","Action":["logs:CreateLogStream","logs:PutLogEvents"],"Resource":"fixture-reference-%s-workload-logs:*"}]}`, spec.name)
			json.Unmarshal([]byte(expectedPolicy), &wantPolicy)
			if !reflect.DeepEqual(policyJSON, wantPolicy) {
				t.Error("D5_RUNTIME_WIRING: log policy output wiring changed")
			}
			task := d5One(t, mocks, "aws:ecs/taskDefinition:TaskDefinition")
			d5WantString(t, task.Inputs, "family", spec.name+"-workload")
			d5WantString(t, task.Inputs, "cpu", "256")
			d5WantString(t, task.Inputs, "memory", "512")
			d5WantString(t, task.Inputs, "networkMode", "awsvpc")
			d5WantString(t, task.Inputs, "executionRoleArn", "fixture-reference-"+spec.name+"-workload-execution")
			if got := d5Strings(t, task.Inputs, "requiresCompatibilities"); !reflect.DeepEqual(got, []string{"FARGATE"}) {
				t.Errorf("runtime compatibility changed: %v", got)
			}
			var containers, wantContainers []map[string]interface{}
			if err := json.Unmarshal([]byte(d5String(t, task.Inputs, "containerDefinitions")), &containers); err != nil {
				t.Fatal(err)
			}
			expectedContainers := fmt.Sprintf(`[{"name":"api","image":"fixture.invalid/api@sha256:%s","essential":true,"portMappings":[{"containerPort":8080,"protocol":"tcp"}],"healthCheck":{"command":["CMD-SHELL","curl -f http://localhost:8080/health || exit 1"],"interval":30,"timeout":5,"retries":3},"logConfiguration":{"logDriver":"awslogs","options":{"awslogs-group":"%s-workload-logs","awslogs-region":"%s","awslogs-stream-prefix":"api"}}}]`, strings.Repeat("a", 64), spec.name, spec.region)
			if err := json.Unmarshal([]byte(expectedContainers), &wantContainers); err != nil {
				t.Fatal(err)
			}
			if !reflect.DeepEqual(containers, wantContainers) {
				t.Error("container runtime/image/health/log output wiring changed")
			}
			service := d5One(t, mocks, "aws:ecs/service:Service")
			d5WantNumber(t, service.Inputs, "desiredCount", float64(spec.capacity))
			d5WantString(t, service.Inputs, "cluster", "fixture-reference-"+spec.name+"-workload-cluster")
			d5WantString(t, service.Inputs, "taskDefinition", "fixture-reference-"+spec.name+"-workload-task")
			d5WantString(t, service.Inputs, "launchType", "FARGATE")
			network := d5Object(t, service.Inputs, "networkConfiguration")
			if got := d5Strings(t, network, "subnets"); !reflect.DeepEqual(got, spec.subnets) {
				t.Errorf("ECS subnet wiring: got %v, want %v", got, spec.subnets)
			}
			if got := d5Strings(t, network, "securityGroups"); !reflect.DeepEqual(got, []string{spec.name + "-workload-service-sg-mock-id"}) {
				t.Errorf("ECS SG output wiring: got %v", got)
			}
			d5WantBool(t, network, "assignPublicIp", true)
			dependsOnPolicy := false
			for _, dependency := range service.RegisterRPC.GetDependencies() {
				dependsOnPolicy = dependsOnPolicy || strings.HasSuffix(dependency, "::"+spec.name+"-workload-logs-policy")
			}
			if !dependsOnPolicy {
				t.Error("service log policy dependency missing")
			}
			mocks.mu.Lock()
			outputs := map[string]string{"bucketName": mocks.outputs["bucketName"], "serviceName": mocks.outputs["serviceName"]}
			mocks.mu.Unlock()
			expectedOutputs := map[string]string{"bucketName": bucket.Name + "-mock", "serviceName": spec.name + "-workload-service"}
			if !reflect.DeepEqual(outputs, expectedOutputs) {
				t.Errorf("workspace outputs: got %v, want %v", outputs, expectedOutputs)
			}
		})
	}
}
func TestHarnessD5UnknownImageRegistration(t *testing.T) {
	for _, spec := range d5Contracts() {
		t.Run(spec.name, func(t *testing.T) {
			args := d5Args(t, spec)
			args.Image = pulumi.UnsafeUnknownOutput(nil).ApplyT(func(value interface{}) string { return value.(string) }).(pulumi.StringOutput)
			mocks := &d5Mocks{outputs: map[string]string{}}
			err := pulumi.RunErr(func(ctx *pulumi.Context) error { _, err := New(ctx, spec.name, args); return err }, pulumi.WithMocks("daily-workspace", spec.name, mocks), func(info *pulumi.RunInfo) { info.DryRun = true })
			if err != nil {
				t.Fatal(err)
			}
			d5AssertInventory(t, spec, mocks)
			d5One(t, mocks, "aws:ecs/taskDefinition:TaskDefinition")
			d5One(t, mocks, "aws:ecs/service:Service")
		})
	}
}

const d5FrozenNonProdIdentity = `[
  {
    "Type": "aws:cloudwatch/logGroup:LogGroup",
    "Name": "nonprod-workload-logs",
    "Parent": "urn:pulumi:nonprod::daily-workspace::xbrain:workspace:Workspace$xbrain:workload:Workload::nonprod-workload",
    "Provider": "urn:pulumi:nonprod::daily-workspace::pulumi:providers:aws::nonprod-aws::nonprod-aws-mock-id"
  },
  {
    "Type": "aws:ec2/securityGroup:SecurityGroup",
    "Name": "nonprod-workload-service-sg",
    "Parent": "urn:pulumi:nonprod::daily-workspace::xbrain:workspace:Workspace$xbrain:workload:Workload::nonprod-workload",
    "Provider": "urn:pulumi:nonprod::daily-workspace::pulumi:providers:aws::nonprod-aws::nonprod-aws-mock-id"
  },
  {
    "Type": "aws:ecs/cluster:Cluster",
    "Name": "nonprod-workload-cluster",
    "Parent": "urn:pulumi:nonprod::daily-workspace::xbrain:workspace:Workspace$xbrain:workload:Workload::nonprod-workload",
    "Provider": "urn:pulumi:nonprod::daily-workspace::pulumi:providers:aws::nonprod-aws::nonprod-aws-mock-id"
  },
  {
    "Type": "aws:ecs/service:Service",
    "Name": "nonprod-workload-service",
    "Parent": "urn:pulumi:nonprod::daily-workspace::xbrain:workspace:Workspace$xbrain:workload:Workload::nonprod-workload",
    "Provider": "urn:pulumi:nonprod::daily-workspace::pulumi:providers:aws::nonprod-aws::nonprod-aws-mock-id"
  },
  {
    "Type": "aws:ecs/taskDefinition:TaskDefinition",
    "Name": "nonprod-workload-task",
    "Parent": "urn:pulumi:nonprod::daily-workspace::xbrain:workspace:Workspace$xbrain:workload:Workload::nonprod-workload",
    "Provider": "urn:pulumi:nonprod::daily-workspace::pulumi:providers:aws::nonprod-aws::nonprod-aws-mock-id"
  },
  {
    "Type": "aws:iam/role:Role",
    "Name": "nonprod-workload-execution",
    "Parent": "urn:pulumi:nonprod::daily-workspace::xbrain:workspace:Workspace$xbrain:workload:Workload::nonprod-workload",
    "Provider": "urn:pulumi:nonprod::daily-workspace::pulumi:providers:aws::nonprod-aws::nonprod-aws-mock-id"
  },
  {
    "Type": "aws:iam/rolePolicy:RolePolicy",
    "Name": "nonprod-workload-logs-policy",
    "Parent": "urn:pulumi:nonprod::daily-workspace::xbrain:workspace:Workspace$xbrain:workload:Workload::nonprod-workload",
    "Provider": "urn:pulumi:nonprod::daily-workspace::pulumi:providers:aws::nonprod-aws::nonprod-aws-mock-id"
  },
  {
    "Type": "aws:s3/bucket:Bucket",
    "Name": "nonprod-storage-uploads",
    "Parent": "urn:pulumi:nonprod::daily-workspace::xbrain:workspace:Workspace$xbrain:storage:Storage::nonprod-storage",
    "Provider": "urn:pulumi:nonprod::daily-workspace::pulumi:providers:aws::nonprod-aws::nonprod-aws-mock-id"
  },
  {
    "Type": "aws:s3/bucketPublicAccessBlock:BucketPublicAccessBlock",
    "Name": "nonprod-storage-uploads-access",
    "Parent": "urn:pulumi:nonprod::daily-workspace::xbrain:workspace:Workspace$xbrain:storage:Storage::nonprod-storage",
    "Provider": "urn:pulumi:nonprod::daily-workspace::pulumi:providers:aws::nonprod-aws::nonprod-aws-mock-id"
  },
  {
    "Type": "pulumi:providers:aws",
    "Name": "nonprod-aws",
    "Parent": "urn:pulumi:nonprod::daily-workspace::pulumi:pulumi:Stack::daily-workspace-nonprod",
    "Provider": ""
  },
  {
    "Type": "xbrain:storage:Storage",
    "Name": "nonprod-storage",
    "Parent": "urn:pulumi:nonprod::daily-workspace::xbrain:workspace:Workspace::nonprod",
    "Provider": ""
  },
  {
    "Type": "xbrain:workload:Workload",
    "Name": "nonprod-workload",
    "Parent": "urn:pulumi:nonprod::daily-workspace::xbrain:workspace:Workspace::nonprod",
    "Provider": ""
  },
  {
    "Type": "xbrain:workspace:Workspace",
    "Name": "nonprod",
    "Parent": "urn:pulumi:nonprod::daily-workspace::pulumi:pulumi:Stack::daily-workspace-nonprod",
    "Provider": ""
  }
]`

func TestHarnessD5PublicAPI(t *testing.T) {
	types := []struct {
		name  string
		value reflect.Type
	}{
		{name: "workspace.Args", value: reflect.TypeOf(Args{})},
		{name: "workload.Args", value: reflect.TypeOf(workload.Args{})},
	}
	for _, item := range types {
		t.Run(item.name, func(t *testing.T) {
			field, exists := item.value.FieldByName("ReplicaCount")
			if !exists || field.PkgPath != "" || field.Type.Kind() != reflect.Int {
				t.Error("public ReplicaCount int field is required")
			}
			if _, exists := item.value.FieldByName("DesiredCount"); exists {
				t.Error("legacy DesiredCount Go API must be removed")
			}
		})
	}
}

func d5URN(stack, project, token, name, parent string) string {
	if parent != "" {
		return parent[:strings.LastIndex(parent, "::")] + "$" + token + "::" + name
	}
	return "urn:pulumi:" + stack + "::" + project + "::" + token + "::" + name
}
func d5ValidURN(value string) bool {
	parts := strings.Split(value, "::")
	return len(parts) == 4 && strings.HasPrefix(parts[0], "urn:pulumi:") && len(strings.TrimPrefix(parts[0], "urn:pulumi:")) > 0 && parts[1] != "" && parts[2] != "" && parts[3] != ""
}
func d5AliasDeclarations(spec d5Contract, item pulumi.MockResourceArgs) (map[string]bool, []string) {
	result := map[string]bool{}
	qualified := []string{}
	rpc := item.RegisterRPC
	for _, value := range rpc.GetAliasURNs() {
		if d5ValidURN(value) {
			result[value] = true
		} else {
			qualified = append(qualified, "unrecognized legacy alias URN")
		}
	}
	for _, alias := range rpc.GetAliases() {
		if value := alias.GetUrn(); value != "" {
			if d5ValidURN(value) {
				result[value] = true
			} else {
				qualified = append(qualified, "unrecognized alias URN")
			}
			continue
		}
		old := alias.GetSpec()
		if old == nil || len(alias.ProtoReflect().GetUnknown()) != 0 || (old != nil && len(old.ProtoReflect().GetUnknown()) != 0) {
			qualified = append(qualified, "unrecognized alias representation requires source review")
			continue
		}
		name, token, stack, project, parent := item.Name, item.TypeToken, spec.name, "daily-workspace", rpc.GetParent()
		if old.GetName() != "" {
			name = old.GetName()
		}
		if old.GetType() != "" {
			token = old.GetType()
		}
		if old.GetStack() != "" {
			stack = old.GetStack()
		}
		if old.GetProject() != "" {
			project = old.GetProject()
		}
		switch previous := old.GetParent().(type) {
		case nil:
		case *pulumirpc.Alias_Spec_ParentUrn:
			parent = previous.ParentUrn
		case *pulumirpc.Alias_Spec_NoParent:
			if previous.NoParent {
				parent = ""
			}
		default:
			qualified = append(qualified, "unrecognized alias parent representation requires source review")
			continue
		}
		if parent != "" && !d5ValidURN(parent) {
			qualified = append(qualified, "unrecognized alias parent URN")
			continue
		}
		if stack != spec.name || project != "daily-workspace" {
			continue
		}
		result[d5URN(stack, project, token, name, parent)] = true
	}
	return result, qualified
}
func d5AssertAliasCoverage(t *testing.T, spec d5Contract, m *d5Mocks) {
	t.Helper()
	var old []d5Identity
	if err := json.Unmarshal([]byte(strings.ReplaceAll(d5FrozenNonProdIdentity, "nonprod", spec.name)), &old); err != nil {
		t.Fatal(err)
	}
	component := d5One(t, m, "xbrain:storage:Storage")
	componentURN := d5URN(spec.name, "daily-workspace", component.TypeToken, component.Name, component.RegisterRPC.GetParent())
	declaredParent, parentQualified := d5AliasDeclarations(spec, component)
	coverage := map[string]string{}
	missing := []string{}
	qualification := []string{}
	for _, expected := range old {
		if expected.Type != "xbrain:storage:Storage" && expected.Type != "aws:s3/bucket:Bucket" && expected.Type != "aws:s3/bucketPublicAccessBlock:BucketPublicAccessBlock" {
			continue
		}
		target := d5URN(spec.name, "daily-workspace", expected.Type, expected.Name, expected.Parent)
		current := d5One(t, m, expected.Type)
		declarations, unfamiliar := d5AliasDeclarations(spec, current)
		raw, _ := json.Marshal(current.RegisterRPC.GetAliases())
		t.Logf("D5_ALIAS_DECLARATIONS:%s/%s:%s", spec.name, expected.Type, raw)
		if declarations[target] {
			coverage[target] = "declared equivalent old identity"
			continue
		}
		if expected.Type != "xbrain:storage:Storage" && current.RegisterRPC.GetParent() == componentURN && strings.HasPrefix(current.Name, component.Name) {
			candidates := map[string]bool{d5URN(spec.name, "daily-workspace", current.TypeToken, current.Name, current.RegisterRPC.GetParent()): true}
			for candidate := range declarations {
				candidates[candidate] = true
			}
			for parentAlias := range declaredParent {
				parentParts := strings.Split(parentAlias, "::")
				for childAlias := range candidates {
					childParts := strings.Split(childAlias, "::")
					childName := childParts[3]
					childType := childParts[2][strings.LastIndex(childParts[2], "$")+1:]
					if strings.HasPrefix(childName, component.Name) {
						childName = parentParts[3] + childName[len(component.Name):]
					}
					candidate := d5URN(spec.name, "daily-workspace", childType, childName, parentAlias)
					if candidate == target {
						coverage[target] = "documented inherited component/child alias coverage"
						break
					}
				}
				if coverage[target] != "" {
					break
				}
			}
		}
		if coverage[target] != "" {
			continue
		}
		unfamiliar = append(unfamiliar, parentQualified...)
		if len(unfamiliar) > 0 {
			qualification = append(qualification, target+": "+strings.Join(unfamiliar, "; "))
		} else {
			missing = append(missing, target)
		}
	}
	encoded, _ := json.Marshal(coverage)
	t.Log("D5_OLD_IDENTITY_COVERAGE:" + string(encoded))
	for _, target := range missing {
		t.Errorf("D5_UNCOVERED_OLD_IDENTITY:%s", target)
	}
	if len(qualification) > 0 {
		t.Errorf("D5_ALIAS_REVIEW_QUALIFICATION: %s", strings.Join(qualification, " | "))
	}
}
func TestHarnessD5AliasCoverage(t *testing.T) {
	for _, spec := range d5Contracts() {
		for _, unknown := range []bool{false, true} {
			mode := "known-image"
			if unknown {
				mode = "unknown-image"
			}
			t.Run(spec.name+"/"+mode, func(t *testing.T) {
				args := d5Args(t, spec)
				if unknown {
					args.Image = pulumi.UnsafeUnknownOutput(nil).ApplyT(func(value interface{}) string { return value.(string) }).(pulumi.StringOutput)
				}
				mocks := &d5Mocks{outputs: map[string]string{}}
				err := pulumi.RunErr(func(ctx *pulumi.Context) error { _, err := New(ctx, spec.name, args); return err }, pulumi.WithMocks("daily-workspace", spec.name, mocks), func(info *pulumi.RunInfo) { info.DryRun = unknown })
				if err != nil {
					t.Fatal(err)
				}
				d5AssertInventory(t, spec, mocks)
				d5AssertAliasCoverage(t, spec, mocks)
			})
		}
	}
}

func TestHarnessD5EquivalentCombinedDeclarations(t *testing.T) {
	spec := d5Contracts()[0]
	stem := spec.name + "-object-store"
	workspaceURN := "urn:pulumi:" + spec.name + "::daily-workspace::xbrain:workspace:Workspace::" + spec.name
	componentURN := d5URN(spec.name, "daily-workspace", "xbrain:storage:Storage", stem, workspaceURN)
	for _, fullURN := range []bool{false, true} {
		t.Run(fmt.Sprintf("child-full-URN-%t", fullURN), func(t *testing.T) {
			child := &pulumirpc.Alias{Alias: &pulumirpc.Alias_Spec_{Spec: &pulumirpc.Alias_Spec{Name: stem + "-uploads"}}}
			if fullURN {
				child = &pulumirpc.Alias{Alias: &pulumirpc.Alias_Urn{Urn: d5URN(spec.name, "daily-workspace", "aws:s3/bucket:Bucket", stem+"-uploads", componentURN)}}
			}
			records := []pulumi.MockResourceArgs{
				{TypeToken: "xbrain:storage:Storage", Name: stem, RegisterRPC: &pulumirpc.RegisterResourceRequest{Parent: workspaceURN, Aliases: []*pulumirpc.Alias{{Alias: &pulumirpc.Alias_Spec_{Spec: &pulumirpc.Alias_Spec{Name: spec.name + "-storage"}}}}}},
				{TypeToken: "aws:s3/bucket:Bucket", Name: stem + "-uploads-v2", RegisterRPC: &pulumirpc.RegisterResourceRequest{Parent: componentURN, Aliases: []*pulumirpc.Alias{child}}},
				{TypeToken: "aws:s3/bucketPublicAccessBlock:BucketPublicAccessBlock", Name: stem + "-uploads-access", RegisterRPC: &pulumirpc.RegisterResourceRequest{Parent: componentURN}},
			}
			d5AssertAliasCoverage(t, spec, &d5Mocks{records: records})
		})
	}
}

func TestHarnessD5UnfamiliarAliasRequiresReview(t *testing.T) {
	const branch = "D5_CONTROLLER_UNKNOWN_ALIAS_BRANCH"
	if os.Getenv(branch) == "1" {
		spec := d5Contracts()[0]
		stem := spec.name + "-object-store"
		workspaceURN := "urn:pulumi:" + spec.name + "::daily-workspace::xbrain:workspace:Workspace::" + spec.name
		componentURN := d5URN(spec.name, "daily-workspace", "xbrain:storage:Storage", stem, workspaceURN)
		future := &pulumirpc.Alias{}
		future.ProtoReflect().SetUnknown([]byte{0x18, 0x01})
		records := []pulumi.MockResourceArgs{
			{TypeToken: "xbrain:storage:Storage", Name: stem, RegisterRPC: &pulumirpc.RegisterResourceRequest{Parent: workspaceURN, Aliases: []*pulumirpc.Alias{future}}},
			{TypeToken: "aws:s3/bucket:Bucket", Name: stem + "-uploads", RegisterRPC: &pulumirpc.RegisterResourceRequest{Parent: componentURN}},
			{TypeToken: "aws:s3/bucketPublicAccessBlock:BucketPublicAccessBlock", Name: stem + "-uploads-access", RegisterRPC: &pulumirpc.RegisterResourceRequest{Parent: componentURN}},
		}
		d5AssertAliasCoverage(t, spec, &d5Mocks{records: records})
		return
	}
	command := exec.Command(os.Args[0], "-test.v", "-test.run=^TestHarnessD5UnfamiliarAliasRequiresReview$")
	command.Env = append(os.Environ(), branch+"=1")
	output, err := command.CombinedOutput()
	failure, ok := err.(*exec.ExitError)
	if !ok || failure.ExitCode() != 1 {
		t.Fatalf("unproven coverage must fail the child test executable: err=%v output=%s", err, output)
	}
	text := string(output)
	if !strings.Contains(text, "D5_ALIAS_REVIEW_QUALIFICATION:") || strings.Contains(text, "D5_UNCOVERED_OLD_IDENTITY:") {
		t.Fatalf("child must request source review without asserting a confirmed coverage defect: %s", output)
	}
	t.Log("D5_QUALIFICATION_GUARD: child exit 1; explicit source-review classification observed")
}

// Input Args doc lap voi gia tri duoc implementation tao ra.
func d5SetOutbound(t *testing.T, args *Args, cidr string) {
	t.Helper()
	value := reflect.ValueOf(args).Elem()
	original := map[string]bool{"Environment": true, "Region": true, "StoragePrefix": true, "ReplicaCount": true, "LogRetentionDays": true, "Image": true, "VpcID": true, "SubnetIDs": true, "PeerCIDR": true}
	names := []string{}
	for i := 0; i < value.NumField(); i++ {
		field := value.Type().Field(i)
		lower := strings.ToLower(field.Name)
		if !original[field.Name] && field.IsExported() && (strings.Contains(lower, "outbound") || strings.Contains(lower, "egress") || strings.Contains(lower, "https")) {
			names = append(names, field.Name)
		}
	}
	if override := os.Getenv("D5_ARGS_FIELD"); override != "" {
		names = []string{override}
	}
	if len(names) == 0 {
		t.Fatal("D5_MISSING_TYPED_OUTBOUND_CONTRACT: workspace Args needs a concrete outbound CIDR input")
	}
	if len(names) != 1 {
		t.Fatalf("D5_SOURCE_REVIEW_QUALIFICATION: ambiguous new Args fields %v", names)
	}
	field := value.FieldByName(names[0])
	if !field.IsValid() || !field.CanSet() {
		t.Fatal("D5_SOURCE_REVIEW_QUALIFICATION: outbound Args field unavailable")
	}
	if field.Kind() == reflect.String {
		field.SetString(cidr)
		return
	}
	if field.Type() == reflect.TypeOf(netip.Prefix{}) {
		prefix, err := netip.ParsePrefix(cidr)
		if err != nil {
			t.Fatal(err)
		}
		field.Set(reflect.ValueOf(prefix))
		return
	}
	input := reflect.ValueOf(pulumi.String(cidr))
	if input.Type().AssignableTo(field.Type()) {
		field.Set(input)
		return
	}
	t.Fatalf("D5_SOURCE_REVIEW_QUALIFICATION: unsupported typed outbound Args representation %s", field.Type())
}

func d5AssertEgress(t *testing.T, spec d5Contract, group pulumi.MockResourceArgs, cidr string) {
	t.Helper()
	egress := d5Array(t, group.Inputs, "egress")
	if len(egress) != 1 || !egress[0].IsObject() {
		t.Fatal("D5_EGRESS_CONTRACT: exactly one scoped rule required")
	}
	rule := egress[0].ObjectValue()
	protocol, from, to, wantCIDR := "-1", float64(0), float64(0), "0.0.0.0/0"
	if spec.name == "uat" {
		protocol, from, to, wantCIDR = "tcp", 443, 443, cidr
	}
	got := d5String(t, rule, "protocol")
	if got != protocol && !(protocol == "tcp" && got == "6") {
		t.Errorf("D5_EGRESS_CONTRACT: protocol %s, want %s", got, protocol)
	}
	d5WantNumber(t, rule, "fromPort", from)
	d5WantNumber(t, rule, "toPort", to)
	values := d5Strings(t, rule, "cidrBlocks")
	if len(values) != 1 {
		t.Fatalf("D5_EGRESS_CONTRACT: destination count %v", values)
	}
	gotPrefix, gotErr := netip.ParsePrefix(values[0])
	wantPrefix, wantErr := netip.ParsePrefix(wantCIDR)
	if gotErr != nil || wantErr != nil || gotPrefix.Masked() != wantPrefix.Masked() {
		t.Errorf("D5_EGRESS_CONTRACT: got %v, want %s", values, wantCIDR)
	}
	for _, key := range []resource.PropertyKey{"ipv6CidrBlocks", "prefixListIds", "securityGroups"} {
		if value, ok := rule[key]; ok && value.IsArray() && len(value.ArrayValue()) != 0 {
			t.Errorf("D5_EGRESS_CONTRACT: unexpected additional destination %s", key)
		}
	}
	if value, ok := rule["self"]; ok && value.IsBool() && value.BoolValue() {
		t.Error("D5_EGRESS_CONTRACT: unexpected self destination")
	}
}

func TestHarnessD5OutboundTypedArgs(t *testing.T) {
	spec := d5Contracts()[1]
	for _, cidr := range []string{"10.42.0.0/24", "10.43.8.0/24"} {
		t.Run(cidr, func(t *testing.T) {
			args := d5Args(t, spec)
			d5SetOutbound(t, args, cidr)
			mocks := &d5Mocks{outputs: map[string]string{}}
			err := pulumi.RunErr(func(ctx *pulumi.Context) error { _, err := New(ctx, spec.name, args); return err }, pulumi.WithMocks("daily-workspace", spec.name, mocks))
			if err != nil {
				t.Fatal(err)
			}
			d5AssertInventory(t, spec, mocks)
			d5AssertAliasCoverage(t, spec, mocks)
			d5AssertEgress(t, spec, d5One(t, mocks, "aws:ec2/securityGroup:SecurityGroup"), cidr)
		})
	}
}
