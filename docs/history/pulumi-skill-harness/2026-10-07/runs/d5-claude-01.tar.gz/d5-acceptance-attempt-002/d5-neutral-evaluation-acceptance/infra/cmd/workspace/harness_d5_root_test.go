package main

import (
    "encoding/json"
    "fmt"
    "os"
    "reflect"
    "strings"
    "sync"
    "testing"

    "github.com/pulumi/pulumi/sdk/v3/go/common/resource"
    "github.com/pulumi/pulumi/sdk/v3/go/pulumi"
)

type d5RootMocks struct { mu sync.Mutex; records []pulumi.MockResourceArgs }
func (m *d5RootMocks) Call(args pulumi.MockCallArgs)(resource.PropertyMap,error){return nil,fmt.Errorf("D5_SHARED_OWNERSHIP: unexpected invoke %s",args.Token)}
func (m *d5RootMocks) NewResource(args pulumi.MockResourceArgs)(string,resource.PropertyMap,error){
    if args.TypeToken!="pulumi:pulumi:Stack" {m.mu.Lock();m.records=append(m.records,args);m.mu.Unlock()}
    output:=args.Inputs.Copy();output["name"]=resource.NewStringProperty(args.Name);output["arn"]=resource.NewStringProperty("fixture-reference-"+args.Name)
    if args.TypeToken=="aws:s3/bucket:Bucket"{output["bucket"]=resource.NewStringProperty(args.Name+"-mock")}
    return args.Name+"-mock-id",output,nil
}
var d5RootConfig map[string]string
var d5RootStack string
var d5RootRecorder *d5RootMocks
var d5RootErr error
var d5RootCalls int

// AST chi doi entrypoint trong ban sao evaluator; callback goc duoc thuc thi.
func d5InterceptRun(body pulumi.RunFunc,opts ...pulumi.RunOption){d5RootErr=d5InterceptRunErr(body,opts...)}
func d5InterceptRunErr(body pulumi.RunFunc,opts ...pulumi.RunOption)error{
    d5RootCalls++
    all:=append([]pulumi.RunOption{},opts...)
    all=append(all,pulumi.WithMocks("daily-workspace",d5RootStack,d5RootRecorder),func(info *pulumi.RunInfo){info.Config=d5RootConfig})
    return pulumi.RunErr(body,all...)
}
func d5RootCase(t *testing.T,target,cidr string,missing,invalid bool){
    t.Helper()
    d5RootConfig=map[string]string{
        "workspace:environment":target,"workspace:region":"ap-southeast-1","workspace:storagePrefix":"xbrain-"+target+"-uploads-",
        "workspace:desiredCount":"1","workspace:logRetentionDays":"7","workspace:image":"fixture.invalid/api@sha256:"+strings.Repeat("a",64),
        "workspace:vpcId":"fixture-vpc","workspace:subnetId":"fixture-subnet-a","workspace:subnetIds":"[\"fixture-subnet-a\"]","workspace:peerCidr":"10.30.0.0/16",
    }
    if extra:=os.Getenv("D5_EXTRA_ROOT_CONFIG");extra!="" {var values map[string]string;if err:=json.Unmarshal([]byte(extra),&values);err!=nil{t.Fatal(err)};for key,value:=range values{d5RootConfig[key]=value}}
    d5RootConfig["workspace:environment"]=target
    if target=="uat"{
        d5RootConfig["workspace:desiredCount"]="2";d5RootConfig["workspace:vpcId"]="fixture-vpc-uat"
        d5RootConfig["workspace:subnetId"]="fixture-subnet-uat-a";d5RootConfig["workspace:subnetIds"]="[\"fixture-subnet-uat-a\",\"fixture-subnet-uat-b\"]"
        if !missing{d5RootConfig["workspace:outboundHttpsCidr"]=cidr}else{delete(d5RootConfig,"workspace:outboundHttpsCidr")}
    }else{delete(d5RootConfig,"workspace:outboundHttpsCidr")}
    if target=="uat" {delete(d5RootConfig,"workspace:subnetId")} else {delete(d5RootConfig,"workspace:subnetIds")}
    d5RootRecorder=&d5RootMocks{};d5RootStack=target;d5RootErr=nil;d5RootCalls=0
    var recovered interface{}
    func(){defer func(){recovered=recover()}();main()}()
    records:=d5RootRecorder.records
    if target=="uat"&&(invalid||missing){
        if d5RootErr==nil&&recovered==nil{t.Errorf("D5_ROOT_REJECTION: missing/invalid CIDR accepted")}
        if len(records)!=0{t.Errorf("D5_ROOT_REJECTION: %d app registrations before rejection",len(records))}
        return
    }
    if recovered!=nil{t.Fatalf("D5_ROOT_VALID: panic %v",recovered)}
    if d5RootErr!=nil{t.Fatalf("D5_ROOT_VALID: %v",d5RootErr)}
    if d5RootCalls!=1{t.Fatalf("D5_SOURCE_REVIEW_QUALIFICATION: root interception calls %d",d5RootCalls)}
    if len(records)!=13{t.Errorf("D5_ROOT_INVENTORY: got %d, want thirteen",len(records))}
    var group,service *pulumi.MockResourceArgs
    for i:=range records{
        item:=&records[i]
        if item.ID!=""||item.ReadRPC!=nil||item.RegisterRPC.GetImportId()!=""{t.Errorf("D5_SHARED_OWNERSHIP: unexpected read/import")}
        switch item.TypeToken{
        case "aws:ec2/securityGroup:SecurityGroup":group=item
        case "aws:ecs/service:Service":service=item
        case "aws:ec2/vpc:Vpc","aws:ec2/subnet:Subnet","aws:ec2/route:Route","aws:ec2/routeTable:RouteTable","aws:ec2/vpcPeeringConnection:VpcPeeringConnection":t.Errorf("D5_SHARED_OWNERSHIP: %s",item.TypeToken)
        }
    }
    if group==nil||service==nil{t.Fatal("D5_ROOT_INVENTORY: missing group/service")}
    if group.Name!=target+"-workload-service-sg"{t.Errorf("D5_ROOT_TARGET: %s",group.Name)}
    egress:=group.Inputs["egress"]
    if !egress.IsArray()||len(egress.ArrayValue())!=1||!egress.ArrayValue()[0].IsObject(){t.Fatal("D5_ROOT_EGRESS: expected one rule")}
    rule:=egress.ArrayValue()[0].ObjectValue()
    protocol,port,want:="-1",float64(0),"0.0.0.0/0"
    if target=="uat"{protocol,port,want="tcp",443,cidr}
    if value:=rule["protocol"];!value.IsString()||(value.StringValue()!=protocol&&!(protocol=="tcp"&&value.StringValue()=="6")){t.Errorf("D5_ROOT_EGRESS: unexpected protocol")}
    for _,key:=range []resource.PropertyKey{"fromPort","toPort"}{if value:=rule[key];!value.IsNumber()||value.NumberValue()!=port{t.Errorf("D5_ROOT_EGRESS: %s",key)}}
    values:=rule["cidrBlocks"]
    if !values.IsArray()||len(values.ArrayValue())!=1||!values.ArrayValue()[0].IsString()||values.ArrayValue()[0].StringValue()!=want{t.Errorf("D5_ROOT_EGRESS: want %s, got %+v",want,values)}
    expectedCount:=float64(1);if target=="uat"{expectedCount=2}
    if value:=service.Inputs["desiredCount"];!value.IsNumber()||value.NumberValue()!=expectedCount{t.Errorf("D5_ROOT_PERSISTED_KEY: desiredCount input not consumed")}
    network:=service.Inputs["networkConfiguration"].ObjectValue()
    gotSubnets:=[]string{};for _,value:=range network["subnets"].ArrayValue(){gotSubnets=append(gotSubnets,value.StringValue())}
    expectedSubnets:=[]string{"fixture-subnet-a"};if target=="uat"{expectedSubnets=[]string{"fixture-subnet-uat-a","fixture-subnet-uat-b"}}
    if !reflect.DeepEqual(gotSubnets,expectedSubnets){t.Errorf("D5_ROOT_SUBNETS: got %v want %v",gotSubnets,expectedSubnets)}
}
func TestHarnessD5RootConfig(t *testing.T){
    t.Run("nonprod-no-new-key",func(t *testing.T){d5RootCase(t,"nonprod","",true,false)})
    t.Run("uat-approved",func(t *testing.T){d5RootCase(t,"uat","10.42.0.0/24",false,false)})
    t.Run("uat-consumes-root-input",func(t *testing.T){d5RootCase(t,"uat","10.43.8.0/24",false,false)})
    t.Run("uat-missing",func(t *testing.T){d5RootCase(t,"uat","",true,true)})
    for _,value:=range []string{"","not-a-cidr","10.42.0.0/99","0.0.0.0/0","2001:db8::/64"}{t.Run("uat-invalid-"+strings.ReplaceAll(value,"/","-"),func(t *testing.T){d5RootCase(t,"uat",value,false,true)})}
}
