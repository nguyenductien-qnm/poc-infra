package main

import (
	"fmt"
	"net"

	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi/config"
	"xbrain.local/daily/internal/workspace"
)

func main() {
	d5InterceptRun(run)
}

// run la composition root: doc config cua target, ghep workspace va export outputs hien co
func run(ctx *pulumi.Context) error {
	name, args, err := loadArgs(config.New(ctx, "workspace"))
	if err != nil {
		return err
	}
	result, err := workspace.New(ctx, name, args)
	if err != nil {
		return err
	}
	ctx.Export("bucketName", result.BucketName)
	ctx.Export("serviceName", result.ServiceName)
	return nil
}

// loadArgs tra ve logical workspace name va Args cho target.
// Logical name lay theo environment: nonprod giu identity "nonprod", uat dung "uat".
func loadArgs(cfg *config.Config) (string, *workspace.Args, error) {
	environment := cfg.Require("environment")
	subnets, err := subnetIDs(cfg)
	if err != nil {
		return "", nil, err
	}
	outbound, err := outboundHTTPSCIDR(cfg, environment)
	if err != nil {
		return "", nil, err
	}
	// ReplicaCount doc tu key persisted desiredCount de tuong thich stack hien co; khong doi ten key
	return environment, &workspace.Args{
		Environment:   environment,
		Region:        cfg.Require("region"),
		StoragePrefix: cfg.Require("storagePrefix"),
		ReplicaCount:  cfg.RequireInt("desiredCount"),
		Image:         pulumi.String(cfg.Require("image")),
		VpcID:         pulumi.String(cfg.Require("vpcId")),
		SubnetIDs:     pulumi.ToStringArray(subnets),
		PeerCIDR:      cfg.Require("peerCidr"),

		OutboundHTTPSCIDR: outbound,
	}, nil
}

// outboundHTTPSCIDR doc dich egress HTTPS (D5). UAT bat buoc co IPv4 CIDR dang network, khong phai /0;
// target khac khong duoc dat key nay de giu egress NonProd hien co.
func outboundHTTPSCIDR(cfg *config.Config, environment string) (string, error) {
	value := cfg.Get("outboundHttpsCidr")
	if environment != "uat" {
		if value != "" {
			return "", fmt.Errorf("workspace:outboundHttpsCidr is only supported for uat")
		}
		return "", nil
	}
	if value == "" {
		return "", fmt.Errorf("uat requires workspace:outboundHttpsCidr")
	}
	ip, network, err := net.ParseCIDR(value)
	if err != nil || ip.To4() == nil || !ip.Equal(network.IP) || network.String() != value {
		return "", fmt.Errorf("workspace:outboundHttpsCidr must be a canonical IPv4 CIDR")
	}
	if ones, _ := network.Mask.Size(); ones == 0 {
		return "", fmt.Errorf("workspace:outboundHttpsCidr must not be an all-networks CIDR")
	}
	return value, nil
}

// subnetIDs nhan list `subnetIds` (UAT) hoac key legacy `subnetId` (NonProd), khong cho phep ca hai
func subnetIDs(cfg *config.Config) ([]string, error) {
	legacy := cfg.Get("subnetId")
	var list []string
	hasList := cfg.Get("subnetIds") != ""
	if hasList {
		if err := cfg.TryObject("subnetIds", &list); err != nil {
			return nil, fmt.Errorf("workspace:subnetIds must be a list of subnet ids: %w", err)
		}
	}
	switch {
	case hasList && legacy != "":
		return nil, fmt.Errorf("set only one of workspace:subnetIds or legacy workspace:subnetId")
	case legacy != "":
		return []string{legacy}, nil
	case len(list) == 0:
		return nil, fmt.Errorf("workspace requires workspace:subnetIds (or legacy workspace:subnetId)")
	}
	for _, id := range list {
		if id == "" {
			return nil, fmt.Errorf("workspace:subnetIds must not contain empty ids")
		}
	}
	return list, nil
}
