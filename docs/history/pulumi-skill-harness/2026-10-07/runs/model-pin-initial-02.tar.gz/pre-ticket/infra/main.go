package main

// Native preflight verified.
func main() {}
