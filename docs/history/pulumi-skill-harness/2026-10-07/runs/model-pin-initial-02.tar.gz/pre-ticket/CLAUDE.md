Read AGENTS.md.
