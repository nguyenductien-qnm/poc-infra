package main

import (
	"strings"
	"testing"

	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
	"xbrain.local/daily/internal/testutil"
)

func TestLogRetentionConfig(t *testing.T) {
	for _, tc := range []struct {
		name        string
		environment string
		configured  string
		want        int
	}{
		{name: "nonprod omitted", environment: "nonprod", want: 7},
		{name: "nonprod zero", environment: "nonprod", configured: "0", want: 7},
		{name: "nonprod explicit", environment: "nonprod", configured: "7", want: 7},
		{name: "uat", environment: "uat", configured: "14", want: 14},
		{name: "future consumer 30 days", environment: "future", configured: "30", want: 30},
	} {
		t.Run(tc.name, func(t *testing.T) {
			values := map[string]string{
				"workspace:environment":   tc.environment,
				"workspace:region":        "ap-southeast-1",
				"workspace:storagePrefix": "xbrain-" + tc.environment + "-uploads-",
				"workspace:desiredCount":  "1",
				"workspace:image":         "fixture.invalid/api@sha256:" + strings.Repeat("a", 64),
				"workspace:vpcId":         "fixture-vpc",
				"workspace:subnetId":      "fixture-subnet-a",
				"workspace:peerCidr":      "10.30.0.0/16",
			}
			if tc.environment == "uat" {
				values["workspace:desiredCount"] = "2"
			}
			if tc.configured != "" {
				values["workspace:logRetentionDays"] = tc.configured
			}
			mocks := &testutil.Mocks{}
			if err := pulumi.RunErr(run, pulumi.WithMocks("daily-workspace", "nonprod", mocks),
				func(info *pulumi.RunInfo) { info.Config = values }); err != nil {
				t.Fatal(err)
			}
			count := 0
			for _, item := range mocks.Resources() {
				if item.TypeToken == "aws:cloudwatch/logGroup:LogGroup" {
					count++
					if got := item.Inputs["retentionInDays"].NumberValue(); got != float64(tc.want) {
						t.Errorf("retention from config = %v, want %d", got, tc.want)
					}
				}
			}
			if count != 1 {
				t.Errorf("log group count = %d, want 1", count)
			}
		})
	}
}
