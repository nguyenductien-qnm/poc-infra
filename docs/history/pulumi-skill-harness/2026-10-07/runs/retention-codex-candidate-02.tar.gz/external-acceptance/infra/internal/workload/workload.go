package workload

import (
	"encoding/json"
	"github.com/pulumi/pulumi-aws/sdk/v7/go/aws/cloudwatch"
	"github.com/pulumi/pulumi-aws/sdk/v7/go/aws/ec2"
	"github.com/pulumi/pulumi-aws/sdk/v7/go/aws/ecs"
	"github.com/pulumi/pulumi-aws/sdk/v7/go/aws/iam"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
)

type Args struct {
	Image            pulumi.StringInput
	VpcID            pulumi.StringInput
	SubnetIDs        pulumi.StringArrayInput
	PeerCIDR         string
	DesiredCount     int
	LogRetentionDays int
	Region           string
	Tags             pulumi.StringMapInput
}
type Workload struct {
	pulumi.ResourceState
	ServiceName pulumi.StringOutput
}

func New(ctx *pulumi.Context, name string, args *Args, opts ...pulumi.ResourceOption) (*Workload, error) {
	retentionDays := args.LogRetentionDays
	if retentionDays == 0 {
		retentionDays = 7
	}
	component := &Workload{}
	if err := ctx.RegisterComponentResource("xbrain:workload:Workload", name, component, opts...); err != nil {
		return nil, err
	}
	child := pulumi.Parent(component)
	logs, err := cloudwatch.NewLogGroup(ctx, name+"-logs", &cloudwatch.LogGroupArgs{
		RetentionInDays: pulumi.Int(retentionDays), Tags: args.Tags,
	}, child)
	if err != nil {
		return nil, err
	}
	role, err := iam.NewRole(ctx, name+"-execution", &iam.RoleArgs{
		AssumeRolePolicy: pulumi.String(`{"Version":"2012-10-17","Statement":[{"Effect":"Allow","Principal":{"Service":"ecs-tasks.amazonaws.com"},"Action":"sts:AssumeRole"}]}`),
		Tags:             args.Tags,
	}, child)
	if err != nil {
		return nil, err
	}
	policy := logs.Arn.ApplyT(func(logID string) (string, error) {
		data, err := json.Marshal(map[string]interface{}{
			"Version": "2012-10-17", "Statement": []interface{}{map[string]interface{}{
				"Effect": "Allow", "Action": []string{"logs:CreateLogStream", "logs:PutLogEvents"}, "Resource": logID + ":*",
			}},
		})
		return string(data), err
	}).(pulumi.StringOutput)
	logPolicy, err := iam.NewRolePolicy(ctx, name+"-logs-policy", &iam.RolePolicyArgs{Role: role.ID(), Policy: policy}, child)
	if err != nil {
		return nil, err
	}
	group, err := ec2.NewSecurityGroup(ctx, name+"-service-sg", &ec2.SecurityGroupArgs{
		VpcId: args.VpcID, Tags: args.Tags,
		Ingress: ec2.SecurityGroupIngressArray{ec2.SecurityGroupIngressArgs{
			Protocol: pulumi.String("tcp"), FromPort: pulumi.Int(8080), ToPort: pulumi.Int(8080),
			CidrBlocks: pulumi.StringArray{pulumi.String(args.PeerCIDR)},
		}},
		Egress: ec2.SecurityGroupEgressArray{ec2.SecurityGroupEgressArgs{
			Protocol: pulumi.String("-1"), FromPort: pulumi.Int(0), ToPort: pulumi.Int(0),
			CidrBlocks: pulumi.StringArray{pulumi.String("0.0.0.0/0")},
		}},
	}, child)
	if err != nil {
		return nil, err
	}
	cluster, err := ecs.NewCluster(ctx, name+"-cluster", &ecs.ClusterArgs{Tags: args.Tags}, child)
	if err != nil {
		return nil, err
	}
	definitions := pulumi.All(args.Image, logs.Name).ApplyT(func(values []interface{}) (string, error) {
		container := map[string]interface{}{
			"name": "api", "image": values[0], "essential": true,
			"portMappings":     []interface{}{map[string]interface{}{"containerPort": 8080, "protocol": "tcp"}},
			"healthCheck":      map[string]interface{}{"command": []string{"CMD-SHELL", "curl -f http://localhost:8080/health || exit 1"}, "interval": 30, "timeout": 5, "retries": 3},
			"logConfiguration": map[string]interface{}{"logDriver": "awslogs", "options": map[string]interface{}{"awslogs-group": values[1], "awslogs-region": args.Region, "awslogs-stream-prefix": "api"}},
		}
		data, err := json.Marshal([]interface{}{container})
		return string(data), err
	}).(pulumi.StringOutput)
	task, err := ecs.NewTaskDefinition(ctx, name+"-task", &ecs.TaskDefinitionArgs{
		Family: pulumi.String(name), Cpu: pulumi.String("256"), Memory: pulumi.String("512"),
		NetworkMode: pulumi.String("awsvpc"), RequiresCompatibilities: pulumi.StringArray{pulumi.String("FARGATE")},
		ExecutionRoleArn: role.Arn, ContainerDefinitions: definitions, Tags: args.Tags,
	}, child)
	if err != nil {
		return nil, err
	}
	service, err := ecs.NewService(ctx, name+"-service", &ecs.ServiceArgs{
		Cluster: cluster.Arn, TaskDefinition: task.Arn, DesiredCount: pulumi.Int(args.DesiredCount),
		LaunchType: pulumi.String("FARGATE"), Tags: args.Tags,
		NetworkConfiguration: &ecs.ServiceNetworkConfigurationArgs{
			Subnets: args.SubnetIDs, SecurityGroups: pulumi.StringArray{group.ID()}, AssignPublicIp: pulumi.Bool(true),
		},
	}, child, pulumi.DependsOn([]pulumi.Resource{logPolicy}))
	if err != nil {
		return nil, err
	}
	component.ServiceName = service.Name
	if err := ctx.RegisterResourceOutputs(component, pulumi.Map{"serviceName": component.ServiceName}); err != nil {
		return nil, err
	}
	return component, nil
}
