# xbrain daily infrastructure lab

Repo kế thừa cho ticket bảo trì Pulumi Go. Đây là fixture offline, chưa deploy.
`infra/cmd/workspace` đọc config; `infra/internal/workspace` ghép component;
storage và workload có owner riêng trong workspace, network được consume.

Đọc docs/DECISIONS.md và docs/CONTRACTS.md. Kiểm tra từ infra:
`gofmt -l .`, `go mod tidy -diff`, `go vet ./...`, `go build ./...`, `go test ./...`.
Mocks không chứng minh preview, cloud connectivity hoặc migration thành công.
App là module scope-control riêng, không phải image runtime và không build nó.

## Cấu hình log retention

Composition root `infra/cmd/workspace` đọc `workspace:logRetentionDays` rồi
truyền qua `workspace.Args.LogRetentionDays` và `workload.Args.LogRetentionDays`
đến CloudWatch LogGroup. Bỏ trống hoặc cấp `0` dùng mặc định **7 ngày**;
`0` ở capability này không có nghĩa là lưu log vô thời hạn.

| Consumer | Giá trị retention | Kết quả |
| --- | --- | --- |
| NonProd hiện tại | Bỏ trống, `0` hoặc `7` | 7 ngày |
| UAT | `14` | 14 ngày |
| Consumer tương lai | `30` | 30 ngày |

Consumer Go mới cấp số ngày qua `workspace.Args.LogRetentionDays`, cùng các
Args môi trường, prefix lưu trữ, capacity và network contract được cấp riêng.
Ví dụ UAT dùng environment `uat`, prefix `xbrain-uat-uploads-`, desired count `2`
và `LogRetentionDays: 14`; không cần thêm nhánh xử lý riêng theo môi trường.
Các giá trị khác phải thuộc tập retention được CloudWatch hỗ trợ.

UAT mới được kiểm tra bằng mocks, chưa onboard. Root hiện tại vẫn dùng logical
name `nonprod`; đổi config môi trường không tạo một workspace UAT riêng.
Thay đổi này giữ nguyên type token, logical names, parent/provider, ownership,
network và image contracts; không cần alias hay migration theo source hiện tại.
Tests kiểm tra cả đường truyền config và Args với 7/14/30 ngày. Chỉ chạy checks
local trong lab này; không thao tác config, state hoặc cloud.
