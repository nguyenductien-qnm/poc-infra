package workspace

import (
	"encoding/json"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
	"reflect"
	"strings"
	"testing"
	"xbrain.local/daily/internal/testutil"
)

func NonProdArgs() *Args {
	return &Args{Environment: "nonprod", Region: "ap-southeast-1", StoragePrefix: "xbrain-nonprod-uploads-", DesiredCount: 1,
		Image: pulumi.String("fixture.invalid/api@sha256:" + strings.Repeat("a", 64)),
		VpcID: pulumi.String("fixture-vpc"), SubnetIDs: pulumi.StringArray{pulumi.String("fixture-subnet-a")}, PeerCIDR: "10.30.0.0/16"}
}

func TestExistingNonProd(t *testing.T) {
	mocks := &testutil.Mocks{}
	err := pulumi.RunErr(func(ctx *pulumi.Context) error {
		result, err := New(ctx, "nonprod", NonProdArgs())
		if err != nil {
			return err
		}
		ctx.Export("bucketName", result.BucketName)
		ctx.Export("serviceName", result.ServiceName)
		return nil
	}, pulumi.WithMocks("daily-workspace", "nonprod", mocks))
	if err != nil {
		t.Fatal(err)
	}
	seenBucket, seenService := false, false
	for _, item := range mocks.Resources() {
		switch item.TypeToken {
		case "aws:s3/bucket:Bucket":
			seenBucket = true
			if item.Name != "nonprod-storage-uploads" || item.Inputs["bucketPrefix"].StringValue() != "xbrain-nonprod-uploads-" {
				t.Fatal("existing bucket contract changed")
			}
			if item.RegisterRPC.GetParent() == "" || item.Provider == "" {
				t.Fatal("bucket must have parent/provider")
			}
		case "aws:ecs/service:Service":
			seenService = true
			if item.Inputs["desiredCount"].NumberValue() != 1 {
				t.Fatal("existing capacity changed")
			}
			network := item.Inputs["networkConfiguration"].ObjectValue()
			if network["subnets"].ArrayValue()[0].StringValue() != "fixture-subnet-a" {
				t.Fatal("external subnet not consumed")
			}
		case "aws:ec2/vpc:Vpc", "aws:ec2/subnet:Subnet":
			t.Fatal("workspace must not own external network")
		}
	}
	if !seenBucket || !seenService {
		t.Fatal("missing existing resources")
	}
	assertWorkspaceContracts(t, mocks.Resources(), "nonprod", NonProdArgs(), 7)
}

func TestLogRetentionConsumers(t *testing.T) {
	for _, tc := range []struct {
		name        string
		environment string
		retention   int
		capacity    int
		want        int
	}{
		{name: "nonprod-zero", environment: "nonprod", retention: 0, capacity: 1, want: 7},
		{name: "nonprod-explicit", environment: "nonprod", retention: 7, capacity: 1, want: 7},
		{name: "uat", environment: "uat", retention: 14, capacity: 2, want: 14},
		{name: "future", environment: "future", retention: 30, capacity: 1, want: 30},
	} {
		t.Run(tc.name, func(t *testing.T) {
			args := NonProdArgs()
			args.Environment = tc.environment
			args.StoragePrefix = "xbrain-" + tc.environment + "-uploads-"
			args.DesiredCount = tc.capacity
			args.LogRetentionDays = tc.retention
			mocks := &testutil.Mocks{}
			if err := pulumi.RunErr(func(ctx *pulumi.Context) error {
				_, err := New(ctx, tc.environment, args)
				return err
			}, pulumi.WithMocks("daily-workspace", "nonprod", mocks)); err != nil {
				t.Fatal(err)
			}
			assertWorkspaceContracts(t, mocks.Resources(), tc.environment, args, tc.want)
		})
	}
}

func assertWorkspaceContracts(t *testing.T, resources []pulumi.MockResourceArgs, name string, args *Args, retention int) {
	t.Helper()
	root := "urn:pulumi:nonprod::daily-workspace::"
	stackURN := root + "pulumi:pulumi:Stack::daily-workspace-nonprod"
	workspaceURN := root + "xbrain:workspace:Workspace::" + name
	storageURN := root + "xbrain:workspace:Workspace$xbrain:storage:Storage::" + name + "-storage"
	workloadURN := root + "xbrain:workspace:Workspace$xbrain:workload:Workload::" + name + "-workload"
	provider := root + "pulumi:providers:aws::" + name + "-aws::" + name + "-aws-mock-id"
	expected := map[string]struct{ token, parent string }{
		name + "-aws":                    {"pulumi:providers:aws", stackURN},
		name:                             {"xbrain:workspace:Workspace", stackURN},
		name + "-storage":                {"xbrain:storage:Storage", workspaceURN},
		name + "-workload":               {"xbrain:workload:Workload", workspaceURN},
		name + "-storage-uploads":        {"aws:s3/bucket:Bucket", storageURN},
		name + "-storage-uploads-access": {"aws:s3/bucketPublicAccessBlock:BucketPublicAccessBlock", storageURN},
		name + "-workload-logs":          {"aws:cloudwatch/logGroup:LogGroup", workloadURN},
		name + "-workload-execution":     {"aws:iam/role:Role", workloadURN},
		name + "-workload-logs-policy":   {"aws:iam/rolePolicy:RolePolicy", workloadURN},
		name + "-workload-service-sg":    {"aws:ec2/securityGroup:SecurityGroup", workloadURN},
		name + "-workload-cluster":       {"aws:ecs/cluster:Cluster", workloadURN},
		name + "-workload-task":          {"aws:ecs/taskDefinition:TaskDefinition", workloadURN},
		name + "-workload-service":       {"aws:ecs/service:Service", workloadURN},
	}
	check := func(label string, got, want interface{}) {
		t.Helper()
		if !reflect.DeepEqual(got, want) {
			t.Errorf("%s changed: got %v, want %v", label, got, want)
		}
	}
	for _, item := range resources {
		want, ok := expected[item.Name]
		if !ok {
			t.Errorf("unexpected resource %s (%s)", item.Name, item.TypeToken)
			continue
		}
		delete(expected, item.Name)
		check(item.Name+" type", item.TypeToken, want.token)
		check(item.Name+" parent", item.RegisterRPC.GetParent(), want.parent)
		if strings.HasPrefix(item.TypeToken, "aws:") {
			check(item.Name+" provider", item.Provider, provider)
		}
		if strings.HasPrefix(item.TypeToken, "aws:") && item.TypeToken != "aws:iam/rolePolicy:RolePolicy" && item.TypeToken != "aws:s3/bucketPublicAccessBlock:BucketPublicAccessBlock" {
			check(item.Name+" environment tag", item.Inputs["tags"].ObjectValue()["Environment"].StringValue(), args.Environment)
			check(item.Name+" team tag", item.Inputs["tags"].ObjectValue()["Team"].StringValue(), "xbrain")
		}
		switch item.TypeToken {
		case "pulumi:providers:aws":
			check("provider region", item.Inputs["region"].StringValue(), args.Region)
		case "xbrain:workspace:Workspace":
			check("workspace provider map", item.RegisterRPC.GetProviders()["aws"], provider)
		case "aws:s3/bucket:Bucket":
			check("bucket prefix", item.Inputs["bucketPrefix"].StringValue(), args.StoragePrefix)
			if _, exists := item.Inputs["bucket"]; exists {
				t.Error("bucket must retain auto-naming")
			}
		case "aws:cloudwatch/logGroup:LogGroup":
			check("log retention", item.Inputs["retentionInDays"].NumberValue(), float64(retention))
		case "aws:iam/rolePolicy:RolePolicy":
			check("log policy role", item.Inputs["role"].StringValue(), name+"-workload-execution-mock-id")
			var policy map[string]interface{}
			if err := json.Unmarshal([]byte(item.Inputs["policy"].StringValue()), &policy); err != nil {
				t.Fatal(err)
			}
			statement := policy["Statement"].([]interface{})[0].(map[string]interface{})
			check("log policy resource output", statement["Resource"], "fixture-reference-"+name+"-workload-logs:*")
			check("log policy actions", statement["Action"], []interface{}{"logs:CreateLogStream", "logs:PutLogEvents"})
		case "aws:ec2/securityGroup:SecurityGroup":
			check("external VPC", item.Inputs["vpcId"].StringValue(), "fixture-vpc")
			ingress := item.Inputs["ingress"].ArrayValue()[0].ObjectValue()
			check("ingress port", ingress["fromPort"].NumberValue(), float64(8080))
			check("ingress end port", ingress["toPort"].NumberValue(), float64(8080))
			check("ingress protocol", ingress["protocol"].StringValue(), "tcp")
			check("peer CIDR", ingress["cidrBlocks"].ArrayValue()[0].StringValue(), args.PeerCIDR)
			egress := item.Inputs["egress"].ArrayValue()[0].ObjectValue()
			check("egress protocol", egress["protocol"].StringValue(), "-1")
			check("egress CIDR", egress["cidrBlocks"].ArrayValue()[0].StringValue(), "0.0.0.0/0")
		case "aws:ecs/taskDefinition:TaskDefinition":
			check("task CPU", item.Inputs["cpu"].StringValue(), "256")
			check("task memory", item.Inputs["memory"].StringValue(), "512")
			check("task network mode", item.Inputs["networkMode"].StringValue(), "awsvpc")
			check("task execution role output", item.Inputs["executionRoleArn"].StringValue(), "fixture-reference-"+name+"-workload-execution")
			var containers []struct {
				Image        string
				PortMappings []struct {
					ContainerPort int
					Protocol      string
				}
				HealthCheck      struct{ Command []string }
				LogConfiguration struct {
					LogDriver string
					Options   map[string]string
				}
			}
			if err := json.Unmarshal([]byte(item.Inputs["containerDefinitions"].StringValue()), &containers); err != nil {
				t.Fatal(err)
			}
			if len(containers) != 1 || len(containers[0].PortMappings) != 1 {
				t.Fatal("expected one API container with one port mapping")
			}
			container := containers[0]
			check("image contract", container.Image, "fixture.invalid/api@sha256:"+strings.Repeat("a", 64))
			check("container port", container.PortMappings[0].ContainerPort, 8080)
			check("container protocol", container.PortMappings[0].Protocol, "tcp")
			check("health contract", container.HealthCheck.Command, []string{"CMD-SHELL", "curl -f http://localhost:8080/health || exit 1"})
			check("log driver", container.LogConfiguration.LogDriver, "awslogs")
			check("log group output", container.LogConfiguration.Options["awslogs-group"], name+"-workload-logs")
			check("log region", container.LogConfiguration.Options["awslogs-region"], args.Region)
		case "aws:ecs/service:Service":
			check("service capacity", item.Inputs["desiredCount"].NumberValue(), float64(args.DesiredCount))
			check("service launch type", item.Inputs["launchType"].StringValue(), "FARGATE")
			network := item.Inputs["networkConfiguration"].ObjectValue()
			check("external subnet", network["subnets"].ArrayValue()[0].StringValue(), "fixture-subnet-a")
			check("service security group output", network["securityGroups"].ArrayValue()[0].StringValue(), name+"-workload-service-sg-mock-id")
			check("public IP", network["assignPublicIp"].BoolValue(), true)
		}
	}
	for missing := range expected {
		t.Errorf("missing resource %s", missing)
	}
}
