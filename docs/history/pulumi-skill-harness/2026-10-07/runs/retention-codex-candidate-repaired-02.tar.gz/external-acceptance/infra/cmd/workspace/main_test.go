package main

import (
	"strings"
	"testing"

	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
	"xbrain.local/daily/internal/testutil"
)

func TestRetentionConfig(t *testing.T) {
	for _, test := range []struct {
		name  string
		value string
		want  float64
	}{
		{name: "omitted", want: 7},
		{name: "zero", value: "0", want: 7},
		{name: "nonprod", value: "7", want: 7},
		{name: "uat", value: "14", want: 14},
		{name: "future-30-days", value: "30", want: 30},
	} {
		t.Run(test.name, func(t *testing.T) {
			cfg := map[string]string{
				"workspace:environment": "nonprod", "workspace:region": "ap-southeast-1",
				"workspace:storagePrefix": "xbrain-nonprod-uploads-", "workspace:desiredCount": "1",
				"workspace:image": "fixture.invalid/api@sha256:" + strings.Repeat("a", 64),
				"workspace:vpcId": "fixture-vpc", "workspace:subnetId": "fixture-subnet-a",
				"workspace:peerCidr": "10.30.0.0/16",
			}
			if test.value != "" {
				cfg["workspace:logRetentionDays"] = test.value
			}
			mocks := &testutil.Mocks{}
			if err := pulumi.RunErr(run, pulumi.WithMocks("daily-workspace", "nonprod", mocks), func(info *pulumi.RunInfo) {
				info.Config = cfg
			}); err != nil {
				t.Fatal(err)
			}
			count := 0
			for _, item := range mocks.Resources() {
				if item.TypeToken == "aws:cloudwatch/logGroup:LogGroup" {
					count++
					if item.Inputs["retentionInDays"].NumberValue() != test.want {
						t.Fatalf("config did not reach LogGroup: want retention %g", test.want)
					}
				}
			}
			if count != 1 {
				t.Fatalf("want one LogGroup, got %d", count)
			}
		})
	}
}
