package workspace

import (
	"encoding/json"
	"reflect"
	"testing"

	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
	"xbrain.local/daily/internal/testutil"
)

func TestRetentionConsumers(t *testing.T) {
	for _, test := range []struct {
		name        string
		environment string
		capacity    int
		retention   int
		want        float64
	}{
		{name: "nonprod-default", environment: "nonprod", capacity: 1, want: 7},
		{name: "nonprod-explicit", environment: "nonprod", capacity: 1, retention: 7, want: 7},
		{name: "uat", environment: "uat", capacity: 2, retention: 14, want: 14},
		{name: "future-30-days", environment: "future", capacity: 1, retention: 30, want: 30},
	} {
		t.Run(test.name, func(t *testing.T) {
			args := NonProdArgs()
			args.Environment = test.environment
			args.StoragePrefix = "xbrain-" + test.environment + "-uploads-"
			args.DesiredCount = test.capacity
			args.LogRetentionDays = test.retention
			mocks := &testutil.Mocks{}
			if err := pulumi.RunErr(func(ctx *pulumi.Context) error {
				_, err := New(ctx, test.environment, args)
				return err
			}, pulumi.WithMocks("daily-workspace", test.environment, mocks)); err != nil {
				t.Fatal(err)
			}
			assertWorkspaceContract(t, mocks.Resources(), args, test.want)
		})
	}
}

func assertWorkspaceContract(t *testing.T, resources []pulumi.MockResourceArgs, args *Args, retention float64) {
	t.Helper()
	name := args.Environment
	urnPrefix := "urn:pulumi:" + name + "::daily-workspace::"
	stackParent := urnPrefix + "pulumi:pulumi:Stack::daily-workspace-" + name
	workspaceParent := urnPrefix + "xbrain:workspace:Workspace::" + name
	storageParent := urnPrefix + "xbrain:workspace:Workspace$xbrain:storage:Storage::" + name + "-storage"
	workloadParent := urnPrefix + "xbrain:workspace:Workspace$xbrain:workload:Workload::" + name + "-workload"
	provider := urnPrefix + "pulumi:providers:aws::" + name + "-aws::" + name + "-aws-mock-id"
	expected := map[string]struct{ token, parent string }{
		name + "-aws":                    {"pulumi:providers:aws", stackParent},
		name:                             {"xbrain:workspace:Workspace", stackParent},
		name + "-storage":                {"xbrain:storage:Storage", workspaceParent},
		name + "-storage-uploads":        {"aws:s3/bucket:Bucket", storageParent},
		name + "-storage-uploads-access": {"aws:s3/bucketPublicAccessBlock:BucketPublicAccessBlock", storageParent},
		name + "-workload":               {"xbrain:workload:Workload", workspaceParent},
		name + "-workload-logs":          {"aws:cloudwatch/logGroup:LogGroup", workloadParent},
		name + "-workload-execution":     {"aws:iam/role:Role", workloadParent},
		name + "-workload-logs-policy":   {"aws:iam/rolePolicy:RolePolicy", workloadParent},
		name + "-workload-service-sg":    {"aws:ec2/securityGroup:SecurityGroup", workloadParent},
		name + "-workload-cluster":       {"aws:ecs/cluster:Cluster", workloadParent},
		name + "-workload-task":          {"aws:ecs/taskDefinition:TaskDefinition", workloadParent},
		name + "-workload-service":       {"aws:ecs/service:Service", workloadParent},
	}
	for _, item := range resources {
		if item.TypeToken == "pulumi:pulumi:Stack" {
			continue
		}
		identity, ok := expected[item.Name]
		if !ok || item.TypeToken != identity.token || item.RegisterRPC.GetParent() != identity.parent {
			t.Fatalf("resource identity or ownership changed for %s: type %s, parent %s (want %s)", item.Name, item.TypeToken, item.RegisterRPC.GetParent(), identity.parent)
		}
		delete(expected, item.Name)
		if item.Custom && item.TypeToken != "pulumi:providers:aws" && item.Provider != provider {
			t.Fatal("child must inherit the workspace provider")
		}
		inputs := item.Inputs
		if tags, ok := inputs["tags"]; ok {
			if tags.ObjectValue()["Team"].StringValue() != "xbrain" || tags.ObjectValue()["Environment"].StringValue() != name {
				t.Fatal("consumer tags changed")
			}
		}
		switch item.TypeToken {
		case "pulumi:providers:aws":
			if inputs["region"].StringValue() != args.Region {
				t.Fatal("provider region changed")
			}
		case "aws:s3/bucket:Bucket":
			if inputs["bucketPrefix"].StringValue() != args.StoragePrefix {
				t.Fatal("storage prefix changed")
			}
			if _, fixed := inputs["bucket"]; fixed {
				t.Fatal("bucket must retain auto-naming")
			}
		case "aws:cloudwatch/logGroup:LogGroup":
			if inputs["retentionInDays"].NumberValue() != retention {
				t.Fatalf("want retention %g days", retention)
			}
		case "aws:iam/rolePolicy:RolePolicy":
			var policy struct {
				Statement []struct {
					Action   []string
					Resource string
				}
			}
			if err := json.Unmarshal([]byte(inputs["policy"].StringValue()), &policy); err != nil {
				t.Fatal(err)
			}
			if len(policy.Statement) != 1 || policy.Statement[0].Resource != "fixture-reference-"+name+"-workload-logs:*" ||
				!reflect.DeepEqual(policy.Statement[0].Action, []string{"logs:CreateLogStream", "logs:PutLogEvents"}) ||
				inputs["role"].StringValue() != name+"-workload-execution-mock-id" {
				t.Fatal("log policy must consume the owned LogGroup and role outputs")
			}
		case "aws:ec2/securityGroup:SecurityGroup":
			ingress := inputs["ingress"].ArrayValue()[0].ObjectValue()
			if inputs["vpcId"].StringValue() != "fixture-vpc" || ingress["protocol"].StringValue() != "tcp" ||
				ingress["fromPort"].NumberValue() != 8080 || ingress["toPort"].NumberValue() != 8080 ||
				ingress["cidrBlocks"].ArrayValue()[0].StringValue() != args.PeerCIDR {
				t.Fatal("external network or ingress contract changed")
			}
		case "aws:ecs/taskDefinition:TaskDefinition":
			var definitions []struct {
				Image            string
				PortMappings     []struct{ ContainerPort int }
				HealthCheck      struct{ Command []string }
				LogConfiguration struct {
					LogDriver string
					Options   map[string]string
				}
			}
			if err := json.Unmarshal([]byte(inputs["containerDefinitions"].StringValue()), &definitions); err != nil {
				t.Fatal(err)
			}
			if len(definitions) != 1 {
				t.Fatal("container contract changed")
			}
			container := definitions[0]
			if container.Image != string(args.Image.(pulumi.String)) || len(container.PortMappings) != 1 ||
				container.PortMappings[0].ContainerPort != 8080 ||
				!reflect.DeepEqual(container.HealthCheck.Command, []string{"CMD-SHELL", "curl -f http://localhost:8080/health || exit 1"}) ||
				container.LogConfiguration.LogDriver != "awslogs" ||
				container.LogConfiguration.Options["awslogs-group"] != name+"-workload-logs" ||
				container.LogConfiguration.Options["awslogs-region"] != args.Region ||
				inputs["cpu"].StringValue() != "256" || inputs["memory"].StringValue() != "512" ||
				inputs["networkMode"].StringValue() != "awsvpc" ||
				inputs["requiresCompatibilities"].ArrayValue()[0].StringValue() != "FARGATE" ||
				inputs["executionRoleArn"].StringValue() != "fixture-reference-"+name+"-workload-execution" {
				t.Fatal("image, runtime or log output contract changed")
			}
		case "aws:ecs/service:Service":
			network := inputs["networkConfiguration"].ObjectValue()
			if inputs["desiredCount"].NumberValue() != float64(args.DesiredCount) ||
				inputs["launchType"].StringValue() != "FARGATE" ||
				inputs["cluster"].StringValue() != "fixture-reference-"+name+"-workload-cluster" ||
				inputs["taskDefinition"].StringValue() != "fixture-reference-"+name+"-workload-task" ||
				len(network["subnets"].ArrayValue()) != 1 || network["subnets"].ArrayValue()[0].StringValue() != "fixture-subnet-a" ||
				len(network["securityGroups"].ArrayValue()) != 1 || network["securityGroups"].ArrayValue()[0].StringValue() != name+"-workload-service-sg-mock-id" ||
				!network["assignPublicIp"].BoolValue() {
				t.Fatal("capacity or service network contract changed")
			}
		}
	}
	if len(expected) != 0 {
		t.Fatal("missing workspace resources")
	}
}
