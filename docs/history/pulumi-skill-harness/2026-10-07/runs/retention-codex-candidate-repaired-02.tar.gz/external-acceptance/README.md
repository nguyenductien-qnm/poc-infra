# xbrain daily infrastructure lab

Repo kế thừa cho ticket bảo trì Pulumi Go. Đây là fixture offline, chưa deploy.
`infra/cmd/workspace` đọc config; `infra/internal/workspace` ghép component;
storage và workload có owner riêng trong workspace, network được consume.

Retention được cấp ở composition root qua `workspace:logRetentionDays` (số
ngày), truyền bằng `workspace.Args.LogRetentionDays` tới
`workload.Args.LogRetentionDays` và `LogGroup.retentionInDays`. Bỏ trống hoặc
cấp `0` giữ mặc định **7 ngày**; `0` không có nghĩa là lưu vô thời hạn trong
capability này. NonProd dùng 7 ngày, UAT cấp 14 ngày. Consumer tương lai có
thể cấp 30 ngày qua cùng trường Args, không cần thêm nhánh theo môi trường.
Giá trị khác 0 phải là số ngày được CloudWatch hỗ trợ theo SDK đang ghim.

Ví dụ dữ liệu cấu hình cho một lần onboard được cấp phép sau này:

```yaml
config:
  workspace:logRetentionDays: 14
```

Đây chỉ là ví dụ cho retention; UAT chưa được onboard. Consumer mới còn cần
environment, storage prefix, capacity, network và image theo contract.
Root hiện tại vẫn dùng logical name `nonprod`; không đổi tên root hiện có
để chuyển môi trường. Khi ghép consumer mới trực tiếp bằng Go, cấp
`LogRetentionDays: 14` hoặc `LogRetentionDays: 30` trong `workspace.Args`
cùng tên và các input riêng của consumer đó.

Consumer tương lai cấp 30 ngày tại composition root bằng dữ liệu cấu hình:

```yaml
config:
  workspace:logRetentionDays: 30
```

Root đọc số nguyên này và truyền qua `workspace.Args.LogRetentionDays`, rồi
`workload.Args.LogRetentionDays`; LogGroup nhận `retentionInDays: 30`.
Consumer ghép trực tiếp bằng Go đặt `args.LogRetentionDays = 30` trước khi
gọi `workspace.New(ctx, consumerName, args)`, với `args` chứa đầy đủ input
riêng của consumer. Không cần sửa workload hay thêm nhánh cho môi trường mới.
Case `future-30-days` kiểm tra cả đường config và đường Args, đồng thời giữ
các kiểm tra identity, parent/provider và contracts của consumer.

Thay đổi retention chỉ cập nhật input của LogGroup hiện có; giữ type token,
logical name, ownership, parent và provider. Theo source không cần alias hay
migration, không dự kiến replacement/deletion; chưa có preview để xác nhận.
Regression mocks kiểm tra mặc định, 0, 7, 14, 30 ngày từ config tới LogGroup,
các consumer Go và các contract identity/provider, storage, network, image,
capacity và policy ghi log từ Output.

Đọc docs/DECISIONS.md và docs/CONTRACTS.md. Kiểm tra từ infra:
`gofmt -l .`, `go mod tidy -diff`, `go vet ./...`, `go build ./...`, `go test ./...`.
Mocks không chứng minh preview, cloud connectivity hoặc migration thành công.
App là module scope-control riêng, không phải image runtime và không build nó.
