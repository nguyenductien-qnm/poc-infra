# xbrain daily infrastructure lab

Repo kế thừa cho ticket bảo trì Pulumi Go. Đây là fixture offline, chưa deploy.
`infra/cmd/workspace` đọc config; `infra/internal/workspace` ghép component;
storage và workload có owner riêng trong workspace, network được consume.

Đọc docs/DECISIONS.md và docs/CONTRACTS.md. Kiểm tra từ infra:
`gofmt -l .`, `go mod tidy -diff`, `go vet ./...`, `go build ./...`, `go test ./...`.
Mocks không chứng minh preview, cloud connectivity hoặc migration thành công.

## Log retention

Mọi consumer cấp retention qua cùng một capability: config
`workspace:logRetentionDays` tại composition root, truyền qua
`workspace.Args.LogRetentionDays` rồi `workload.Args.LogRetentionDays` tới
LogGroup `<workspace>-workload-logs`. Không cấp hoặc 0 giữ mặc định 7 ngày của
NonProd. UAT theo contract cấp `14`; consumer tương lai có thể cấp ví dụ `30`.
Giá trị âm hoặc không thuộc danh sách retention của CloudWatch Logs (1, 3, 5,
7, 14, 30, 60, 90, ...) bị từ chối trước khi đăng ký resource. Đổi retention
chỉ cập nhật thuộc tính LogGroup, không đổi logical name, parent hay provider.
App là module scope-control riêng, không phải image runtime và không build nó.
