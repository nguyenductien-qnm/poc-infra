package workspace

import (
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
	"strings"
	"testing"
	"xbrain.local/daily/internal/testutil"
)

func NonProdArgs() *Args {
	return &Args{Environment: "nonprod", Region: "ap-southeast-1", StoragePrefix: "xbrain-nonprod-uploads-", DesiredCount: 1,
		Image: pulumi.String("fixture.invalid/api@sha256:" + strings.Repeat("a", 64)),
		VpcID: pulumi.String("fixture-vpc"), SubnetIDs: pulumi.StringArray{pulumi.String("fixture-subnet-a")}, PeerCIDR: "10.30.0.0/16"}
}

// UATArgs la cau hinh thu hai hop le theo contract, chua onboard.
func UATArgs() *Args {
	args := NonProdArgs()
	args.Environment, args.StoragePrefix, args.DesiredCount, args.LogRetentionDays = "uat", "xbrain-uat-uploads-", 2, 14
	return args
}

func runWorkspace(t *testing.T, name string, args *Args) []pulumi.MockResourceArgs {
	t.Helper()
	mocks := &testutil.Mocks{}
	err := pulumi.RunErr(func(ctx *pulumi.Context) error {
		result, err := New(ctx, name, args)
		if err != nil {
			return err
		}
		ctx.Export("bucketName", result.BucketName)
		ctx.Export("serviceName", result.ServiceName)
		return nil
	}, pulumi.WithMocks("daily-workspace", name, mocks))
	if err != nil {
		t.Fatal(err)
	}
	return mocks.Resources()
}

func findResource(t *testing.T, resources []pulumi.MockResourceArgs, typeToken string) pulumi.MockResourceArgs {
	t.Helper()
	var found []pulumi.MockResourceArgs
	for _, item := range resources {
		if item.TypeToken == typeToken {
			found = append(found, item)
		}
	}
	if len(found) != 1 {
		t.Fatalf("expected exactly one %s, got %d", typeToken, len(found))
	}
	return found[0]
}

// assertLogGroup kiem tra retention va giu nguyen identity/parent/provider cua log group.
func assertLogGroup(t *testing.T, resources []pulumi.MockResourceArgs, name string, days float64) {
	t.Helper()
	logs := findResource(t, resources, "aws:cloudwatch/logGroup:LogGroup")
	if logs.Name != name+"-workload-logs" {
		t.Fatalf("log group logical name changed: %s", logs.Name)
	}
	if got := logs.Inputs["retentionInDays"].NumberValue(); got != days {
		t.Fatalf("log retention = %v, want %v", got, days)
	}
	workload := findResource(t, resources, "xbrain:workload:Workload")
	if workload.Name != name+"-workload" || !strings.HasSuffix(logs.RegisterRPC.GetParent(), "::"+workload.Name) {
		t.Fatalf("log group must stay parented to %s-workload, got %s", name, logs.RegisterRPC.GetParent())
	}
	if logs.Provider == "" || !strings.Contains(logs.Provider, "::"+name+"-aws::") {
		t.Fatalf("log group must inherit workspace provider, got %q", logs.Provider)
	}
	if logs.Inputs["tags"].ObjectValue()["Environment"].StringValue() != name {
		t.Fatal("log group environment tag changed")
	}
	policy := findResource(t, resources, "aws:iam/rolePolicy:RolePolicy")
	if !strings.Contains(policy.Inputs["policy"].StringValue(), "fixture-reference-"+logs.Name+":*") {
		t.Fatal("execution role policy must be derived from the log group output")
	}
}

func TestExistingNonProd(t *testing.T) {
	resources := runWorkspace(t, "nonprod", NonProdArgs())
	seenBucket, seenService := false, false
	for _, item := range resources {
		switch item.TypeToken {
		case "aws:s3/bucket:Bucket":
			seenBucket = true
			if item.Name != "nonprod-storage-uploads" || item.Inputs["bucketPrefix"].StringValue() != "xbrain-nonprod-uploads-" {
				t.Fatal("existing bucket contract changed")
			}
			if item.RegisterRPC.GetParent() == "" || item.Provider == "" {
				t.Fatal("bucket must have parent/provider")
			}
		case "aws:ecs/service:Service":
			seenService = true
			if item.Inputs["desiredCount"].NumberValue() != 1 {
				t.Fatal("existing capacity changed")
			}
			network := item.Inputs["networkConfiguration"].ObjectValue()
			if network["subnets"].ArrayValue()[0].StringValue() != "fixture-subnet-a" {
				t.Fatal("external subnet not consumed")
			}
		case "aws:ec2/vpc:Vpc", "aws:ec2/subnet:Subnet":
			t.Fatal("workspace must not own external network")
		}
	}
	if !seenBucket || !seenService {
		t.Fatal("missing existing resources")
	}
	findResource(t, resources, "xbrain:workspace:Workspace")
	// khong cap retention thi NonProd giu 7 ngay
	assertLogGroup(t, resources, "nonprod", 7)
}

func TestNonProdExplicitSevenDays(t *testing.T) {
	args := NonProdArgs()
	args.LogRetentionDays = 7
	assertLogGroup(t, runWorkspace(t, "nonprod", args), "nonprod", 7)
}

func TestUATRetention(t *testing.T) {
	resources := runWorkspace(t, "uat", UATArgs())
	assertLogGroup(t, resources, "uat", 14)
	bucket := findResource(t, resources, "aws:s3/bucket:Bucket")
	if bucket.Name != "uat-storage-uploads" || bucket.Inputs["bucketPrefix"].StringValue() != "xbrain-uat-uploads-" {
		t.Fatal("uat storage contract not applied")
	}
	service := findResource(t, resources, "aws:ecs/service:Service")
	if service.Inputs["desiredCount"].NumberValue() != 2 {
		t.Fatal("uat capacity not applied")
	}
	group := findResource(t, resources, "aws:ec2/securityGroup:SecurityGroup")
	if group.Inputs["vpcId"].StringValue() != "fixture-vpc" {
		t.Fatal("uat must consume the supplied network contract")
	}
}

func TestFutureConsumerRetention(t *testing.T) {
	args := NonProdArgs()
	args.LogRetentionDays = 30
	assertLogGroup(t, runWorkspace(t, "nonprod", args), "nonprod", 30)
}

func TestInvalidRetentionRejected(t *testing.T) {
	for _, days := range []int{-1, 2, 10, 4000} {
		args := NonProdArgs()
		args.LogRetentionDays = days
		mocks := &testutil.Mocks{}
		err := pulumi.RunErr(func(ctx *pulumi.Context) error {
			_, err := New(ctx, "nonprod", args)
			return err
		}, pulumi.WithMocks("daily-workspace", "nonprod", mocks))
		if err == nil || !strings.Contains(err.Error(), "log retention") {
			t.Fatalf("retention %d must be rejected, got %v", days, err)
		}
		for _, item := range mocks.Resources() {
			if item.TypeToken == "aws:cloudwatch/logGroup:LogGroup" {
				t.Fatalf("retention %d must not register a log group", days)
			}
		}
	}
}
