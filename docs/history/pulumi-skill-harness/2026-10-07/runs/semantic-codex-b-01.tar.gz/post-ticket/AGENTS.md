# Infrastructure review

Use `.agents/skills/pulumi/SKILL.md` for this documentation-only Pulumi Go verification. Follow docs/DECISIONS.md. The only authorized persistent edit is the pre-existing docs/REVIEW.md. Temporary helpers and outputs may be created only inside `.harness-scratch/` in this repository. Source, tests, module files and runtime setup are read-only. Do not commit, run cloud/state/config/auth writes, deploy, fetch secret values, access sibling repositories, upgrade dependencies or launch native CLIs. Keep the review guide in accented Vietnamese.
