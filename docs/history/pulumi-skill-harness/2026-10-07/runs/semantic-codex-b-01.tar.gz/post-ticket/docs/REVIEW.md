# Rà soát archive

**Kết luận: `pass` trong phạm vi rà soát tài liệu và bằng chứng mock.** Đã tự rà soát bốn nhận định theo `docs/DECISIONS.md`: sửa hai nhận định vượt quá bằng chứng (`NewLate`, `TestSelectedParents`), giữ hai bảo đảm có căn cứ (`NewEarly`, `TestCompleteFrozenParents`). Kết luận này không xác nhận triển khai cloud hoặc kế hoạch preview.

## Đối chiếu bốn nhận định

1. **`NewLate`: sửa nhận định không có đăng ký.** `NewLate` gọi `prepare` trước `newAudit` (`infra/archive/archive.go:29–39`). `prepare` khai báo provider, component, bucket và PublicAccessBlock (`archive.go:50–70`); đến `newAudit` mới kiểm tra `KeepDays` và từ chối 0 trước khi khai báo LogGroup (`archive.go:73–77`). `TestLateRejectedInput` khẳng định lỗi chứa `KeepDays must be positive` và danh mục đúng bốn type nói trên (`infra/archive/archive_test.go:61–73`); log baseline cũng ghi bốn request. Vì vậy, lỗi này không bảo đảm không có yêu cầu đăng ký. Nếu cần từ chối trước đăng ký, dùng điểm vào `NewEarly`.

2. **`NewEarly`: giữ bảo đảm từ chối trước đăng ký ứng dụng.** Kiểm tra diễn ra ngay tại điểm vào, trước lời gọi `NewLate` (`infra/archive/archive.go:43–47`); `validate` từ chối mọi giá trị nhỏ hơn 1 (`archive.go:21–25`). Với trường hợp được kiểm thử `KeepDays=0`, `TestEarlyRejectedInput` kiểm tra cả lỗi và `len(records)==0` (`infra/archive/archive_test.go:76–83`), baseline ghi `[]`. Phạm vi này loại Stack ngầm của SDK theo bộ ghi mock (`archive_test.go:29–36`); test chưa bao phủ các giá trị âm.

3. **`TestSelectedParents`: sửa phạm vi kiểm tra parent.** Test chạy `NewEarly` với 7 ngày, kiểm tra tổng số request là 5, nhưng chỉ kiểm tra parent của bucket và LogGroup, cùng số phần tử được kiểm tra là 2 (`infra/archive/archive_test.go:89–108`). Parent của PublicAccessBlock, provider hoặc component sai vẫn có thể qua riêng test này. Source khai báo parent của bucket/LogGroup tại `infra/archive/archive.go:59,77`; log đủ năm request không mở rộng phạm vi assertions của test.

4. **`TestCompleteFrozenParents`: giữ bảo đảm so sánh đủ danh mục.** Với `NewEarly(KeepDays=7)`, test dùng `reflect.DeepEqual` so sánh toàn bộ bộ ba type/name/parent của năm request với danh mục cố định độc lập (`infra/archive/archive_test.go:111–126`). Bucket, PublicAccessBlock và LogGroup có parent là component archive; provider và component có parent là Stack (`archive_test.go:86–87,117–123`). Source đặt parent cho ba tài nguyên con và không truyền parent riêng cho provider/component (`infra/archive/archive.go:50–66,77`). Đây là kiểm chứng đầy đủ danh mục đăng ký trong ca mock này.

## Kết quả kiểm tra và nguồn bằng chứng

Baseline là kết quả chạy cục bộ thực tế, thu lúc `2026-10-06T18:54:35.250457+00:00` (`docs/baseline-checks.json:2–12`). Trong lượt rà soát này đã tính lại SHA-256 của `infra/archive/archive.go`, `infra/archive/archive_test.go`, `infra/go.mod` và `infra/go.sum`: **4/4 khớp** các hash nguồn tại `baseline-checks.json:5–9`. Không chạy lại Go; các kết quả dưới đây là baseline đã đối chiếu nguồn.

| Kiểm tra tại `infra` | Kết quả baseline | Tham chiếu |
| --- | --- | --- |
| `gofmt -l .` | Mã thoát 0, không liệt kê tệp | `docs/baseline-checks.json:15–29` |
| `go mod tidy -diff` | Mã thoát 0, không có diff | `docs/baseline-checks.json:31–46` |
| `go vet ./...` | Mã thoát 0, không có chẩn đoán | `docs/baseline-checks.json:48–63` |
| `go build ./...` | Mã thoát 0, không có lỗi | `docs/baseline-checks.json:65–79` |
| `go test -count=1 -v ./...` | Mã thoát 0; cả bốn test PASS; số request lần lượt 4, 0, 5, 5 | `docs/baseline-checks.json:80–96` |

Baseline ghi `GOPROXY=off`, `GOSUMDB=off`, `AWS_EC2_METADATA_DISABLED=true`. Các test gọi resource AWS Go thật qua `pulumi.WithMocks` (`infra/archive/archive.go:6–9`; `infra/archive/archive_test.go:45–58`), không tạo tài nguyên AWS. Danh mục được sắp xếp theo type/name (`archive_test.go:38–43`), nên thứ tự trong log không chứng minh thứ tự thực thi đăng ký.

## Phạm vi và điều chưa biết khi bàn giao

Chỉ cập nhật tài liệu này; mã nguồn, test và module giữ nguyên. Không chạy preview, triển khai, thao tác state/config/auth hoặc lấy giá trị bí mật. Mock ghi type/name/parent, trả lại inputs và ID giả (`infra/archive/archive_test.go:15–19,26–36`); assertions hiện có không kiểm chứng provider wiring, giá trị cấu hình chặn công khai, retention hoặc component outputs. Bằng chứng Go/mock không xác nhận AWS chấp nhận cấu hình, trạng thái tài nguyên thực tế, hay việc không có thay thế/xóa/thay đổi trong kế hoạch cloud. Hai ca đầu vào 0 và 7 không chứng minh mọi giá trị dương đều hợp lệ với AWS.
