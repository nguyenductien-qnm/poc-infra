package archive

import (
	"fmt"

	"github.com/pulumi/pulumi-aws/sdk/v7/go/aws"
	"github.com/pulumi/pulumi-aws/sdk/v7/go/aws/cloudwatch"
	"github.com/pulumi/pulumi-aws/sdk/v7/go/aws/s3"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
)

type Args struct{ KeepDays int }

type Archive struct {
	pulumi.ResourceState
	Bucket *s3.Bucket
	Access *s3.BucketPublicAccessBlock
	Audit  *cloudwatch.LogGroup
}

func validate(args Args) error {
	if args.KeepDays < 1 {
		return fmt.Errorf("archive KeepDays must be positive")
	}
	return nil
}

// NewLate giu thu tu dang ky cua luong archive cu.
func NewLate(ctx *pulumi.Context, name string, args Args) (*Archive, error) {
	root, provider, err := prepare(ctx, name)
	if err != nil {
		return nil, err
	}
	audit, err := newAudit(ctx, name, args, root, provider)
	if err != nil {
		return nil, err
	}
	root.Audit = audit
	return root, ctx.RegisterResourceOutputs(root, pulumi.Map{"bucket": root.Bucket.ID(), "audit": audit.ID()})
}

// NewEarly kiem tra tham so tai diem vao truoc khi tao tai nguyen.
func NewEarly(ctx *pulumi.Context, name string, args Args) (*Archive, error) {
	if err := validate(args); err != nil {
		return nil, err
	}
	return NewLate(ctx, name, args)
}

func prepare(ctx *pulumi.Context, name string) (*Archive, *aws.Provider, error) {
	provider, err := aws.NewProvider(ctx, name+"-region", &aws.ProviderArgs{Region: pulumi.String("ap-southeast-1")})
	if err != nil {
		return nil, nil, err
	}
	root := &Archive{}
	if err = ctx.RegisterComponentResource("lab:archive:Archive", name, root); err != nil {
		return nil, nil, err
	}
	root.Bucket, err = s3.NewBucket(ctx, name+"-blobs", &s3.BucketArgs{}, pulumi.Parent(root), pulumi.Provider(provider))
	if err != nil {
		return nil, nil, err
	}
	root.Access, err = s3.NewBucketPublicAccessBlock(ctx, name+"-access", &s3.BucketPublicAccessBlockArgs{
		Bucket: root.Bucket.ID(), BlockPublicAcls: pulumi.Bool(true), BlockPublicPolicy: pulumi.Bool(true),
		IgnorePublicAcls: pulumi.Bool(true), RestrictPublicBuckets: pulumi.Bool(true),
	}, pulumi.Parent(root), pulumi.Provider(provider))
	if err != nil {
		return nil, nil, err
	}
	return root, provider, nil
}

func newAudit(ctx *pulumi.Context, name string, args Args, parent *Archive, provider *aws.Provider) (*cloudwatch.LogGroup, error) {
	if err := validate(args); err != nil {
		return nil, err
	}
	return cloudwatch.NewLogGroup(ctx, name+"-audit", &cloudwatch.LogGroupArgs{RetentionInDays: pulumi.Int(args.KeepDays)}, pulumi.Parent(parent), pulumi.Provider(provider))
}
