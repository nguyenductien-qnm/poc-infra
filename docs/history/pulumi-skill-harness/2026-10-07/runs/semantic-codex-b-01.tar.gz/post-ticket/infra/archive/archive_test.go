package archive

import (
	"encoding/json"
	"reflect"
	"sort"
	"strings"
	"sync"
	"testing"

	"github.com/pulumi/pulumi/sdk/v3/go/common/resource"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
)

type request struct {
	Type   string `json:"type"`
	Name   string `json:"name"`
	Parent string `json:"parent"`
}

type recorder struct {
	mu      sync.Mutex
	records []request
}

func (m *recorder) Call(args pulumi.MockCallArgs) (resource.PropertyMap, error) {
	return args.Args, nil
}
func (m *recorder) NewResource(args pulumi.MockResourceArgs) (string, resource.PropertyMap, error) {
	// Stack la tai nguyen ngam cua SDK, khong phai khai bao cua ung dung.
	if args.TypeToken != "pulumi:pulumi:Stack" {
		m.mu.Lock()
		m.records = append(m.records, request{args.TypeToken, args.Name, args.RegisterRPC.GetParent()})
		m.mu.Unlock()
	}
	return args.Name + "-mock", args.Inputs, nil
}
func (m *recorder) inventory() []request {
	m.mu.Lock()
	defer m.mu.Unlock()
	result := append([]request{}, m.records...)
	sort.Slice(result, func(i, j int) bool { return result[i].Type+"/"+result[i].Name < result[j].Type+"/"+result[j].Name })
	return result
}
func observe(t *testing.T, constructor func(*pulumi.Context, string, Args) (*Archive, error), days int) ([]request, error) {
	t.Helper()
	m := &recorder{}
	err := pulumi.RunErr(func(ctx *pulumi.Context) error {
		_, err := constructor(ctx, "ledger", Args{KeepDays: days})
		return err
	}, pulumi.WithMocks("archive-review", "sandbox", m))
	records := m.inventory()
	encoded, encodeErr := json.Marshal(records)
	if encodeErr != nil {
		t.Fatal(encodeErr)
	}
	t.Log("APPLICATION_REGISTRATION_REQUESTS:" + string(encoded))
	return records, err
}

func TestLateRejectedInput(t *testing.T) {
	records, err := observe(t, NewLate, 0)
	if err == nil || !strings.Contains(err.Error(), "KeepDays must be positive") {
		t.Fatalf("expected input rejection, got %v", err)
	}
	expected := []string{"aws:s3/bucket:Bucket", "aws:s3/bucketPublicAccessBlock:BucketPublicAccessBlock", "lab:archive:Archive", "pulumi:providers:aws"}
	types := []string{}
	for _, item := range records {
		types = append(types, item.Type)
	}
	if !reflect.DeepEqual(types, expected) {
		t.Fatalf("unexpected preceding application requests: %v", types)
	}
}

func TestEarlyRejectedInput(t *testing.T) {
	records, err := observe(t, NewEarly, 0)
	if err == nil || !strings.Contains(err.Error(), "KeepDays must be positive") {
		t.Fatalf("expected input rejection, got %v", err)
	}
	if len(records) != 0 {
		t.Fatalf("application registrations preceded root rejection: %+v", records)
	}
}

const stackParent = "urn:pulumi:sandbox::archive-review::pulumi:pulumi:Stack::archive-review-sandbox"
const archiveParent = "urn:pulumi:sandbox::archive-review::lab:archive:Archive::ledger"

func TestSelectedParents(t *testing.T) {
	records, err := observe(t, NewEarly, 7)
	if err != nil {
		t.Fatal(err)
	}
	if len(records) != 5 {
		t.Fatalf("expected five application registrations, got %d", len(records))
	}
	checked := 0
	for _, item := range records {
		if item.Type == "aws:s3/bucket:Bucket" || item.Type == "aws:cloudwatch/logGroup:LogGroup" {
			checked++
			if item.Parent != archiveParent {
				t.Errorf("unexpected selected parent: %+v", item)
			}
		}
	}
	if checked != 2 {
		t.Fatalf("expected two selected children, checked %d", checked)
	}
}

func TestCompleteFrozenParents(t *testing.T) {
	records, err := observe(t, NewEarly, 7)
	if err != nil {
		t.Fatal(err)
	}
	// Danh muc dong bang doc lap gom ca provider va component goc.
	expected := []request{
		{"aws:cloudwatch/logGroup:LogGroup", "ledger-audit", archiveParent},
		{"aws:s3/bucket:Bucket", "ledger-blobs", archiveParent},
		{"aws:s3/bucketPublicAccessBlock:BucketPublicAccessBlock", "ledger-access", archiveParent},
		{"lab:archive:Archive", "ledger", stackParent},
		{"pulumi:providers:aws", "ledger-region", stackParent},
	}
	if !reflect.DeepEqual(records, expected) {
		t.Fatalf("complete parent inventory differs:\n got %+v\nwant %+v", records, expected)
	}
}
