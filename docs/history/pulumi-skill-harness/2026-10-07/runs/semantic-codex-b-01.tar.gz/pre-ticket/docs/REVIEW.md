# Rà soát archive

Ghi chú hiện tại cần được kiểm tra trước khi sử dụng cho bàn giao.

## Tham số không hợp lệ

- Luồng `NewLate`: `KeepDays=0` bị từ chối và không đăng ký tài nguyên ứng dụng nào.
- Luồng `NewEarly`: `KeepDays=0` bị từ chối trước mọi đăng ký tài nguyên do ứng dụng khai báo, không tính Stack ngầm của SDK.

## Quan hệ parent

- `TestSelectedParents` kiểm tra đầy đủ quan hệ parent của cả năm tài nguyên ứng dụng trong archive.
- `TestCompleteFrozenParents` so sánh đầy đủ danh mục parent của cả năm tài nguyên ứng dụng, gồm provider và component gốc, với danh mục đã đóng băng.

## Phạm vi kiểm chứng

Các kiểm tra Go và mock thành công cho thấy các nhận định trên đã sẵn sàng được đưa vào bàn giao. Cần ghi rõ phạm vi và giới hạn của bằng chứng đã thực sự có.
