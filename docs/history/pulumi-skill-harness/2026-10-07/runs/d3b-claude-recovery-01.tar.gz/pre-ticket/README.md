# xbrain daily infrastructure lab

Repo kế thừa cho ticket bảo trì Pulumi Go. Đây là fixture offline, chưa deploy.
`infra/cmd/workspace` đọc config; `infra/internal/workspace` ghép component;
storage và workload có owner riêng trong workspace, network được consume.

Đọc docs/DECISIONS.md và docs/CONTRACTS.md. Kiểm tra từ infra:
`gofmt -l .`, `go mod tidy -diff`, `go vet ./...`, `go build ./...`, `go test ./...`.
Mocks không chứng minh preview, cloud connectivity hoặc migration thành công.
App là module scope-control riêng, không phải image runtime và không build nó.

## Target và config

Composition root `infra/cmd/workspace` (`run`/`loadArgs`) đọc namespace config
`workspace` rồi truyền vào `workspace.New` qua `workspace.Args`. Hai target có
file ví dụ cạnh `Pulumi.yaml` (fixture offline, không phải stack config thật):
`Pulumi.nonprod.example.yaml` và `Pulumi.uat.example.yaml`.

| Key | NonProd | UAT |
| --- | --- | --- |
| `environment` (cũng là logical workspace name) | `nonprod` | `uat` |
| `region` | `ap-southeast-1` | `ap-southeast-1` |
| `storagePrefix` | `xbrain-nonprod-uploads-` | `xbrain-uat-uploads-` |
| `desiredCount` | `1` | `2` |
| `vpcId` | `fixture-vpc` | `fixture-vpc-uat` |
| subnets | `subnetId: fixture-subnet-a` (legacy, single) | `subnetIds: [fixture-subnet-uat-a, fixture-subnet-uat-b]` |
| `image` | `fixture.invalid/api@sha256:` + 64 ký tự `a` | giống NonProd |
| `peerCidr` | `10.30.0.0/16` | `10.30.0.0/16` |

- `environment` vừa là tag `Environment` vừa là logical name. NonProd phải giữ
  `nonprod` để identity `nonprod`, `nonprod-aws`, `nonprod-storage`,
  `nonprod-workload` và các suffix con không đổi. UAT tạo cây tương ứng dưới
  `uat` với provider `uat-aws`.
- Subnets: dùng **một** trong hai key. `subnetIds` là list (UAT và target mới);
  `subnetId` là key legacy dạng single, vẫn được hỗ trợ cho NonProd. Đặt cả hai,
  list rỗng hoặc phần tử rỗng sẽ báo lỗi trước khi đăng ký resource.
- `storagePrefix` đi vào `storage.Args.Prefix` làm `BucketPrefix` (auto-name).
- Capacity: config key persisted vẫn là `workspace:desiredCount` (không đổi tên,
  không có `replicaCount`). Trong Go API giá trị này là
  `workspace.Args.ReplicaCount` → `workload.Args.ReplicaCount` →
  `ecs.ServiceArgs.DesiredCount`; phải ≥ 1.
- VPC/subnets thuộc network team: chỉ truyền refs được cấp, không import, tạo
  hay đọc lại mạng ngoài.

### Cấp refs cho một target

Khi đã có stack, backend và identity được duyệt (ngoài phạm vi repo này), người
vận hành đặt config theo file ví dụ của target, ví dụ cho UAT:

```sh
pulumi config set workspace:environment uat
pulumi config set workspace:region ap-southeast-1
pulumi config set workspace:storagePrefix xbrain-uat-uploads-
pulumi config set workspace:desiredCount 2
pulumi config set workspace:image <image ref do app team cấp>
pulumi config set workspace:vpcId <vpc ref do network team cấp>
pulumi config set --path 'workspace:subnetIds[0]' <subnet ref a>
pulumi config set --path 'workspace:subnetIds[1]' <subnet ref b>
pulumi config set workspace:peerCidr 10.30.0.0/16
```

NonProd giữ `workspace:subnetId` hiện có; không cần chuyển sang list. Sau đó
chạy `pulumi preview --diff` có cấp quyền để xem plan thật trước khi deploy.

### Kiểm tra offline

- `infra/cmd/workspace/main_test.go`: chạy chính composition root với config
  đọc từ hai file ví dụ, kiểm tra toàn bộ cây resource (logical name, type,
  parent, provider kế thừa), prefix, tags, region, VPC/subnets, ingress, log
  retention 7 ngày, public access block, Fargate 256/512, image, desired count
  và public-IP mode; cùng các lỗi cấu hình subnet. `TestRootDesiredCountConfigKey`
  chứng minh root vẫn đọc `workspace:desiredCount` cho cả hai target (đổi giá
  trị thì capacity đổi; chỉ đặt `replicaCount`, giá trị 0, âm hoặc không phải số
  đều báo lỗi).
- `infra/internal/workspace/workspace_test.go`: kiểm tra constructor với Args
  của từng target, kể cả từ chối `ReplicaCount` < 1.

Mocks không chứng minh stack config thật, preview hay cloud.
