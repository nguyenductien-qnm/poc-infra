package main

import (
	"errors"
	"fmt"
	"strings"

	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi/config"
	"xbrain.local/daily/internal/workspace"
)

func main() {
	pulumi.Run(run)
}

func run(ctx *pulumi.Context) error {
	cfg := config.New(ctx, "workspace")
	environment := cfg.Require("environment")
	subnets, err := readSubnetIDs(cfg)
	if err != nil {
		return err
	}
	result, err := workspace.New(ctx, environment, &workspace.Args{
		Environment:   environment,
		Region:        cfg.Require("region"),
		StoragePrefix: cfg.Require("storagePrefix"),
		DesiredCount:  cfg.RequireInt("desiredCount"),
		Image:         pulumi.String(cfg.Require("image")),
		VpcID:         pulumi.String(cfg.Require("vpcId")),
		SubnetIDs:     subnets,
		PeerCIDR:      cfg.Require("peerCidr"),
	})
	if err != nil {
		return err
	}
	ctx.Export("bucketName", result.BucketName)
	ctx.Export("serviceName", result.ServiceName)
	return nil
}

func readSubnetIDs(cfg *config.Config) (pulumi.StringArray, error) {
	var refs []string
	err := cfg.TryObject("subnetIds", &refs)
	if errors.Is(err, config.ErrMissingVar) {
		legacy, err := cfg.Try("subnetId")
		if err != nil || strings.TrimSpace(legacy) == "" {
			return nil, fmt.Errorf("workspace requires subnetIds or legacy subnetId")
		}
		refs = []string{legacy}
	} else if err != nil || len(refs) == 0 {
		return nil, fmt.Errorf("workspace:subnetIds must be a non-empty list of subnet references")
	}
	subnets := make(pulumi.StringArray, len(refs))
	for i, ref := range refs {
		if strings.TrimSpace(ref) == "" {
			return nil, fmt.Errorf("workspace subnet references must not be blank")
		}
		subnets[i] = pulumi.String(ref)
	}
	return subnets, nil
}
