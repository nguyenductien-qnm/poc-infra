package workspace

import (
	"encoding/json"
	"fmt"
	"github.com/pulumi/pulumi/sdk/v3/go/common/resource"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
	"reflect"
	"sort"
	"strings"
	"sync"
	"testing"
)

// Mocks va contract cua controller, khong dung helper ma coder co the sua.
type d2Mocks struct {
	mu      sync.Mutex
	records []pulumi.MockResourceArgs
	outputs map[string]string
}

func (m *d2Mocks) Call(args pulumi.MockCallArgs) (resource.PropertyMap, error) {
	return nil, fmt.Errorf("unexpected offline invoke: %s", args.Token)
}
func (m *d2Mocks) NewResource(args pulumi.MockResourceArgs) (string, resource.PropertyMap, error) {
	m.mu.Lock()
	m.records = append(m.records, args)
	m.mu.Unlock()
	outputs := args.Inputs.Copy()
	outputs["name"] = resource.NewStringProperty(args.Name)
	outputs["arn"] = resource.NewStringProperty("fixture-reference-" + args.Name)
	if args.TypeToken == "aws:s3/bucket:Bucket" {
		outputs["bucket"] = resource.NewStringProperty(args.Name + "-mock")
	}
	return args.Name + "-mock-id", outputs, nil
}
func (m *d2Mocks) resources() []pulumi.MockResourceArgs {
	m.mu.Lock()
	defer m.mu.Unlock()
	return append([]pulumi.MockResourceArgs(nil), m.records...)
}

// Ky vong co dinh truoc constructor, khong doc lai Args sau khi chay.
type d2Contract struct {
	name, environment, region, prefix, vpc, cidr string
	capacity                                     int
	subnets                                      []string
}

func d2Contracts() []d2Contract {
	return []d2Contract{
		{name: "nonprod", environment: "nonprod", region: "ap-southeast-1", prefix: "xbrain-nonprod-uploads-", capacity: 1, vpc: "fixture-vpc", subnets: []string{"fixture-subnet-a"}, cidr: "10.30.0.0/16"},
		{name: "uat", environment: "uat", region: "ap-southeast-1", prefix: "xbrain-uat-uploads-", capacity: 2, vpc: "fixture-vpc-uat", subnets: []string{"fixture-subnet-uat-a", "fixture-subnet-uat-b"}, cidr: "10.30.0.0/16"},
	}
}
func d2Args(spec d2Contract) *Args {
	subnets := pulumi.StringArray{}
	for _, subnet := range spec.subnets {
		subnets = append(subnets, pulumi.String(subnet))
	}
	return &Args{Environment: spec.environment, Region: spec.region, StoragePrefix: spec.prefix, DesiredCount: spec.capacity,
		Image: pulumi.String("fixture.invalid/api@sha256:" + strings.Repeat("a", 64)), VpcID: pulumi.String(spec.vpc), SubnetIDs: subnets, PeerCIDR: spec.cidr}
}

type d2Identity struct{ Type, Name, Parent, Provider string }

func d2Inventory(m *d2Mocks) []d2Identity {
	result := []d2Identity{}
	for _, item := range m.resources() {
		result = append(result, d2Identity{item.TypeToken, item.Name, item.RegisterRPC.GetParent(), item.Provider})
	}
	sort.Slice(result, func(i, j int) bool { return result[i].Type+"/"+result[i].Name < result[j].Type+"/"+result[j].Name })
	return result
}
func d2AssertInventory(t *testing.T, spec d2Contract, m *d2Mocks) {
	t.Helper()
	var expected []d2Identity
	// Chi doi logical names va stack URNs tu inventory NonProd dong bang.
	data := strings.ReplaceAll(d2FrozenNonProdIdentity, "nonprod", spec.name)
	if err := json.Unmarshal([]byte(data), &expected); err != nil {
		t.Fatal(err)
	}
	actual := d2Inventory(m)
	encoded, _ := json.Marshal(actual)
	t.Log("D2_REGISTRATION_INVENTORY:" + string(encoded))
	if len(expected) != 13 || !reflect.DeepEqual(actual, expected) {
		t.Errorf("full thirteen-resource identity/provider inventory changed: got %s", encoded)
	}
	for _, item := range m.resources() {
		if item.ID != "" || item.ReadRPC != nil || item.RegisterRPC.GetImportId() != "" {
			t.Errorf("unexpected external resource read/import: %s/%s", item.TypeToken, item.Name)
		}
		if item.TypeToken == "aws:ec2/vpc:Vpc" || item.TypeToken == "aws:ec2/subnet:Subnet" {
			t.Error("workspace registered externally owned network")
		}
	}
}
func d2One(t *testing.T, m *d2Mocks, token string) pulumi.MockResourceArgs {
	t.Helper()
	found := []pulumi.MockResourceArgs{}
	for _, item := range m.resources() {
		if item.TypeToken == token {
			found = append(found, item)
		}
	}
	if len(found) != 1 {
		t.Fatalf("got %d resources for %s, want 1", len(found), token)
	}
	return found[0]
}
func d2String(t *testing.T, props resource.PropertyMap, key string) string {
	t.Helper()
	value, ok := props[resource.PropertyKey(key)]
	if !ok || !value.IsString() {
		t.Fatalf("%s must be a concrete string", key)
	}
	return value.StringValue()
}
func d2Object(t *testing.T, props resource.PropertyMap, key string) resource.PropertyMap {
	t.Helper()
	value, ok := props[resource.PropertyKey(key)]
	if !ok || !value.IsObject() {
		t.Fatalf("%s must be an object", key)
	}
	return value.ObjectValue()
}
func d2Array(t *testing.T, props resource.PropertyMap, key string) []resource.PropertyValue {
	t.Helper()
	value, ok := props[resource.PropertyKey(key)]
	if !ok || !value.IsArray() {
		t.Fatalf("%s must be an array", key)
	}
	return value.ArrayValue()
}
func d2Strings(t *testing.T, props resource.PropertyMap, key string) []string {
	t.Helper()
	result := []string{}
	for _, value := range d2Array(t, props, key) {
		if !value.IsString() {
			t.Fatalf("%s array must contain strings", key)
		}
		result = append(result, value.StringValue())
	}
	return result
}
func d2WantString(t *testing.T, props resource.PropertyMap, key, want string) {
	t.Helper()
	if got := d2String(t, props, key); got != want {
		t.Errorf("%s: got %q, want %q", key, got, want)
	}
}
func d2WantNumber(t *testing.T, props resource.PropertyMap, key string, want float64) {
	t.Helper()
	value, ok := props[resource.PropertyKey(key)]
	if !ok || !value.IsNumber() {
		t.Fatalf("%s must be a concrete number", key)
	}
	if got := value.NumberValue(); got != want {
		t.Errorf("%s: got %v, want %v", key, got, want)
	}
}
func d2WantBool(t *testing.T, props resource.PropertyMap, key string, want bool) {
	t.Helper()
	value, ok := props[resource.PropertyKey(key)]
	if !ok || !value.IsBool() {
		t.Fatalf("%s must be a concrete boolean", key)
	}
	if got := value.BoolValue(); got != want {
		t.Errorf("%s: got %v, want %v", key, got, want)
	}
}
func d2CaptureOutputs(ctx *pulumi.Context, m *d2Mocks, result *Workspace) {
	result.BucketName.ApplyT(func(value string) string { m.mu.Lock(); m.outputs["bucketName"] = value; m.mu.Unlock(); return value })
	result.ServiceName.ApplyT(func(value string) string { m.mu.Lock(); m.outputs["serviceName"] = value; m.mu.Unlock(); return value })
	ctx.Export("bucketName", result.BucketName)
	ctx.Export("serviceName", result.ServiceName)
}
func TestHarnessD2Consumers(t *testing.T) {
	for _, spec := range d2Contracts() {
		t.Run(spec.name, func(t *testing.T) {
			args := d2Args(spec)
			mocks := &d2Mocks{outputs: map[string]string{}}
			err := pulumi.RunErr(func(ctx *pulumi.Context) error {
				result, err := New(ctx, spec.name, args)
				if err != nil {
					return err
				}
				d2CaptureOutputs(ctx, mocks, result)
				return nil
			}, pulumi.WithMocks("daily-workspace", spec.name, mocks))
			if err != nil {
				t.Fatal(err)
			}
			d2AssertInventory(t, spec, mocks)
			provider := d2One(t, mocks, "pulumi:providers:aws")
			if provider.Name != spec.name+"-aws" {
				t.Error("provider logical name changed")
			}
			d2WantString(t, provider.Inputs, "region", spec.region)
			for _, token := range []string{"aws:s3/bucket:Bucket", "aws:cloudwatch/logGroup:LogGroup", "aws:ec2/securityGroup:SecurityGroup", "aws:iam/role:Role", "aws:ecs/cluster:Cluster", "aws:ecs/taskDefinition:TaskDefinition", "aws:ecs/service:Service"} {
				tags := d2Object(t, d2One(t, mocks, token).Inputs, "tags")
				d2WantString(t, tags, "Team", "xbrain")
				d2WantString(t, tags, "Environment", spec.environment)
			}
			bucket := d2One(t, mocks, "aws:s3/bucket:Bucket")
			d2WantString(t, bucket.Inputs, "bucketPrefix", spec.prefix)
			block := d2One(t, mocks, "aws:s3/bucketPublicAccessBlock:BucketPublicAccessBlock")
			d2WantString(t, block.Inputs, "bucket", spec.name+"-storage-uploads-mock-id")
			for _, key := range []string{"blockPublicAcls", "blockPublicPolicy", "ignorePublicAcls", "restrictPublicBuckets"} {
				d2WantBool(t, block.Inputs, key, true)
			}
			group := d2One(t, mocks, "aws:ec2/securityGroup:SecurityGroup")
			d2WantString(t, group.Inputs, "vpcId", spec.vpc)
			ingress := d2Array(t, group.Inputs, "ingress")
			if len(ingress) != 1 || !ingress[0].IsObject() {
				t.Fatal("expected one internal ingress rule")
			}
			rule := ingress[0].ObjectValue()
			d2WantString(t, rule, "protocol", "tcp")
			d2WantNumber(t, rule, "fromPort", 8080)
			d2WantNumber(t, rule, "toPort", 8080)
			if got := d2Strings(t, rule, "cidrBlocks"); !reflect.DeepEqual(got, []string{spec.cidr}) {
				t.Errorf("ingress CIDR: got %v, want %v", got, spec.cidr)
			}
			egress := d2Array(t, group.Inputs, "egress")
			if len(egress) != 1 || !egress[0].IsObject() {
				t.Fatal("expected one lab egress rule")
			}
			outbound := egress[0].ObjectValue()
			d2WantString(t, outbound, "protocol", "-1")
			d2WantNumber(t, outbound, "fromPort", 0)
			d2WantNumber(t, outbound, "toPort", 0)
			if got := d2Strings(t, outbound, "cidrBlocks"); !reflect.DeepEqual(got, []string{"0.0.0.0/0"}) {
				t.Errorf("egress CIDR: got %v", got)
			}
			logs := d2One(t, mocks, "aws:cloudwatch/logGroup:LogGroup")
			d2WantNumber(t, logs.Inputs, "retentionInDays", 7)
			role := d2One(t, mocks, "aws:iam/role:Role")
			var assume, wantAssume map[string]interface{}
			if err := json.Unmarshal([]byte(d2String(t, role.Inputs, "assumeRolePolicy")), &assume); err != nil {
				t.Fatal(err)
			}
			json.Unmarshal([]byte(`{"Version":"2012-10-17","Statement":[{"Effect":"Allow","Principal":{"Service":"ecs-tasks.amazonaws.com"},"Action":"sts:AssumeRole"}]}`), &wantAssume)
			if !reflect.DeepEqual(assume, wantAssume) {
				t.Error("task execution trust changed")
			}
			policy := d2One(t, mocks, "aws:iam/rolePolicy:RolePolicy")
			d2WantString(t, policy.Inputs, "role", spec.name+"-workload-execution-mock-id")
			var policyJSON, wantPolicy map[string]interface{}
			if err := json.Unmarshal([]byte(d2String(t, policy.Inputs, "policy")), &policyJSON); err != nil {
				t.Fatal(err)
			}
			expectedPolicy := fmt.Sprintf(`{"Version":"2012-10-17","Statement":[{"Effect":"Allow","Action":["logs:CreateLogStream","logs:PutLogEvents"],"Resource":"fixture-reference-%s-workload-logs:*"}]}`, spec.name)
			json.Unmarshal([]byte(expectedPolicy), &wantPolicy)
			if !reflect.DeepEqual(policyJSON, wantPolicy) {
				t.Error("log policy output wiring changed")
			}
			task := d2One(t, mocks, "aws:ecs/taskDefinition:TaskDefinition")
			d2WantString(t, task.Inputs, "family", spec.name+"-workload")
			d2WantString(t, task.Inputs, "cpu", "256")
			d2WantString(t, task.Inputs, "memory", "512")
			d2WantString(t, task.Inputs, "networkMode", "awsvpc")
			d2WantString(t, task.Inputs, "executionRoleArn", "fixture-reference-"+spec.name+"-workload-execution")
			if got := d2Strings(t, task.Inputs, "requiresCompatibilities"); !reflect.DeepEqual(got, []string{"FARGATE"}) {
				t.Errorf("runtime compatibility changed: %v", got)
			}
			var containers, wantContainers []map[string]interface{}
			if err := json.Unmarshal([]byte(d2String(t, task.Inputs, "containerDefinitions")), &containers); err != nil {
				t.Fatal(err)
			}
			expectedContainers := fmt.Sprintf(`[{"name":"api","image":"fixture.invalid/api@sha256:%s","essential":true,"portMappings":[{"containerPort":8080,"protocol":"tcp"}],"healthCheck":{"command":["CMD-SHELL","curl -f http://localhost:8080/health || exit 1"],"interval":30,"timeout":5,"retries":3},"logConfiguration":{"logDriver":"awslogs","options":{"awslogs-group":"%s-workload-logs","awslogs-region":"%s","awslogs-stream-prefix":"api"}}}]`, strings.Repeat("a", 64), spec.name, spec.region)
			if err := json.Unmarshal([]byte(expectedContainers), &wantContainers); err != nil {
				t.Fatal(err)
			}
			if !reflect.DeepEqual(containers, wantContainers) {
				t.Error("container runtime/image/health/log output wiring changed")
			}
			service := d2One(t, mocks, "aws:ecs/service:Service")
			d2WantNumber(t, service.Inputs, "desiredCount", float64(spec.capacity))
			d2WantString(t, service.Inputs, "cluster", "fixture-reference-"+spec.name+"-workload-cluster")
			d2WantString(t, service.Inputs, "taskDefinition", "fixture-reference-"+spec.name+"-workload-task")
			d2WantString(t, service.Inputs, "launchType", "FARGATE")
			network := d2Object(t, service.Inputs, "networkConfiguration")
			if got := d2Strings(t, network, "subnets"); !reflect.DeepEqual(got, spec.subnets) {
				t.Errorf("ECS subnet wiring: got %v, want %v", got, spec.subnets)
			}
			if got := d2Strings(t, network, "securityGroups"); !reflect.DeepEqual(got, []string{spec.name + "-workload-service-sg-mock-id"}) {
				t.Errorf("ECS SG output wiring: got %v", got)
			}
			d2WantBool(t, network, "assignPublicIp", true)
			dependsOnPolicy := false
			for _, dependency := range service.RegisterRPC.GetDependencies() {
				dependsOnPolicy = dependsOnPolicy || strings.HasSuffix(dependency, "::"+spec.name+"-workload-logs-policy")
			}
			if !dependsOnPolicy {
				t.Error("service log policy dependency missing")
			}
			mocks.mu.Lock()
			outputs := map[string]string{"bucketName": mocks.outputs["bucketName"], "serviceName": mocks.outputs["serviceName"]}
			mocks.mu.Unlock()
			expectedOutputs := map[string]string{"bucketName": spec.name + "-storage-uploads-mock", "serviceName": spec.name + "-workload-service"}
			if !reflect.DeepEqual(outputs, expectedOutputs) {
				t.Errorf("workspace outputs: got %v, want %v", outputs, expectedOutputs)
			}
		})
	}
}
func TestHarnessD2UnknownImageRegistration(t *testing.T) {
	for _, spec := range d2Contracts() {
		t.Run(spec.name, func(t *testing.T) {
			args := d2Args(spec)
			args.Image = pulumi.UnsafeUnknownOutput(nil).ApplyT(func(value interface{}) string { return value.(string) }).(pulumi.StringOutput)
			mocks := &d2Mocks{outputs: map[string]string{}}
			err := pulumi.RunErr(func(ctx *pulumi.Context) error { _, err := New(ctx, spec.name, args); return err }, pulumi.WithMocks("daily-workspace", spec.name, mocks), func(info *pulumi.RunInfo) { info.DryRun = true })
			if err != nil {
				t.Fatal(err)
			}
			d2AssertInventory(t, spec, mocks)
			d2One(t, mocks, "aws:ecs/taskDefinition:TaskDefinition")
			d2One(t, mocks, "aws:ecs/service:Service")
		})
	}
}

// Inventory NonProd dong bang, khong phu thuoc file coder hoac environment.
const d2FrozenNonProdIdentity = `[
  {
    "Type": "aws:cloudwatch/logGroup:LogGroup",
    "Name": "nonprod-workload-logs",
    "Parent": "urn:pulumi:nonprod::daily-workspace::xbrain:workspace:Workspace$xbrain:workload:Workload::nonprod-workload",
    "Provider": "urn:pulumi:nonprod::daily-workspace::pulumi:providers:aws::nonprod-aws::nonprod-aws-mock-id"
  },
  {
    "Type": "aws:ec2/securityGroup:SecurityGroup",
    "Name": "nonprod-workload-service-sg",
    "Parent": "urn:pulumi:nonprod::daily-workspace::xbrain:workspace:Workspace$xbrain:workload:Workload::nonprod-workload",
    "Provider": "urn:pulumi:nonprod::daily-workspace::pulumi:providers:aws::nonprod-aws::nonprod-aws-mock-id"
  },
  {
    "Type": "aws:ecs/cluster:Cluster",
    "Name": "nonprod-workload-cluster",
    "Parent": "urn:pulumi:nonprod::daily-workspace::xbrain:workspace:Workspace$xbrain:workload:Workload::nonprod-workload",
    "Provider": "urn:pulumi:nonprod::daily-workspace::pulumi:providers:aws::nonprod-aws::nonprod-aws-mock-id"
  },
  {
    "Type": "aws:ecs/service:Service",
    "Name": "nonprod-workload-service",
    "Parent": "urn:pulumi:nonprod::daily-workspace::xbrain:workspace:Workspace$xbrain:workload:Workload::nonprod-workload",
    "Provider": "urn:pulumi:nonprod::daily-workspace::pulumi:providers:aws::nonprod-aws::nonprod-aws-mock-id"
  },
  {
    "Type": "aws:ecs/taskDefinition:TaskDefinition",
    "Name": "nonprod-workload-task",
    "Parent": "urn:pulumi:nonprod::daily-workspace::xbrain:workspace:Workspace$xbrain:workload:Workload::nonprod-workload",
    "Provider": "urn:pulumi:nonprod::daily-workspace::pulumi:providers:aws::nonprod-aws::nonprod-aws-mock-id"
  },
  {
    "Type": "aws:iam/role:Role",
    "Name": "nonprod-workload-execution",
    "Parent": "urn:pulumi:nonprod::daily-workspace::xbrain:workspace:Workspace$xbrain:workload:Workload::nonprod-workload",
    "Provider": "urn:pulumi:nonprod::daily-workspace::pulumi:providers:aws::nonprod-aws::nonprod-aws-mock-id"
  },
  {
    "Type": "aws:iam/rolePolicy:RolePolicy",
    "Name": "nonprod-workload-logs-policy",
    "Parent": "urn:pulumi:nonprod::daily-workspace::xbrain:workspace:Workspace$xbrain:workload:Workload::nonprod-workload",
    "Provider": "urn:pulumi:nonprod::daily-workspace::pulumi:providers:aws::nonprod-aws::nonprod-aws-mock-id"
  },
  {
    "Type": "aws:s3/bucket:Bucket",
    "Name": "nonprod-storage-uploads",
    "Parent": "urn:pulumi:nonprod::daily-workspace::xbrain:workspace:Workspace$xbrain:storage:Storage::nonprod-storage",
    "Provider": "urn:pulumi:nonprod::daily-workspace::pulumi:providers:aws::nonprod-aws::nonprod-aws-mock-id"
  },
  {
    "Type": "aws:s3/bucketPublicAccessBlock:BucketPublicAccessBlock",
    "Name": "nonprod-storage-uploads-access",
    "Parent": "urn:pulumi:nonprod::daily-workspace::xbrain:workspace:Workspace$xbrain:storage:Storage::nonprod-storage",
    "Provider": "urn:pulumi:nonprod::daily-workspace::pulumi:providers:aws::nonprod-aws::nonprod-aws-mock-id"
  },
  {
    "Type": "pulumi:providers:aws",
    "Name": "nonprod-aws",
    "Parent": "urn:pulumi:nonprod::daily-workspace::pulumi:pulumi:Stack::daily-workspace-nonprod",
    "Provider": ""
  },
  {
    "Type": "xbrain:storage:Storage",
    "Name": "nonprod-storage",
    "Parent": "urn:pulumi:nonprod::daily-workspace::xbrain:workspace:Workspace::nonprod",
    "Provider": ""
  },
  {
    "Type": "xbrain:workload:Workload",
    "Name": "nonprod-workload",
    "Parent": "urn:pulumi:nonprod::daily-workspace::xbrain:workspace:Workspace::nonprod",
    "Provider": ""
  },
  {
    "Type": "xbrain:workspace:Workspace",
    "Name": "nonprod",
    "Parent": "urn:pulumi:nonprod::daily-workspace::pulumi:pulumi:Stack::daily-workspace-nonprod",
    "Provider": ""
  }
]`
