# xbrain daily infrastructure lab

Repo kế thừa cho ticket bảo trì Pulumi Go. Đây là fixture offline, chưa deploy.
`infra/cmd/workspace` đọc config; `infra/internal/workspace` ghép component;
storage và workload có owner riêng trong workspace, network được consume.

Đọc docs/DECISIONS.md và docs/CONTRACTS.md. Kiểm tra từ infra:
`gofmt -l .`, `go mod tidy -diff`, `go vet ./...`, `go build ./...`, `go test ./...`.
Mocks không chứng minh preview, cloud connectivity hoặc migration thành công.
App là module scope-control riêng, không phải image runtime và không build nó.

## Dùng lại component Workspace

`infra/internal/workspace.New(ctx, name, args, opts...)` ghép storage và workload
qua Args cụ thể. Component không đọc stack config. Composition root
`infra/cmd/workspace` đọc namespace `workspace` và dùng `environment` làm
logical name; tên stack không quyết định tên component. Khi dùng trong một
composition root khác của module `infra`, truyền name ổn định và các giá trị từ
contract của môi trường đó.

| Config ở root | Args | Ý nghĩa |
| --- | --- | --- |
| `workspace:environment` | `Environment` | Tag `Environment`; root dùng làm logical name |
| `workspace:region` | `Region` | Region cho provider và container logs |
| `workspace:storagePrefix` | `StoragePrefix` | Truyền xuống `storage.Args.BucketPrefix`; giữ S3 auto-naming |
| `workspace:desiredCount` | `DesiredCount` | Số task ECS, phải lớn hơn 0 |
| `workspace:image` | `Image` | Image do app team cấp, truyền qua Pulumi Input |
| `workspace:vpcId` | `VpcID` | VPC ngoài workspace, chỉ consume |
| `workspace:subnetId` | `SubnetIDs` | Root hiện nhận một subnet; component nhận StringArrayInput |
| `workspace:peerCidr` | `PeerCIDR` | CIDR được ingress TCP tới port 8080 |

Environment, region và storage prefix phải khác rỗng. `BucketName` và
`ServiceName` là Pulumi StringOutput, được đăng ký trên component và export ở
root thành `bucketName` / `serviceName`; giữ Output khi nối với consumer tiếp theo.

Ví dụ Go cho UAT từ contract offline (dùng trong module `infra`):

```go
result, err := workspace.New(ctx, "uat", &workspace.Args{
    Environment:   "uat",
    Region:        "ap-southeast-1",
    StoragePrefix: "xbrain-uat-uploads-",
    DesiredCount:  2,
    Image:         pulumi.String("fixture.invalid/api@sha256:" + strings.Repeat("a", 64)),
    VpcID:         pulumi.String("fixture-vpc"),
    SubnetIDs:     pulumi.StringArray{pulumi.String("fixture-subnet-a")},
    PeerCIDR:      "10.30.0.0/16",
})
if err != nil {
    return err
}
ctx.Export("bucketName", result.BucketName)
ctx.Export("serviceName", result.ServiceName)
```

Ví dụ cần import `strings`, `github.com/pulumi/pulumi/sdk/v3/go/pulumi` và
`xbrain.local/daily/internal/workspace`. Region trong ví dụ là fixture test.
Theo [contract](docs/CONTRACTS.md), NonProd dùng environment/name `nonprod`,
prefix `xbrain-nonprod-uploads-`, desired count 1; UAT dùng `uat`,
`xbrain-uat-uploads-`, desired count 2. Cả hai giữ tag `Team=xbrain`, retention
7 ngày, port 8080, health `/health`, Fargate 256 CPU/512 MiB và wiring logs.
UAT chỉ được kiểm chứng bằng mocks; chưa onboard. Mỗi môi trường phải nhận
contract mạng riêng và image live trước khi triển khai; fixture không dùng trên AWS.

Workspace sở hữu provider `<name>-aws` ở stack root, bucket và public-access
block, SG, logs, execution role/policy, ECS cluster/task/service. Child components
`<name>-storage` và `<name>-workload` có parent là Workspace; tài nguyên có
parent là component tương ứng và kế thừa provider. VPC/subnet không được tạo,
đọc lookup hay import. Caller options được truyền vào đăng ký Workspace;
giữ provider do Workspace sở hữu theo [quyết định](docs/DECISIONS.md).

Với NonProd hiện tại, giữ environment/name `nonprod`, region và prefix cũ:
type token `xbrain:workspace:Workspace`, toàn bộ logical names, parents và
provider ownership giữ nguyên; bucket vẫn dùng `BucketPrefix`, không có physical
name cố định. Theo source không dự kiến replacement/deletion và không cần alias
cho refactor này. Đổi environment/name, parent, region hay prefix về sau cần
đánh giá migration riêng. Chưa có observed preview hoặc kiểm chứng cloud.

## Kiểm chứng offline

Trong PowerShell, từ thư mục `infra`, dùng dependency/toolchain đã có sẵn để
không tải mạng:

```powershell
$env:GOTOOLCHAIN = 'local'
$env:GOPROXY = 'off'
$env:GOSUMDB = 'off'
gofmt -l .
go mod tidy -diff
go vet ./...
go build ./...
go test ./...
```

`TestWorkspaceContracts` kiểm tra cả NonProd và UAT: inventory/identity,
parent/provider, prefix, tags, capacity, Outputs, mạng ngoài, container và quyền
ghi log nối từ LogGroup Output. `TestConfiguredEnvironments` chạy composition
root bằng config fixture cho cả hai môi trường với tên stack độc lập, kiểm tra
root truyền environment, prefix và capacity. Mocks từ chối provider invoke;
tests chỉ dùng giá trị fixture. Các check này không chứng minh preview,
image pull, connectivity hay migration thành công.
