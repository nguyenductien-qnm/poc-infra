package main

import (
	"strconv"
	"strings"
	"testing"

	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
	"xbrain.local/daily/internal/testutil"
)

func TestConfiguredEnvironments(t *testing.T) {
	for _, tc := range []struct {
		environment string
		prefix      string
		capacity    int
	}{
		{"nonprod", "xbrain-nonprod-uploads-", 1},
		{"uat", "xbrain-uat-uploads-", 2},
	} {
		t.Run(tc.environment, func(t *testing.T) {
			mocks := &testutil.Mocks{}
			err := pulumi.RunErr(run, pulumi.WithMocks("daily-workspace", "fixture-stack", mocks), func(info *pulumi.RunInfo) {
				info.Config = map[string]string{
					"workspace:environment": tc.environment, "workspace:region": "ap-southeast-1",
					"workspace:storagePrefix": tc.prefix, "workspace:desiredCount": strconv.Itoa(tc.capacity),
					"workspace:image": "fixture.invalid/api@sha256:" + strings.Repeat("a", 64),
					"workspace:vpcId": "fixture-vpc", "workspace:subnetId": "fixture-subnet-a", "workspace:peerCidr": "10.30.0.0/16",
				}
			})
			if err != nil {
				t.Fatal(err)
			}
			seenWorkspace, seenBucket, seenService := false, false, false
			for _, item := range mocks.Resources() {
				switch item.TypeToken {
				case "xbrain:workspace:Workspace":
					seenWorkspace = true
					if item.Name != tc.environment {
						t.Error("workspace name must come from environment config")
					}
				case "aws:s3/bucket:Bucket":
					seenBucket = true
					if item.Name != tc.environment+"-storage-uploads" || item.Inputs["bucketPrefix"].StringValue() != tc.prefix {
						t.Error("storage must consume the configured name and prefix")
					}
				case "aws:ecs/service:Service":
					seenService = true
					if item.Name != tc.environment+"-workload-service" || item.Inputs["desiredCount"].NumberValue() != float64(tc.capacity) {
						t.Error("workload must consume the configured name and capacity")
					}
				}
			}
			if !seenWorkspace || !seenBucket || !seenService {
				t.Error("missing configured workspace resources")
			}
		})
	}
}
