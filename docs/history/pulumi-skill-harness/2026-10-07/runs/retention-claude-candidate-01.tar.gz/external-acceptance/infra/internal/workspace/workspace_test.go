package workspace

import (
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
	"strings"
	"testing"
	"xbrain.local/daily/internal/testutil"
)

func NonProdArgs() *Args {
	return &Args{Environment: "nonprod", Region: "ap-southeast-1", StoragePrefix: "xbrain-nonprod-uploads-", DesiredCount: 1,
		Image: pulumi.String("fixture.invalid/api@sha256:" + strings.Repeat("a", 64)),
		VpcID: pulumi.String("fixture-vpc"), SubnetIDs: pulumi.StringArray{pulumi.String("fixture-subnet-a")}, PeerCIDR: "10.30.0.0/16"}
}

func TestExistingNonProd(t *testing.T) {
	mocks := &testutil.Mocks{}
	err := pulumi.RunErr(func(ctx *pulumi.Context) error {
		result, err := New(ctx, "nonprod", NonProdArgs())
		if err != nil {
			return err
		}
		ctx.Export("bucketName", result.BucketName)
		ctx.Export("serviceName", result.ServiceName)
		return nil
	}, pulumi.WithMocks("daily-workspace", "nonprod", mocks))
	if err != nil {
		t.Fatal(err)
	}
	seenBucket, seenService := false, false
	for _, item := range mocks.Resources() {
		switch item.TypeToken {
		case "aws:s3/bucket:Bucket":
			seenBucket = true
			if item.Name != "nonprod-storage-uploads" || item.Inputs["bucketPrefix"].StringValue() != "xbrain-nonprod-uploads-" {
				t.Fatal("existing bucket contract changed")
			}
			if item.RegisterRPC.GetParent() == "" || item.Provider == "" {
				t.Fatal("bucket must have parent/provider")
			}
		case "aws:ecs/service:Service":
			seenService = true
			if item.Inputs["desiredCount"].NumberValue() != 1 {
				t.Fatal("existing capacity changed")
			}
			network := item.Inputs["networkConfiguration"].ObjectValue()
			if network["subnets"].ArrayValue()[0].StringValue() != "fixture-subnet-a" {
				t.Fatal("external subnet not consumed")
			}
		case "aws:ec2/vpc:Vpc", "aws:ec2/subnet:Subnet":
			t.Fatal("workspace must not own external network")
		}
	}
	if !seenBucket || !seenService {
		t.Fatal("missing existing resources")
	}
}

// UATArgs dung gia tri UAT trong contract, chua onboard o composition root.
func UATArgs() *Args {
	args := NonProdArgs()
	args.Environment, args.StoragePrefix, args.DesiredCount, args.LogRetentionDays = "uat", "xbrain-uat-uploads-", 2, 14
	return args
}

func runWorkspace(t *testing.T, name string, args *Args) []pulumi.MockResourceArgs {
	t.Helper()
	mocks := &testutil.Mocks{}
	err := pulumi.RunErr(func(ctx *pulumi.Context) error {
		_, err := New(ctx, name, args)
		return err
	}, pulumi.WithMocks("daily-workspace", name, mocks))
	if err != nil {
		t.Fatal(err)
	}
	return mocks.Resources()
}

func TestLogRetention(t *testing.T) {
	explicitNonProd := NonProdArgs()
	explicitNonProd.LogRetentionDays = 7
	future := NonProdArgs()
	future.LogRetentionDays = 30
	cases := []struct {
		label, name, environment string
		args                     *Args
		want                     float64
	}{
		{"nonprod default", "nonprod", "nonprod", NonProdArgs(), 7},
		{"nonprod explicit", "nonprod", "nonprod", explicitNonProd, 7},
		{"uat", "uat", "uat", UATArgs(), 14},
		{"future consumer", "nonprod", "nonprod", future, 30},
	}
	for _, tc := range cases {
		t.Run(tc.label, func(t *testing.T) {
			seenLogs := false
			for _, item := range runWorkspace(t, tc.name, tc.args) {
				switch item.TypeToken {
				case "aws:cloudwatch/logGroup:LogGroup":
					seenLogs = true
					if got := item.Inputs["retentionInDays"].NumberValue(); got != tc.want {
						t.Fatalf("retention = %v, want %v", got, tc.want)
					}
					// giu identity, parent va provider hien co cua log group
					if item.Name != tc.name+"-workload-logs" {
						t.Fatalf("log group logical name changed: %s", item.Name)
					}
					if !strings.HasSuffix(item.RegisterRPC.GetParent(), "xbrain:workload:Workload::"+tc.name+"-workload") {
						t.Fatalf("log group parent changed: %s", item.RegisterRPC.GetParent())
					}
					if !strings.Contains(item.Provider, "::"+tc.name+"-aws::") {
						t.Fatalf("log group provider changed: %s", item.Provider)
					}
					if item.Inputs["tags"].ObjectValue()["Environment"].StringValue() != tc.environment {
						t.Fatal("log group environment tag changed")
					}
				case "aws:ecs/service:Service":
					if item.Inputs["desiredCount"].NumberValue() != float64(tc.args.DesiredCount) {
						t.Fatal("capacity not passed through")
					}
				case "aws:ecs/taskDefinition:TaskDefinition":
					// image contract phai di nguyen ven vao container definition
					if !strings.Contains(item.Inputs["containerDefinitions"].StringValue(), "fixture.invalid/api@sha256:"+strings.Repeat("a", 64)) {
						t.Fatal("image contract changed")
					}
				case "aws:s3/bucket:Bucket":
					if item.Inputs["bucketPrefix"].StringValue() != tc.args.StoragePrefix {
						t.Fatal("storage prefix not passed through")
					}
				case "aws:ec2/vpc:Vpc", "aws:ec2/subnet:Subnet":
					t.Fatal("workspace must not own external network")
				}
			}
			if !seenLogs {
				t.Fatal("missing log group")
			}
		})
	}
}

func TestNegativeLogRetentionRejected(t *testing.T) {
	args := NonProdArgs()
	args.LogRetentionDays = -1
	err := pulumi.RunErr(func(ctx *pulumi.Context) error {
		_, err := New(ctx, "nonprod", args)
		return err
	}, pulumi.WithMocks("daily-workspace", "nonprod", &testutil.Mocks{}))
	if err == nil || !strings.Contains(err.Error(), "log retention") {
		t.Fatalf("expected retention validation error, got %v", err)
	}
}
