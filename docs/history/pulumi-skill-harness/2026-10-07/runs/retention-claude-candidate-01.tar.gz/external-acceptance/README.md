# xbrain daily infrastructure lab

Repo kế thừa cho ticket bảo trì Pulumi Go. Đây là fixture offline, chưa deploy.
`infra/cmd/workspace` đọc config; `infra/internal/workspace` ghép component;
storage và workload có owner riêng trong workspace, network được consume.

Đọc docs/DECISIONS.md và docs/CONTRACTS.md. Kiểm tra từ infra:
`gofmt -l .`, `go mod tidy -diff`, `go vet ./...`, `go build ./...`, `go test ./...`.
Mocks không chứng minh preview, cloud connectivity hoặc migration thành công.

Log retention: đặt `workspace:logRetentionDays` trong stack config của consumer;
giá trị đi qua `workspace.Args.LogRetentionDays` tới `workload.Args.LogRetentionDays`
và LogGroup `<workspace>-workload-logs`. Không cấp hoặc 0 giữ mặc định 7 ngày
(NonProd); UAT cấp 14; consumer tương lai cấp giá trị riêng (ví dụ 30) qua cùng
key. Giá trị âm bị từ chối. AWS chỉ chấp nhận một tập ngày retention cố định;
mocks không kiểm tra tập đó.
App là module scope-control riêng, không phải image runtime và không build nó.
