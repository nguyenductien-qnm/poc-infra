# Entry preview cua fixture, chi goi CLI gia lap duoc cap.
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
if ($env:D4_EVENT_NAME -ne 'workflow_dispatch' -or $env:D4_ORIGIN -ne 'pull_request' -or $env:D4_OPERATION -ne 'preview') {
    Write-Output 'D4_GATE:blocked'
    exit 0
}
if ($env:D4_REVISION -cnotmatch '^[0-9a-f]{40}$') { throw 'Full synthetic revision required' }
$backendLabel = 'fixture-backend-nonprod'
if ($env:D4_BACKEND_LABEL -ne $backendLabel) { throw 'Fixed mock backend label required' }
# Target duoc chon tai entrypoint, khong nhan tu input cua PR.
$target = 'uat'
& (Join-Path $PSScriptRoot 'stub-pulumi.ps1') -Command preview -Stack $target -BackendLabel $backendLabel -Revision $env:D4_REVISION
