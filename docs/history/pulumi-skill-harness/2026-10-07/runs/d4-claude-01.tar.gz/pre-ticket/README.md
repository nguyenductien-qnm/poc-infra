# xbrain daily infrastructure lab

Repo kế thừa cho ticket bảo trì Pulumi Go. Đây là fixture offline, chưa deploy.
`infra/cmd/workspace` đọc config; `infra/internal/workspace` ghép component;
storage và workload có owner riêng trong workspace, network được consume.

Đọc docs/DECISIONS.md và docs/CONTRACTS.md. Kiểm tra từ infra:
`gofmt -l .`, `go mod tidy -diff`, `go vet ./...`, `go build ./...`, `go test ./...`.
Mocks không chứng minh preview, cloud connectivity hoặc migration thành công.
App là module scope-control riêng, không phải image runtime và không build nó.

## Target và config

Composition root `infra/cmd/workspace` (`run`/`loadArgs`) đọc namespace config
`workspace` rồi truyền vào `workspace.New` qua `workspace.Args`. Hai target có
file ví dụ cạnh `Pulumi.yaml` (fixture offline, không phải stack config thật):
`Pulumi.nonprod.example.yaml` và `Pulumi.uat.example.yaml`.

| Key | NonProd | UAT |
| --- | --- | --- |
| `environment` (cũng là logical workspace name) | `nonprod` | `uat` |
| `region` | `ap-southeast-1` | `ap-southeast-1` |
| `storagePrefix` | `xbrain-nonprod-uploads-` | `xbrain-uat-uploads-` |
| `desiredCount` | `1` | `2` |
| `vpcId` | `fixture-vpc` | `fixture-vpc-uat` |
| subnets | `subnetId: fixture-subnet-a` (legacy, single) | `subnetIds: [fixture-subnet-uat-a, fixture-subnet-uat-b]` |
| `image` | `fixture.invalid/api@sha256:` + 64 ký tự `a` | giống NonProd |
| `peerCidr` | `10.30.0.0/16` | `10.30.0.0/16` |

- `environment` vừa là tag `Environment` vừa là logical name. NonProd phải giữ
  `nonprod` để identity `nonprod`, `nonprod-aws`, `nonprod-workload` và các
  suffix con không đổi. `nonprod-object-store` là tên mới (trước là
  `nonprod-storage`, giữ liên tục qua alias; xem "Migration D3b"). UAT tạo cây
  tương ứng dưới `uat` với provider `uat-aws`.
- Subnets: dùng **một** trong hai key. `subnetIds` là list (UAT và target mới);
  `subnetId` là key legacy dạng single, vẫn được hỗ trợ cho NonProd. Đặt cả hai,
  list rỗng hoặc phần tử rỗng sẽ báo lỗi trước khi đăng ký resource.
- `storagePrefix` đi vào `storage.Args.Prefix` làm `BucketPrefix` (auto-name).
- Capacity: config key persisted vẫn là `workspace:desiredCount` (không đổi tên,
  không có `replicaCount`). Trong Go API giá trị này là
  `workspace.Args.ReplicaCount` → `workload.Args.ReplicaCount` →
  `ecs.ServiceArgs.DesiredCount`; phải ≥ 1.
- VPC/subnets thuộc network team: chỉ truyền refs được cấp, không import, tạo
  hay đọc lại mạng ngoài.

### Cấp refs cho một target

Khi đã có stack, backend và identity được duyệt (ngoài phạm vi repo này), người
vận hành đặt config theo file ví dụ của target, ví dụ cho UAT:

```sh
pulumi config set workspace:environment uat
pulumi config set workspace:region ap-southeast-1
pulumi config set workspace:storagePrefix xbrain-uat-uploads-
pulumi config set workspace:desiredCount 2
pulumi config set workspace:image <image ref do app team cấp>
pulumi config set workspace:vpcId <vpc ref do network team cấp>
pulumi config set --path 'workspace:subnetIds[0]' <subnet ref a>
pulumi config set --path 'workspace:subnetIds[1]' <subnet ref b>
pulumi config set workspace:peerCidr 10.30.0.0/16
```

NonProd giữ `workspace:subnetId` hiện có; không cần chuyển sang list. Sau đó
chạy `pulumi preview --diff` có cấp quyền để xem plan thật trước khi deploy.

### Kiểm tra offline

- `infra/cmd/workspace/main_test.go`: chạy chính composition root với config
  đọc từ hai file ví dụ, kiểm tra toàn bộ cây resource (logical name, type,
  parent, provider kế thừa), prefix, tags, region, VPC/subnets, ingress, log
  retention 7 ngày, public access block, Fargate 256/512, image, desired count
  và public-IP mode; cùng các lỗi cấu hình subnet. `TestRootDesiredCountConfigKey`
  chứng minh root vẫn đọc `workspace:desiredCount` cho cả hai target (đổi giá
  trị thì capacity đổi; chỉ đặt `replicaCount`, giá trị 0, âm hoặc không phải số
  đều báo lỗi).
  `TestRootTargets` và `TestRootDryRunAliases` (DryRun) kiểm tra alias D3b ở
  mức declaration: chỉ `<ws>-object-store` khai báo alias `<ws>-storage`; children
  không tự khai báo alias và đều có tên bắt đầu bằng stem mới, nên alias kế
  thừa phủ đủ `<ws>-storage`, `<ws>-storage-uploads`, `<ws>-storage-uploads-access`.
  Alias type-only `aws:s3/bucketV2:BucketV2` trên Bucket do pulumi-aws v7 tự thêm,
  không phải của repo.
- `infra/internal/workspace/workspace_test.go`: kiểm tra constructor với Args
  của từng target, kể cả từ chối `ReplicaCount` < 1; `TestUnknownImageDryRun`
  kiểm tra image unknown trong DryRun vẫn đăng ký đủ 13 resources và alias.

Mocks không chứng minh stack config thật, preview hay cloud. Mocks mặc định chỉ
quan sát alias declarations, không resolve alias, nên không chứng minh engine
sẽ ghép đúng URN cũ, physical ID hay dữ liệu bucket được giữ.

## Migration D3b (đổi tên storage)

URN cũ → mới (ví dụ NonProd; UAT thay `nonprod` bằng `uat`):

| Type | Cũ | Mới |
| --- | --- | --- |
| `xbrain:storage:Storage` | `nonprod-storage` | `nonprod-object-store` |
| `aws:s3/bucket:Bucket` | `nonprod-storage-uploads` | `nonprod-object-store-uploads` |
| `aws:s3/bucketPublicAccessBlock:BucketPublicAccessBlock` | `nonprod-storage-uploads-access` | `nonprod-object-store-uploads-access` |

- Alias được khai báo ở `infra/internal/workspace/workspace.go` trên storage
  component; children kế thừa (xem [tài liệu aliases](https://www.pulumi.com/docs/iac/concepts/resources/options/aliases/)).
- Trước khi deploy: chạy `pulumi preview --diff` có cấp quyền cho từng stack.
  Kết quả mong đợi: 3 resource storage hiện là rename/same, không có
  `create`/`delete`/`replace`. Nếu thấy replace bucket thì dừng lại.
- Chỉ gỡ alias sau khi mọi stack (NonProd, UAT nếu đã có state) đã `up` thành công với tên mới.
