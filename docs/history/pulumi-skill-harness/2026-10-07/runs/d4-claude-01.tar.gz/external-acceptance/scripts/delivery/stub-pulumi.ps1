# CLI gia lap chi ghi trace sanitized, khong ket noi backend hay cloud.
param([string]$Command, [string]$Stack, [string]$BackendLabel, [string]$Revision)
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
if ($Command -ne 'preview') { throw 'Stub accepts preview only' }
if ($Stack -notin @('nonprod', 'uat')) { throw 'Unexpected fixture target' }
if ($BackendLabel -ne 'fixture-backend-nonprod') { throw 'Unexpected fixture backend label' }
if ($Revision -cnotmatch '^[0-9a-f]{40}$') { throw 'Unexpected fixture revision' }
$trace = [ordered]@{ synthetic = $true; command = $Command; stack = $Stack; backend_label = $BackendLabel; revision = $Revision }
Write-Output ('D4_STUB:' + ($trace | ConvertTo-Json -Compress))
