"""Kiem tra offline entrypoint preview D4 va workflow (stdlib only, khong goi Pulumi/cloud).

Chay tu root repo: python -B -m unittest discover -s scripts/delivery -p test_d4_preview.py
Can PowerShell 7 (pwsh) tren PATH. Trace la bang chung local, khong phai observed preview.
"""

import json
import os
import re
import shutil
import subprocess
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
ENTRYPOINT = ROOT / "scripts" / "delivery" / "preview.ps1"
WORKFLOW = ROOT / ".github" / "workflows" / "d4-preview.yml"
REVISION = "0123456789abcdef0123456789abcdef01234567"
BACKEND = "fixture-backend-nonprod"
PWSH = shutil.which("pwsh")


def fixture_env(**overrides):
    # chi giu PATH/SystemRoot va bien D4 fixture; khong mang credentials cua may local vao subprocess
    env = {k: v for k, v in os.environ.items() if k.upper() in ("PATH", "SYSTEMROOT", "TEMP", "TMP", "HOME", "USERPROFILE")}
    env.update(
        D4_EVENT_NAME="workflow_dispatch",
        D4_ORIGIN="pull_request",
        D4_OPERATION="preview",
        D4_REVISION=REVISION,
        D4_BACKEND_LABEL=BACKEND,
    )
    for key, value in overrides.items():
        if value is None:
            env.pop(key, None)
        else:
            env[key] = value
    return env


def run_entry(**overrides):
    return subprocess.run(
        [PWSH, "-NoProfile", "-NonInteractive", "-File", str(ENTRYPOINT)],
        env=fixture_env(**overrides), capture_output=True, text=True, timeout=60,
    )


def traces(stdout):
    return [json.loads(line[len("D4_STUB:"):]) for line in stdout.splitlines() if line.startswith("D4_STUB:")]


@unittest.skipUnless(PWSH, "pwsh (PowerShell 7) is required")
class EntrypointTest(unittest.TestCase):
    def test_pr_revision_previews_nonprod_only(self):
        result = run_entry()
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(traces(result.stdout), [{
            "synthetic": True, "command": "preview", "stack": "nonprod",
            "backend_label": BACKEND, "revision": REVISION,
        }])

    def test_target_and_backend_cannot_be_overridden_by_environment(self):
        # cac ten bien override co the bi them boi PR/environment; entrypoint phai bo qua
        result = run_entry(D4_TARGET="uat", D4_STACK="uat", PULUMI_STACK="uat", STACK="uat",
                           PULUMI_BACKEND_URL="file://override", D4_BACKEND="fixture-backend-uat")
        self.assertEqual(result.returncode, 0, result.stderr)
        trace = traces(result.stdout)
        self.assertEqual(len(trace), 1)
        self.assertEqual(trace[0]["stack"], "nonprod")
        self.assertEqual(trace[0]["backend_label"], BACKEND)

    def test_gate_blocks_other_event_origin_or_operation(self):
        for override in ({"D4_EVENT_NAME": "pull_request"}, {"D4_EVENT_NAME": "push"},
                         {"D4_ORIGIN": "push"}, {"D4_ORIGIN": None},
                         {"D4_OPERATION": "deploy"}, {"D4_OPERATION": "up"}):
            with self.subTest(override=override):
                result = run_entry(**override)
                self.assertEqual(result.returncode, 0, result.stderr)
                self.assertIn("D4_GATE:blocked", result.stdout)
                self.assertEqual(traces(result.stdout), [])

    def test_rejects_invalid_revision(self):
        for revision in ("abc123", REVISION.upper(), REVISION + "0", "main", ""):
            with self.subTest(revision=revision):
                result = run_entry(D4_REVISION=revision)
                self.assertNotEqual(result.returncode, 0)
                self.assertEqual(traces(result.stdout), [])

    def test_rejects_other_backend_label(self):
        for label in ("fixture-backend-uat", "s3://anything", "", None):
            with self.subTest(label=label):
                result = run_entry(D4_BACKEND_LABEL=label)
                self.assertNotEqual(result.returncode, 0)
                self.assertEqual(traces(result.stdout), [])


class SourceContractTest(unittest.TestCase):
    def test_entrypoint_hardcodes_nonprod_and_reads_no_target_input(self):
        text = ENTRYPOINT.read_text(encoding="utf-8")
        self.assertRegex(text, r"(?m)^\$target = 'nonprod'\s*$")
        self.assertNotRegex(text, r"\$env:\w*(TARGET|STACK)\w*")
        self.assertIn("-Revision $env:D4_REVISION", text)

    def test_workflow_is_manual_preview_with_fixed_backend_and_exact_revision(self):
        text = WORKFLOW.read_text(encoding="utf-8")
        on_block = re.search(r"(?ms)^on:\n(.*?)^permissions:", text).group(1)
        triggers = re.findall(r"(?m)^  (\w+):", on_block)
        self.assertEqual(triggers, ["workflow_dispatch"], "no auto PR/push trigger")
        inputs = re.findall(r"(?m)^      (\w+):", on_block)
        self.assertEqual(sorted(inputs), ["mode", "origin", "revision"], "no target/backend input")
        self.assertRegex(on_block, r"options: \[pull_request\]")
        self.assertRegex(on_block, r"options: \[preview\]")
        # permissions chinh xac chi contents: read, khong co block permissions o muc job
        top_permissions = re.search(r"(?ms)^permissions:\n(.*?)^\S", text).group(1)
        self.assertEqual(top_permissions.strip().splitlines(), ["contents: read"])
        jobs_block = text[text.index("\njobs:"):]
        self.assertNotIn("permissions:", jobs_block)
        self.assertIn("if: ${{ github.event_name == 'workflow_dispatch' && inputs.origin == 'pull_request' "
                      "&& inputs.mode == 'preview' }}", text)
        self.assertRegex(text, r"(?m)^      D4_BACKEND_LABEL: fixture-backend-nonprod$")
        self.assertRegex(text, r"(?m)^      D4_REVISION: \$\{\{ inputs\.revision \}\}$")
        self.assertRegex(text, r"(?m)^          ref: \$\{\{ inputs\.revision \}\}$")
        self.assertRegex(text, r"uses: actions/checkout@[0-9a-f]{40}\n", "checkout pinned to a commit")
        self.assertNotRegex(text, r"(?i)target|stack|environment:")


if __name__ == "__main__":
    unittest.main()
