# Contract vận hành D4 — fixture offline

Đây là setup intervention được cấp riêng cho ticket D4; không thay đổi quyết định
deploy hiện có. PR checks vẫn là PR checks; preview được yêu cầu qua manual dispatch,
và deploy manual-dispatch có approval tiếp tục là luồng riêng. Không thêm auto PR
preview, không sửa approval rules/environment hay bootstrap identity.

Workflow `.github/workflows/d4-preview.yml` nhận full revision 40 ký tự hex của PR,
origin `pull_request` và mode `preview`. Entry này chỉ preview NonProd. Target không
nhận từ PR input hoặc environment override. Backend chỉ là nhãn mock cố định
`fixture-backend-nonprod`; nhãn đó không phải URL hay backend có thể đăng nhập.
Revision phải đi xuyên input/checkout/entrypoint/trace; config contract NonProd và
logic hạ tầng của checkpoint D3b được giữ nguyên. UAT không thuộc entry preview này.

Script `scripts/delivery/stub-pulumi.ps1` là fixture chỉ đọc: nó chỉ nhận preview,
ghi trace JSON sanitized, và không gọi Pulumi CLI, đọc config/state/credentials,
đăng nhập backend hoặc liên hệ cloud. Không sửa stub để che một trace không đạt.
Entrypoint cũng từ chối deploy, push, origin khác, revision không hợp lệ và backend
label khác. Một trace là bằng chứng local về script đã chạy, không là observed plan.

`fixtures/d4-preview.synthetic.log` được capture từ một lần chạy PowerShell/stub
thật tại máy local. Nó được gắn nhãn SYNTHETIC: không là log GitHub Actions, không
chứng minh checkout SHA, preview hay gate của CI thật. Run bị lọc chỉ giữ metadata
fixture; không có account ID, provider ID, ARN, credentials hay giá trị secret.

`offline-controls/secret-transform` là control độc lập dùng Pulumi SDK đang pin.
Giá trị được tạo trong memory của test, bọc bằng ToSecret, biến đổi thuần qua ApplyT,
rồi truyền vào Input-valued property dưới mocks. Test kiểm tra metadata và dependency
dataflow; không in giá trị gốc/đã encode. Không fetch config hoặc secret thật.

Kiểm tra local: PowerShell 7 để chạy entrypoint với environment fixture; Python 3
và Go đã cache dependencies để kiểm tra workflow/control. Mọi lệnh Go dùng GOPROXY=off
và GOSUMDB=off. Chưa có quyền dispatch, login, config/state commands, preview CLI,
apply, cloud/bootstrap identity, app builds, push hay commit trong ticket coder.

Để kiểm chứng integration sau này, owner delivery cần cấp quyền và CI identity riêng,
đối chiếu checkout revision, NonProd/config/backend, preview-only permissions và
approval path trên một run thật. Không dispatch hoặc tự cấp identity để hoàn tất lab.
