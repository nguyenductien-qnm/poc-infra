package secrettransform

import (
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
	"net/url"
)

// Bien doi thuan trong Output, giu metadata va dependency cho Input consumer.
func Encode(value pulumi.StringOutput) pulumi.StringOutput {
	return value.ApplyT(func(text string) string { return url.QueryEscape(text) }).(pulumi.StringOutput)
}
