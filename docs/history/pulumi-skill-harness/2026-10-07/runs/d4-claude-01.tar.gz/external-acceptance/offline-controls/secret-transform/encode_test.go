package secrettransform

import (
	"crypto/rand"
	"encoding/base64"
	"fmt"
	"github.com/pulumi/pulumi/sdk/v3/go/common/resource"
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
	"net/url"
	"strings"
	"sync"
	"testing"
)

type source struct {
	pulumi.CustomResourceState
	Value pulumi.StringOutput `pulumi:"value"`
}
type consumer struct{ pulumi.CustomResourceState }
type secretMocks struct {
	mu        sync.Mutex
	generated string
	records   []pulumi.MockResourceArgs
}

func (m *secretMocks) Call(args pulumi.MockCallArgs) (resource.PropertyMap, error) {
	return nil, fmt.Errorf("unexpected invoke: %s", args.Token)
}
func (m *secretMocks) NewResource(args pulumi.MockResourceArgs) (string, resource.PropertyMap, error) {
	m.mu.Lock()
	defer m.mu.Unlock()
	m.records = append(m.records, args)
	outputs := args.Inputs.Copy()
	if args.TypeToken == "fixture:config:Source" {
		outputs["value"] = resource.NewStringProperty(m.generated)
	}
	return "fixture-resource", outputs, nil
}

func TestPureApplyTRetainsSecretAndDependencies(t *testing.T) {
	t.Run("known-secret", func(t *testing.T) {
		// Gia tri chi ton tai trong memory, khong ghi vao source hay log.
		bytes := make([]byte, 24)
		if _, err := rand.Read(bytes); err != nil {
			t.Fatal("could not generate in-memory test input")
		}
		value := base64.StdEncoding.EncodeToString(bytes) + " /+?"
		mocks := &secretMocks{generated: value}
		err := pulumi.RunErr(func(ctx *pulumi.Context) error {
			src := &source{}
			if err := ctx.RegisterResource("fixture:config:Source", "source", nil, src); err != nil {
				return err
			}
			marked := pulumi.ToSecret(src.Value).(pulumi.StringOutput)
			transformed := Encode(marked)
			if !pulumi.IsSecret(transformed) {
				return fmt.Errorf("secret metadata not preserved")
			}
			dst := &consumer{}
			return ctx.RegisterResource("fixture:config:Consumer", "consumer", pulumi.Map{"encoded": transformed}, dst)
		}, pulumi.WithMocks("secret-transform", "unit", mocks))
		if err != nil {
			t.Fatal("mocked secret transformation failed without logging its value")
		}
		mocks.mu.Lock()
		records := append([]pulumi.MockResourceArgs(nil), mocks.records...)
		mocks.mu.Unlock()
		if len(records) != 2 {
			t.Fatalf("got %d registrations, want two", len(records))
		}
		var target pulumi.MockResourceArgs
		for _, item := range records {
			if item.TypeToken == "fixture:config:Consumer" {
				target = item
			}
		}
		encoded, ok := target.Inputs["encoded"]
		if !ok || !encoded.IsSecret() {
			t.Fatal("consumer Input must retain secret metadata")
		}
		element := encoded.SecretValue().Element
		if !element.IsString() || element.StringValue() != url.QueryEscape(value) {
			t.Fatal("consumer did not receive the pure transformed synthetic input; value omitted")
		}
		preserved := false
		for _, dependency := range target.RegisterRPC.GetPropertyDependencies()["encoded"].GetUrns() {
			if strings.HasSuffix(dependency, "::source") && strings.Contains(dependency, "fixture:config:Source") {
				preserved = true
			}
		}
		if !preserved {
			t.Fatal("consumer Input lost source Output dependency")
		}
		t.Log("pure ApplyT secret metadata and dependency propagation verified under mocks; values omitted")
	})
}
