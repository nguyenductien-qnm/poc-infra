package workspace

import (
	"github.com/pulumi/pulumi/sdk/v3/go/pulumi"
	"strings"
	"testing"
	"xbrain.local/daily/internal/testutil"
)

func NonProdArgs() *Args {
	return &Args{Environment: "nonprod", Region: "ap-southeast-1", StoragePrefix: "xbrain-nonprod-uploads-", ReplicaCount: 1,
		Image: pulumi.String("fixture.invalid/api@sha256:" + strings.Repeat("a", 64)),
		VpcID: pulumi.String("fixture-vpc"), SubnetIDs: pulumi.StringArray{pulumi.String("fixture-subnet-a")}, PeerCIDR: "10.30.0.0/16"}
}

// UAT theo contract D2: cung image/region, mang ngoai rieng voi hai subnets
func UATArgs() *Args {
	args := NonProdArgs()
	args.Environment, args.StoragePrefix, args.ReplicaCount = "uat", "xbrain-uat-uploads-", 2
	args.VpcID = pulumi.String("fixture-vpc-uat")
	args.SubnetIDs = pulumi.ToStringArray([]string{"fixture-subnet-uat-a", "fixture-subnet-uat-b"})
	return args
}

type expected struct {
	name, prefix, environment string
	desiredCount              float64
	subnets                   []string
}

// chay workspace tren mocks va kiem tra identity, prefix, capacity, tags va network contract
func runWorkspace(t *testing.T, args *Args, want expected) {
	t.Helper()
	mocks := &testutil.Mocks{}
	err := pulumi.RunErr(func(ctx *pulumi.Context) error {
		result, err := New(ctx, want.name, args)
		if err != nil {
			return err
		}
		ctx.Export("bucketName", result.BucketName)
		ctx.Export("serviceName", result.ServiceName)
		return nil
	}, pulumi.WithMocks("daily-workspace", want.name, mocks))
	if err != nil {
		t.Fatal(err)
	}
	components := map[string]string{
		"xbrain:workspace:Workspace": want.name,
		"xbrain:storage:Storage":     want.name + "-object-store",
		"xbrain:workload:Workload":   want.name + "-workload",
		"pulumi:providers:aws":       want.name + "-aws",
	}
	seen := map[string]bool{}
	for _, item := range mocks.Resources() {
		if name, ok := components[item.TypeToken]; ok {
			seen[item.TypeToken] = true
			if item.Name != name {
				t.Fatalf("%s logical name = %q, want %q", item.TypeToken, item.Name, name)
			}
			continue
		}
		if tags, ok := item.Inputs["tags"]; ok && tags.IsObject() {
			values := tags.ObjectValue()
			if values["Environment"].StringValue() != want.environment || values["Team"].StringValue() != "xbrain" {
				t.Fatalf("%s tags = %v", item.Name, values)
			}
		}
		switch item.TypeToken {
		case "aws:s3/bucket:Bucket":
			seen[item.TypeToken] = true
			if item.Name != want.name+"-object-store-uploads" || item.Inputs["bucketPrefix"].StringValue() != want.prefix {
				t.Fatalf("bucket contract changed: %s %v", item.Name, item.Inputs["bucketPrefix"])
			}
			if !strings.HasSuffix(item.RegisterRPC.GetParent(), "::"+want.name+"-object-store") || item.Provider == "" {
				t.Fatal("bucket must have storage parent and inherited provider")
			}
		case "aws:ecs/service:Service":
			seen[item.TypeToken] = true
			if item.Name != want.name+"-workload-service" || item.Inputs["desiredCount"].NumberValue() != want.desiredCount {
				t.Fatalf("service contract changed: %s %v", item.Name, item.Inputs["desiredCount"])
			}
			network := item.Inputs["networkConfiguration"].ObjectValue()
			subnets := network["subnets"].ArrayValue()
			if len(subnets) != len(want.subnets) {
				t.Fatalf("subnets = %v, want %v", subnets, want.subnets)
			}
			for i, id := range want.subnets {
				if subnets[i].StringValue() != id {
					t.Fatalf("external subnet %d = %v, want %s", i, subnets[i], id)
				}
			}
		case "aws:cloudwatch/logGroup:LogGroup":
			if item.Inputs["retentionInDays"].NumberValue() != 7 {
				t.Fatal("log retention changed")
			}
		case "aws:ec2/vpc:Vpc", "aws:ec2/subnet:Subnet":
			t.Fatal("workspace must not own external network")
		}
	}
	for _, token := range []string{"xbrain:workspace:Workspace", "xbrain:storage:Storage", "xbrain:workload:Workload",
		"pulumi:providers:aws", "aws:s3/bucket:Bucket", "aws:ecs/service:Service"} {
		if !seen[token] {
			t.Fatalf("missing %s", token)
		}
	}
}

func TestExistingNonProd(t *testing.T) {
	runWorkspace(t, NonProdArgs(), expected{name: "nonprod", prefix: "xbrain-nonprod-uploads-", environment: "nonprod", desiredCount: 1,
		subnets: []string{"fixture-subnet-a"}})
}

func TestUAT(t *testing.T) {
	runWorkspace(t, UATArgs(), expected{name: "uat", prefix: "xbrain-uat-uploads-", environment: "uat", desiredCount: 2,
		subnets: []string{"fixture-subnet-uat-a", "fixture-subnet-uat-b"}})
}

// image unknown trong DryRun (nhu preview khi image chua resolve): moi registration van nam ngoai ApplyT,
// nen van du 13 resources va alias storage van duoc khai bao
func TestUnknownImageDryRun(t *testing.T) {
	for name, build := range map[string]func() *Args{"nonprod": NonProdArgs, "uat": UATArgs} {
		t.Run(name, func(t *testing.T) {
			args := build()
			args.Image = pulumi.UnsafeUnknownOutput(nil).ApplyT(func(v interface{}) string { return "" }).(pulumi.StringOutput)
			mocks := &testutil.Mocks{}
			dryRun := func(info *pulumi.RunInfo) { info.DryRun = true }
			err := pulumi.RunErr(func(ctx *pulumi.Context) error {
				_, err := New(ctx, name, args)
				return err
			}, pulumi.WithMocks("daily-workspace", name, mocks), dryRun)
			if err != nil {
				t.Fatal(err)
			}
			names := map[string]string{}
			for _, item := range mocks.Resources() {
				names[item.Name] = item.TypeToken
				if item.Name == name+"-object-store" {
					aliases := item.RegisterRPC.GetAliases()
					if len(aliases) != 1 || aliases[0].GetSpec().GetName() != name+"-storage" {
						t.Fatalf("storage alias = %v", aliases)
					}
				}
				if item.TypeToken == "aws:ecs/taskDefinition:TaskDefinition" && item.Inputs["containerDefinitions"].IsString() {
					t.Fatal("container definitions should be unknown when image is unknown")
				}
			}
			for _, want := range []string{name + "-object-store-uploads", name + "-object-store-uploads-access",
				name + "-workload-task", name + "-workload-service"} {
				if names[want] == "" {
					t.Fatalf("dry-run with unknown image missing %s", want)
				}
			}
			if len(names) != 13 {
				t.Fatalf("dry-run registered %d resources, want 13", len(names))
			}
		})
	}
}

func TestRejectsIncompleteArgs(t *testing.T) {
	cases := map[string]func(*Args){
		"missing storage prefix": func(a *Args) { a.StoragePrefix = "" },
		"zero replica count":     func(a *Args) { a.ReplicaCount = 0 },
		"negative replica count": func(a *Args) { a.ReplicaCount = -1 },
	}
	for name, mutate := range cases {
		t.Run(name, func(t *testing.T) {
			args := UATArgs()
			mutate(args)
			mocks := &testutil.Mocks{}
			err := pulumi.RunErr(func(ctx *pulumi.Context) error {
				_, err := New(ctx, "uat", args)
				return err
			}, pulumi.WithMocks("daily-workspace", "uat", mocks))
			if err == nil {
				t.Fatal("expected validation error")
			}
			if len(mocks.Resources()) != 0 {
				t.Fatal("invalid args must fail before registering resources")
			}
		})
	}
}
